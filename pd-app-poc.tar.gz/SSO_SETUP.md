# SSO (OIDC) Setup

This app ships **SSO-ready but not SSO-active**. Every piece needed to plug
in a real identity provider is already in place — the database schema, the
config, the API routing, and the login screen's UI — but nothing is turned
on until you fill in real values below. Until then, `SSO_ENABLED=false` and
the login screen behaves exactly as it does today (email + password only).

## What's already in place

- **Database:** `users.password_hash` is nullable, and `users.auth_provider`
  (`'local'` | `'oidc'`) + `users.sso_subject` (the IdP's stable unique user
  id) columns exist. A user is either a local account with a password, or an
  SSO account with a subject id — enforced by a check constraint.
- **Config** (`backend/app/core/config.py` / `.env`): `SSO_ENABLED`,
  `OIDC_ISSUER`, `OIDC_CLIENT_ID`, `OIDC_CLIENT_SECRET`, `OIDC_REDIRECT_URI`.
  All blank/false by default.
- **API scaffold** (`backend/app/api/sso.py`):
  - `GET /api/auth/sso/status` — tells the frontend whether to show the
    button. Already live and safe to call regardless of whether SSO is on.
  - `GET /api/auth/sso/login` — will redirect to the IdP. Currently returns
    `501` with a clear message.
  - `POST /api/auth/sso/callback` — will complete the login. Currently
    returns `501`. The exact real implementation (token exchange, JWKS
    validation, JIT user provisioning) is written out step-by-step as a
    comment in that file — it's not guesswork, just not wired up yet.
- **Frontend:** a "Sign in with SSO" button already exists on the login
  screen (`index.html`) and is wired to call `Auth.ssoLogin()`
  (`auth.js`) — but it stays `display:none` until
  `GET /api/auth/sso/status` reports `enabled: true`.

## What you need to activate it

You need an OIDC-compliant identity provider registration. For Azure AD /
Microsoft Entra ID (the common choice for a Microsoft-365 enterprise), that
means an **App Registration** in the Azure portal. You'll come away with:

| Value | Where it comes from |
|---|---|
| `OIDC_ISSUER` | Azure AD: `https://login.microsoftonline.com/<tenant-id>/v2.0` |
| `OIDC_CLIENT_ID` | The App Registration's "Application (client) ID" |
| `OIDC_CLIENT_SECRET` | A client secret you generate under the App Registration's "Certificates & secrets" |
| `OIDC_REDIRECT_URI` | Must be registered in Azure AD's "Redirect URIs" list exactly, e.g. `https://your-backend.run.app/api/auth/sso/callback` |

For Okta, Google Workspace, or another OIDC provider, the equivalent
"discovery document" URL (`<issuer>/.well-known/openid-configuration`) and
app registration flow apply — the shape is the same.

## Steps to go live

1. Register the app with your identity provider, get the 4 values above.
2. Set them in `.env` (or Secret Manager in production) and flip
   `SSO_ENABLED=true`.
3. Add `authlib` to `backend/requirements.txt` (`pip install Authlib`) — it's
   the library the real implementation in `sso.py`'s comments is written
   against, and handles the discovery document + JWKS validation for you.
4. Add `starlette.middleware.sessions.SessionMiddleware` to `main.py` with a
   secret key — `authlib`'s `authorize_redirect`/`authorize_access_token`
   need somewhere to stash the OIDC `state`/`nonce` between the redirect out
   and the callback back in.
5. Replace the two `raise HTTPException(501, ...)` calls in
   `backend/app/api/sso.py` with the real logic already sketched in the
   docstrings above them.
6. Restart the backend. The login screen will automatically show the
   "Sign in with SSO" button the moment `/api/auth/sso/status` reports
   `enabled: true` — no frontend changes needed.

## Why this shape

Once an SSO login succeeds, the callback issues the exact same app-level
JWT that `/api/auth/login` issues today (`create_access_token(user.id)`).
Every other part of the app — role checks, finance-access gating, audit
logging, the `get_current_user` dependency — has no idea whether a session
started via password or SSO. That's intentional: the auth *method* is a
detail contained entirely to login; everything downstream stays unchanged.
