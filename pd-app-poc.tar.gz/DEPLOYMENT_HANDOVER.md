# PD Dashboard — Deployment Handover
## Aramco Digital — Product Portfolio Management Platform

---

## 1. Project Overview

| Item | Detail |
|------|--------|
| Application | PD Dashboard |
| Organization | Aramco Digital |
| Stack | FastAPI (Python) + Vanilla JS + PostgreSQL |
| Target | Google Cloud Run + Cloud SQL |
| Auth | JWT Bearer Token (bcrypt passwords) |
| Admin login | pd.admin@aramcodigital.com / admin (**change on first deploy**) |

---

## 2. Repository Structure

```
pd-dashboard/
├── backend/                  ← FastAPI Python app
│   ├── Dockerfile
│   ├── .env.example          ← Copy to .env, fill in values
│   ├── requirements.txt
│   └── app/
│       ├── main.py           ← App entry point, CORS config
│       ├── core/
│       │   ├── config.py     ← Env var loading
│       │   ├── database.py   ← SQLAlchemy async session
│       │   └── security.py   ← JWT + bcrypt
│       ├── models/           ← SQLAlchemy ORM models
│       ├── schemas/          ← Pydantic request/response schemas
│       ├── api/              ← Route handlers
│       │   ├── auth.py       ← Login, logout, /me
│       │   ├── sso.py        ← OIDC scaffold, inactive by default (SSO_SETUP.md)
│       │   ├── products.py   ← Product CRUD
│       │   ├── data.py       ← Milestones, financials, risks, comments
│       │   ├── admin.py      ← Users, notifications, audit logs, Excel import
│       │   ├── gates.py      ← Gate tasks, heatmap, reorder
│       │   ├── partnerships.py
│       │   └── clients.py
│       └── services/
│           ├── audit.py      ← Audit log writer
│           └── notifications.py
│
├── frontend/                 ← Static HTML/CSS/JS (no build step)
│   ├── index.html
│   ├── nginx.conf            ← For Cloud Run container
│   ├── Dockerfile
│   ├── nocache_server.py     ← Optional local-dev server (disables caching)
│   ├── css/
│   │   ├── main.css          ← Design tokens + layout (Daylight/white theme)
│   │   └── components.css
│   └── js/
│       ├── api.js            ← BASE URL must be updated before deploy
│       ├── auth.js           ← Password login + SSO button wiring
│       ├── theme.js          ← Brand mark + particle background
│       ├── router.js
│       ├── components/
│       └── pages/            ← overview, portfolio, product, gates,
│                                financials, decisions, team, logs, settings
│
└── database/
    └── schema.sql            ← The only file needed — creates every table/
                                 view/trigger and seeds gates + default admin
                                 in one pass (no separate migration files)
```

---

## 3. Database Setup

```bash
psql -U pd_user -d pd_dashboard -f database/schema.sql
```

That's the only file — it's the consolidated schema (tables, views,
triggers, seed data) in one pass.

**Cloud SQL:** run the same file via Cloud SQL proxy or Cloud Shell.

---

## 4. Environment Variables

```env
# .env.example
DATABASE_URL=postgresql+asyncpg://USER:PASSWORD@HOST:5432/pd_dashboard
SYNC_DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/pd_dashboard
SECRET_KEY=generate-with-python-secrets-token-hex-32
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=480
APP_ENV=production
FRONTEND_URL=https://your-frontend-url.run.app

# SSO (OIDC) — leave disabled until a real identity provider is configured.
# See SSO_SETUP.md for exactly what these are and where they come from.
SSO_ENABLED=false
OIDC_ISSUER=
OIDC_CLIENT_ID=
OIDC_CLIENT_SECRET=
OIDC_REDIRECT_URI=
```

**Generate SECRET_KEY:**
```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

---

## 5. GCP Architecture

```
┌─────────────────────────────────────────────────────┐
│  Google Cloud Platform                              │
│                                                     │
│  ┌──────────────┐    ┌─────────────────────────┐   │
│  │  Cloud Run   │    │  Cloud Run              │   │
│  │  Frontend    │───▶│  Backend API (FastAPI)  │   │
│  │  (nginx)     │    │  Port 8000              │   │
│  └──────────────┘    └───────────┬─────────────┘   │
│                                  │                  │
│                     ┌────────────▼──────────────┐  │
│                     │  Cloud SQL (PostgreSQL 15) │  │
│                     │  Private IP connection     │  │
│                     └───────────────────────────┘  │
│                                                     │
│  ┌──────────────────────────────────────────────┐  │
│  │  Secret Manager                              │  │
│  │  DATABASE_URL, SECRET_KEY, DB credentials   │  │
│  └──────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

---

## 6. CI/CD Pipeline (GitLab + Jenkins → GCP)

```
Developer pushes code
        │
        ▼
┌───────────────┐
│   GitLab      │
│   - Lint      │
│   - Unit test │
│   - SAST scan │
└───────┬───────┘
        │
        ▼
┌───────────────┐
│   Jenkins     │
│   - Build     │
│   - Docker    │
│   - Push GCR  │
└───────┬───────┘
        │
        ▼
┌───────────────┐
│   GCP         │
│   - Cloud Run │
│   - Deploy    │
└───────────────┘
```

---

## 7. Security Checklist

| Item | Status | Notes |
|------|--------|-------|
| JWT authentication | ✅ | All API endpoints protected |
| bcrypt password hashing | ✅ | Rounds=12 |
| Role-based access | ✅ | Admin / Manager / Team Lead |
| Finance data restricted | ✅ | Admin + explicit grant only |
| CORS configured | ✅ | Whitelist only — update for production URL |
| SQL injection | ✅ | SQLAlchemy parameterized queries |
| Audit logging | ✅ | Every action logged with user + timestamp |
| HTTPS | ⚠️ | Cloud Run handles TLS termination — ensure enforced |
| Secret management | ⚠️ | Move to GCP Secret Manager — do not use .env in prod |
| Rate limiting | ⚠️ | Not implemented — add via Cloud Armor or API Gateway |
| Password policy | ⚠️ | Currently min 6 chars — enforce stronger in prod |
| Admin password | ⚠️ | **Change default password immediately after deploy** |
| SSO / OIDC | 🔧 | Scaffolded, inactive (`SSO_ENABLED=false`) — see SSO_SETUP.md |

---

## 8. First Deploy Checklist

- [ ] Generate new SECRET_KEY
- [ ] Create Cloud SQL PostgreSQL 15 instance
- [ ] Run `database/schema.sql` (the only file needed)
- [ ] Set all env vars in Cloud Run (via Secret Manager) — leave
      `SSO_ENABLED=false` unless SSO has actually been configured
      (see SSO_SETUP.md)
- [ ] Update `frontend/js/api.js` BASE URL to backend Cloud Run URL
- [ ] Update CORS in `backend/app/main.py` to frontend URL
- [ ] Deploy backend Cloud Run service
- [ ] Deploy frontend Cloud Run service
- [ ] Test login with pd.admin@aramcodigital.com / admin
- [ ] **Change admin password immediately**
- [ ] Create real user accounts in Settings → Manage Users

---

## 9. Key API Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | /api/auth/login | None | Login |
| GET | /api/auth/me | JWT | Current user |
| GET | /api/auth/sso/status | None | Whether SSO is configured (frontend uses this to show/hide the SSO button) |
| GET | /api/products/ | JWT | List products |
| POST | /api/products/ | Manager+ | Create product |
| GET | /api/gates/heatmap | JWT | Overview heatmap |
| GET | /api/gates/progress/{id} | JWT | Product gate detail |
| PUT | /api/gates/task-status | JWT | Update task status |
| GET | /api/clients/summary | JWT | Client overview |
| GET | /api/financials/ | Finance+ | Financial data |

Full API docs available at: `https://your-backend-url.run.app/api/docs`

---

## 10. Contact

For questions about the codebase, contact the development team.
