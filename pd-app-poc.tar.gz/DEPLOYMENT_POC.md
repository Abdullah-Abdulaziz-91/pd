# Cloud Run PoC Deployment

This PoC uses one GCP environment with two Cloud Run services:

- Frontend: `pd-frontend-poc`
- Backend: `pd-backend-poc`

## Frontend

The frontend is a Vanilla JS SPA served by nginx. It reads the backend API base URL from `window.API_BASE_URL` before loading the API client.

The frontend container generates `config.js` from `config.template.js` when the container starts, using the non-secret `API_BASE_URL` environment variable.

Frontend Cloud Run non-secret environment variable:

- `API_BASE_URL=https://BACKEND_CLOUD_RUN_URL/api`

Local development falls back to `http://localhost:8000/api` when `window.API_BASE_URL` is not set.

CDN assets can remain as-is for the PoC because the environment has internet access.

## Backend

The backend is a Python FastAPI service. The Cloud Run service name is `pd-backend-poc`.

Required backend secrets from Google Secret Manager:

- `DATABASE_URL`
- `SYNC_DATABASE_URL`
- `SECRET_KEY`

Required backend non-secret environment variables:

- `FRONTEND_URL=https://REPLACE_WITH_FRONTEND_CLOUD_RUN_URL`
- `APP_ENV=poc`
- `SSO_ENABLED=false`
- `ALGORITHM=HS256`
- `ACCESS_TOKEN_EXPIRE_MINUTES=480`

The backend container starts with:

```sh
uvicorn app.main:app --host 0.0.0.0 --port ${PORT:-8000}
```

Cloud Run provides `PORT`; the Dockerfile defaults to `8000` for local container runs.

## Database

Use Cloud SQL PostgreSQL 15 or newer.

Prefer private IP or the Cloud SQL connector for database connectivity. Run `database/schema.sql` once against a fresh database before first use.

After first login, change the default admin password immediately.

## Secrets

Do not bake `.env`, `.env.local`, database URLs, passwords, Cloud Run URLs, or other real secrets into Docker images. Local development can continue to use `.env` files, but production and PoC runtime values should come from Cloud Run environment variables and Secret Manager.

## Optional VM

An optional VM may be used for deployment or administrative work only. It is not part of the application runtime; the app runtime is Cloud Run plus Cloud SQL.
