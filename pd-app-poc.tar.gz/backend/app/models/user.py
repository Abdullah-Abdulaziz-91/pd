from sqlalchemy import Column, Integer, String, Boolean, TIMESTAMP, func
from sqlalchemy.orm import relationship
from app.core.database import Base


class User(Base):
    __tablename__ = "users"

    id             = Column(Integer, primary_key=True)
    email          = Column(String(255), unique=True, nullable=False)
    name           = Column(String(255), nullable=False)
    password_hash  = Column(String(255), nullable=True)  # NULL for SSO accounts
    role           = Column(String(50), nullable=False, default="Team Lead")
    department     = Column(String(255))
    initials       = Column(String(10))
    finance_access = Column(Boolean, nullable=False, default=False)
    is_active      = Column(Boolean, nullable=False, default=True)
    auth_provider  = Column(String(20), nullable=False, default="local")  # local | oidc
    sso_subject    = Column(String(255), unique=True, nullable=True)
    created_at     = Column(TIMESTAMP(timezone=True), server_default=func.now())
    updated_at     = Column(TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now())

    comments      = relationship("Comment", back_populates="user", foreign_keys="Comment.user_id")
    notifications = relationship("Notification", back_populates="user", cascade="all, delete-orphan")
    audit_logs    = relationship("AuditLog", back_populates="user")
