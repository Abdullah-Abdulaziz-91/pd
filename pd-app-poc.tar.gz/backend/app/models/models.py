from sqlalchemy import (
    Column, Integer, String, Text, Boolean, Date, Numeric,
    ForeignKey, ARRAY, TIMESTAMP, func
)
from sqlalchemy.orm import relationship
from app.core.database import Base


class Product(Base):
    __tablename__ = "products"

    id               = Column(Integer, primary_key=True)
    product_code     = Column(String(50), unique=True, nullable=False)
    name             = Column(String(255), nullable=False)
    description      = Column(Text)
    status           = Column(String(50), nullable=False, default="Unknown")
    priority         = Column(String(20), nullable=False, default="Medium")
    completion       = Column(Integer, nullable=False, default=0)
    action_required  = Column(String(255))
    team_lead        = Column(String(255))
    team_lead_user_id= Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    start_date       = Column(Date)
    readiness_date   = Column(Date)
    pipeline_value   = Column(Numeric(15,2))
    customer_count   = Column(Integer, default=0)
    notes            = Column(Text)
    is_active        = Column(Boolean, nullable=False, default=True)
    created_by       = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    created_at       = Column(TIMESTAMP(timezone=True), server_default=func.now())
    updated_at       = Column(TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now())

    milestones        = relationship("Milestone",   back_populates="product", cascade="all, delete-orphan")
    financials        = relationship("Financial",   back_populates="product", cascade="all, delete-orphan")
    risks             = relationship("Risk",        back_populates="product", cascade="all, delete-orphan")
    comments          = relationship("Comment",     back_populates="product", cascade="all, delete-orphan")
    decision_priority = relationship("DecisionPriority", back_populates="product", uselist=False, cascade="all, delete-orphan")


class Milestone(Base):
    __tablename__ = "milestones"

    id          = Column(Integer, primary_key=True)
    product_id  = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), nullable=False)
    name        = Column(String(255), nullable=False)
    description = Column(Text)
    due_date    = Column(Date, nullable=False)
    status      = Column(String(50), nullable=False, default="Not Started")
    assigned_to = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    notes       = Column(Text)
    created_by  = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    created_at  = Column(TIMESTAMP(timezone=True), server_default=func.now())
    updated_at  = Column(TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now())

    product     = relationship("Product", back_populates="milestones")
    assignee    = relationship("User", foreign_keys=[assigned_to])


class Financial(Base):
    __tablename__ = "financials"

    id              = Column(Integer, primary_key=True)
    product_id      = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), nullable=False)
    approved_budget = Column(Numeric(15, 2), nullable=False, default=0)
    actual_spend    = Column(Numeric(15, 2), nullable=False, default=0)
    forecast        = Column(Numeric(15, 2), nullable=False, default=0)
    quarter         = Column(String(20))
    notes           = Column(Text)
    created_at      = Column(TIMESTAMP(timezone=True), server_default=func.now())
    updated_at      = Column(TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now())

    product         = relationship("Product", back_populates="financials")


class Risk(Base):
    __tablename__ = "risks"

    id            = Column(Integer, primary_key=True)
    risk_code     = Column(String(50))
    product_id    = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), nullable=False)
    title         = Column(String(255), nullable=False)
    description   = Column(Text)
    category      = Column(String(100))
    likelihood    = Column(String(20))
    impact        = Column(String(20))
    risk_score    = Column(Integer)
    mitigation    = Column(Text)
    owner         = Column(String(255))
    owner_user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    status        = Column(String(50), nullable=False, default="Open")
    created_by    = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    created_at    = Column(TIMESTAMP(timezone=True), server_default=func.now())
    updated_at    = Column(TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now())

    product       = relationship("Product", back_populates="risks")


class Comment(Base):
    __tablename__ = "comments"

    id          = Column(Integer, primary_key=True)
    product_id  = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), nullable=False)
    user_id     = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    body        = Column(Text, nullable=False)
    mentions    = Column(ARRAY(String))
    created_at  = Column(TIMESTAMP(timezone=True), server_default=func.now())
    updated_at  = Column(TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now())

    product     = relationship("Product", back_populates="comments")
    user        = relationship("User", back_populates="comments", foreign_keys=[user_id])


class Notification(Base):
    __tablename__ = "notifications"

    id          = Column(Integer, primary_key=True)
    user_id     = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    type        = Column(String(50), nullable=False)
    title       = Column(String(255), nullable=False)
    body        = Column(Text)
    link        = Column(String(255))
    is_read     = Column(Boolean, nullable=False, default=False)
    created_at  = Column(TIMESTAMP(timezone=True), server_default=func.now())

    user        = relationship("User", back_populates="notifications")


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id          = Column(Integer, primary_key=True)
    user_id     = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    user_name   = Column(String(255))
    action_type = Column(String(50), nullable=False)
    entity_type = Column(String(50))
    entity_id   = Column(Integer)
    entity_name = Column(String(255))
    field_name  = Column(String(100))
    old_value   = Column(Text)
    new_value   = Column(Text)
    detail      = Column(Text)
    ip_address  = Column(String(50))
    created_at  = Column(TIMESTAMP(timezone=True), server_default=func.now())

    user        = relationship("User", back_populates="audit_logs")


class DecisionPriority(Base):
    __tablename__ = "decision_priorities"

    product_id  = Column(Integer, ForeignKey("products.id", ondelete="CASCADE"), primary_key=True)
    set_by      = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    priority    = Column(String(20), nullable=False, default="High")
    updated_at  = Column(TIMESTAMP(timezone=True), server_default=func.now(), onupdate=func.now())

    product     = relationship("Product", back_populates="decision_priority")
