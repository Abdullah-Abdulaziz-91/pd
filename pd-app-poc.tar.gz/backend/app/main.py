from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from contextlib import asynccontextmanager
import os

from app.core.config import settings
import app.models  # noqa: F401  (registers all ORM models/relationships)
from app.api.auth     import router as auth_router
from app.api.sso      import router as sso_router
from app.api.products import router as products_router
from app.api.data     import (
    milestones_router, financials_router,
    risks_router, comments_router,
)
from app.api.gates         import router as gates_router
from app.api.clients       import router as clients_router
from app.api.partnerships  import router as partnerships_router
from app.api.admin    import (
    users_router, notif_router, logs_router, excel_router,
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    print(f"🚀  PD Dashboard API starting [{settings.APP_ENV}]")
    yield
    print("API shutting down")


app = FastAPI(
    title       = "PD Dashboard API",
    description = "Aramco Digital — Product Portfolio Management",
    version     = "1.0.0",
    lifespan    = lifespan,
    docs_url    = "/api/docs",
    redoc_url   = "/api/redoc",
    openapi_url = "/api/openapi.json",
)

# ── CORS ──────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        settings.FRONTEND_URL,
        "http://localhost:8080",
        "http://localhost:3000",
        "http://127.0.0.1:8080",
    ],
    allow_credentials = True,
    allow_methods     = ["*"],
    allow_headers     = ["*"],
)

# ── API Routes ────────────────────────────────────────────
app.include_router(auth_router)
app.include_router(sso_router)
app.include_router(products_router)
app.include_router(milestones_router)
app.include_router(financials_router)
app.include_router(risks_router)
app.include_router(comments_router)
app.include_router(users_router)
app.include_router(notif_router)
app.include_router(logs_router)
app.include_router(excel_router)
app.include_router(gates_router)
app.include_router(partnerships_router)
app.include_router(clients_router)


# ── Health check ──────────────────────────────────────────
@app.get("/health")
async def health():
    return {"status": "ok", "env": settings.APP_ENV}


# ── Serve frontend static files ───────────────────────────
# In production, FastAPI also serves the HTML dashboard
frontend_dir = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.isdir(frontend_dir):
    app.mount("/static", StaticFiles(directory=frontend_dir), name="static")

    @app.get("/", include_in_schema=False)
    async def serve_frontend():
        return FileResponse(os.path.join(frontend_dir, "index.html"))

    @app.get("/{full_path:path}", include_in_schema=False)
    async def catch_all(full_path: str):
        # SPA fallback — return index.html for non-API routes
        if full_path.startswith("api/"):
            from fastapi import HTTPException
            raise HTTPException(status_code=404)
        return FileResponse(os.path.join(frontend_dir, "index.html"))
