from __future__ import annotations
from datetime import date, datetime
from typing import Optional, List
from pydantic import BaseModel, EmailStr, field_validator
from decimal import Decimal


# ── Auth ──────────────────────────────────────────────────
class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ── User ──────────────────────────────────────────────────
class UserOut(BaseModel):
    id: int
    email: str
    name: str
    role: str
    department: Optional[str]
    initials: Optional[str]
    is_active: bool
    auth_provider: str = "local"

    model_config = {"from_attributes": True}


class UserCreate(BaseModel):
    email: EmailStr
    name: str
    password: str
    role: str = "Team Lead"
    department: Optional[str] = None
    initials: Optional[str] = None


class UserUpdate(BaseModel):
    name: Optional[str] = None
    department: Optional[str] = None
    initials: Optional[str] = None


class PasswordChange(BaseModel):
    current_password: str
    new_password: str

    @field_validator("new_password")
    @classmethod
    def password_strength(cls, v):
        if len(v) < 6:
            raise ValueError("Password must be at least 6 characters")
        return v


# ── Product ───────────────────────────────────────────────
class ProductBase(BaseModel):
    product_code: str
    name: str
    description: Optional[str] = None
    status: str = "Unknown"
    priority: str = "Medium"
    completion: int = 0
    action_required: Optional[str] = None
    team_lead: Optional[str] = None
    team_lead_user_id: Optional[int] = None
    start_date: Optional[date] = None
    readiness_date: Optional[date] = None
    pipeline_value: Optional[float] = None
    customer_count: Optional[int] = None
    notes: Optional[str] = None


class ProductCreate(ProductBase):
    pass


class ProductUpdate(BaseModel):
    product_code: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    priority: Optional[str] = None
    completion: Optional[int] = None
    action_required: Optional[str] = None
    team_lead: Optional[str] = None
    team_lead_user_id: Optional[int] = None
    start_date: Optional[date] = None
    readiness_date: Optional[date] = None
    pipeline_value: Optional[float] = None
    customer_count: Optional[int] = None
    notes: Optional[str] = None
    is_active: Optional[bool] = None


class ProductOut(ProductBase):
    id: int
    is_active: bool
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class ProductDetail(ProductOut):
    milestones:   List[MilestoneOut] = []
    financials:   List[FinancialOut] = []
    risks:        List[RiskOut] = []
    comments:     List[CommentOut] = []

    model_config = {"from_attributes": True}


# ── Milestone ─────────────────────────────────────────────
class MilestoneBase(BaseModel):
    name: str
    description: Optional[str] = None
    due_date: date
    status: str = "Not Started"
    assigned_to: Optional[int] = None
    notes: Optional[str] = None


class MilestoneCreate(MilestoneBase):
    product_id: int


class MilestoneUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    due_date: Optional[date] = None
    status: Optional[str] = None
    assigned_to: Optional[int] = None
    notes: Optional[str] = None


class MilestoneOut(MilestoneBase):
    id: int
    product_id: int
    created_at: datetime
    updated_at: datetime
    product_name: Optional[str] = None

    model_config = {"from_attributes": True}


# ── Financial ─────────────────────────────────────────────
class FinancialBase(BaseModel):
    approved_budget: Decimal = Decimal("0")
    actual_spend: Decimal = Decimal("0")
    forecast: Decimal = Decimal("0")
    quarter: Optional[str] = None
    notes: Optional[str] = None


class FinancialCreate(FinancialBase):
    product_id: int


class FinancialUpdate(BaseModel):
    approved_budget: Optional[Decimal] = None
    actual_spend: Optional[Decimal] = None
    forecast: Optional[Decimal] = None
    quarter: Optional[str] = None
    notes: Optional[str] = None


class FinancialOut(FinancialBase):
    id: int
    product_id: int
    created_at: datetime
    updated_at: datetime
    utilization_pct: Optional[float] = None
    variance: Optional[Decimal] = None

    model_config = {"from_attributes": True}


# ── Risk ──────────────────────────────────────────────────
class RiskBase(BaseModel):
    risk_code: Optional[str] = None
    title: str
    description: Optional[str] = None
    category: Optional[str] = None
    likelihood: Optional[str] = None
    impact: Optional[str] = None
    mitigation: Optional[str] = None
    owner: Optional[str] = None
    owner_user_id: Optional[int] = None
    status: str = "Open"


class RiskCreate(RiskBase):
    product_id: int


class RiskUpdate(BaseModel):
    risk_code: Optional[str] = None
    title: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    likelihood: Optional[str] = None
    impact: Optional[str] = None
    mitigation: Optional[str] = None
    owner: Optional[str] = None
    owner_user_id: Optional[int] = None
    status: Optional[str] = None


class RiskOut(RiskBase):
    id: int
    product_id: int
    risk_score: Optional[int] = None
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


# ── Comment ───────────────────────────────────────────────
class CommentCreate(BaseModel):
    body: str
    mentions: Optional[List[str]] = []


class CommentOut(BaseModel):
    id: int
    product_id: int
    user_id: int
    body: str
    mentions: Optional[List[str]] = []
    created_at: datetime
    author_name: Optional[str] = None
    author_initials: Optional[str] = None

    model_config = {"from_attributes": True}


# ── Notification ──────────────────────────────────────────
class NotificationOut(BaseModel):
    id: int
    type: str
    title: str
    body: Optional[str]
    link: Optional[str]
    is_read: bool
    created_at: datetime

    model_config = {"from_attributes": True}


# ── Audit Log ─────────────────────────────────────────────
class AuditLogOut(BaseModel):
    id: int
    user_name: Optional[str]
    action_type: str
    entity_type: Optional[str]
    entity_name: Optional[str]
    field_name: Optional[str]
    old_value: Optional[str]
    new_value: Optional[str]
    detail: Optional[str]
    created_at: datetime

    model_config = {"from_attributes": True}


# ── Decision Priority ─────────────────────────────────────
class DecisionPrioritySet(BaseModel):
    priority: str


class DecisionPriorityOut(BaseModel):
    product_id: int
    priority: str
    updated_at: datetime

    model_config = {"from_attributes": True}


# ── Dashboard summary ─────────────────────────────────────
class DashboardSummary(BaseModel):
    total_products: int
    by_status: dict
    by_priority: dict
    avg_completion: float
    milestone_total: int
    milestone_done: int
    milestone_overdue: int
    total_budget: Decimal
    total_spend: Decimal
    open_risks: int
    critical_risks: int


# Forward reference resolution
ProductDetail.model_rebuild()
