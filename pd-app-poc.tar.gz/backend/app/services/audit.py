from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text


async def log_action(
    db: AsyncSession,
    user,
    action_type: str,
    entity_type: str = None,
    entity_id: int = None,
    entity_name: str = None,
    field_name: str = None,
    old_value=None,
    new_value=None,
    detail: str = None,
    ip_address: str = None,
):
    # Callers commit() before AND after calling this — we only add the
    # row to the session here, we do not commit ourselves.
    await db.execute(text("""
        INSERT INTO audit_logs
            (user_id, user_name, action_type, entity_type, entity_id,
             entity_name, field_name, old_value, new_value, detail, ip_address)
        VALUES
            (:user_id, :user_name, :action_type, :entity_type, :entity_id,
             :entity_name, :field_name, :old_value, :new_value, :detail, :ip_address)
    """), {
        "user_id":     getattr(user, "id", None),
        "user_name":   getattr(user, "name", None),
        "action_type": action_type,
        "entity_type": entity_type,
        "entity_id":   entity_id,
        "entity_name": entity_name,
        "field_name":  field_name,
        "old_value":   str(old_value) if old_value is not None else None,
        "new_value":   str(new_value) if new_value is not None else None,
        "detail":      detail,
        "ip_address":  ip_address,
    })
