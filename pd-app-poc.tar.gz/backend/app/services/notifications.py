import re
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text


async def notify_user(db: AsyncSession, user_id: int, type: str, title: str, body: str = None, link: str = None):
    await db.execute(text("""
        INSERT INTO notifications (user_id, type, title, body, link)
        VALUES (:user_id, :type, :title, :body, :link)
    """), {"user_id": user_id, "type": type, "title": title, "body": body, "link": link})


def _normalize(name: str) -> str:
    return re.sub(r"\s+", "", name).lower()


async def notify_mentions(db: AsyncSession, mentions, product_id: int, product_name: str, author_name: str):
    if not mentions:
        return
    result = await db.execute(text("SELECT id, name FROM users WHERE is_active = TRUE"))
    users = result.fetchall()

    matched_ids = set()
    for mention in mentions:
        mention_norm = _normalize(mention)
        for uid, uname in users:
            uname_norm = _normalize(uname)
            if mention_norm == uname_norm or uname_norm.startswith(mention_norm):
                matched_ids.add(uid)

    for uid in matched_ids:
        await notify_user(
            db, uid, "mention",
            title=f"{author_name} mentioned you in {product_name}",
            body=None,
            link=f"/product/{product_id}?tab=comments",
        )
