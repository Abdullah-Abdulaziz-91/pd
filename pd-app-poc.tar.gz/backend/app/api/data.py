from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from typing import Optional

from app.core.database import get_db
from app.core.security import get_current_user, require_manager_or_above, require_finance_access
from app.models.user import User
from app.schemas.schemas import (
    MilestoneCreate, MilestoneUpdate,
    FinancialCreate, FinancialUpdate,
    RiskCreate, RiskUpdate,
    CommentCreate,
)
from app.services.audit import log_action
from app.services.notifications import notify_mentions

# ══════════════════════════════════════════════════════════
# MILESTONES
# ══════════════════════════════════════════════════════════
milestones_router = APIRouter(prefix="/api/milestones", tags=["milestones"])


async def _check_product_edit(db, product_id, current_user):
    result = await db.execute(text("SELECT team_lead_user_id, name FROM products WHERE id = :id"), {"id": product_id})
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Product not found")
    if current_user.role not in ("Admin", "Manager") and row.team_lead_user_id != current_user.id:
        raise HTTPException(status_code=403, detail="You do not have permission to edit this product")
    return row


@milestones_router.get("/")
async def list_milestones(
    product_id: Optional[int] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = "SELECT m.*, p.name AS product_name FROM milestones m JOIN products p ON p.id = m.product_id"
    params = {}
    if product_id:
        query += " WHERE m.product_id = :product_id"
        params["product_id"] = product_id
    query += " ORDER BY m.due_date"
    result = await db.execute(text(query), params)
    return [dict(r._mapping) for r in result.fetchall()]


@milestones_router.post("/")
async def create_milestone(
    payload: MilestoneCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    await _check_product_edit(db, payload.product_id, current_user)
    data = payload.model_dump()
    data["created_by"] = current_user.id
    cols = list(data.keys())
    result = await db.execute(text(f"""
        INSERT INTO milestones ({', '.join(cols)}) VALUES ({', '.join(':' + c for c in cols)})
        RETURNING id
    """), data)
    new_id = result.fetchone()[0]
    await db.commit()
    await log_action(db, user=current_user, action_type="create", entity_type="milestone",
                     entity_id=new_id, entity_name=payload.name)
    await db.commit()
    return {"id": new_id, "message": "Milestone created"}


@milestones_router.patch("/{milestone_id}")
async def update_milestone(
    milestone_id: int,
    payload: MilestoneUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(text("SELECT product_id FROM milestones WHERE id = :id"), {"id": milestone_id})
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Milestone not found")
    await _check_product_edit(db, row.product_id, current_user)

    data = payload.model_dump(exclude_unset=True)
    if not data:
        raise HTTPException(status_code=400, detail="Nothing to update")
    fields = [f"{k} = :{k}" for k in data]
    data["id"] = milestone_id
    await db.execute(text(f"UPDATE milestones SET {', '.join(fields)}, updated_at = NOW() WHERE id = :id"), data)
    await db.commit()
    await log_action(db, user=current_user, action_type="update", entity_type="milestone", entity_id=milestone_id)
    await db.commit()
    return {"message": "Milestone updated"}


@milestones_router.delete("/{milestone_id}")
async def delete_milestone(
    milestone_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(text("SELECT product_id FROM milestones WHERE id = :id"), {"id": milestone_id})
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Milestone not found")
    await _check_product_edit(db, row.product_id, current_user)

    await db.execute(text("DELETE FROM milestones WHERE id = :id"), {"id": milestone_id})
    await db.commit()
    await log_action(db, user=current_user, action_type="delete", entity_type="milestone", entity_id=milestone_id)
    await db.commit()
    return {"message": "Milestone deleted"}


# ══════════════════════════════════════════════════════════
# FINANCIALS  (restricted: Admin or finance_access)
# ══════════════════════════════════════════════════════════
financials_router = APIRouter(prefix="/api/financials", tags=["financials"])


@financials_router.get("/")
async def list_financials(
    product_id: Optional[int] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_finance_access),
):
    query = "SELECT * FROM v_financials"
    params = {}
    if product_id:
        query += " WHERE product_id = :product_id"
        params["product_id"] = product_id
    query += " ORDER BY product_id"
    result = await db.execute(text(query), params)
    return [dict(r._mapping) for r in result.fetchall()]


@financials_router.post("/")
async def create_financial(
    payload: FinancialCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_finance_access),
):
    data = payload.model_dump()
    result = await db.execute(text("""
        INSERT INTO financials (product_id, approved_budget, actual_spend, forecast, quarter, notes)
        VALUES (:product_id, :approved_budget, :actual_spend, :forecast, :quarter, :notes)
        ON CONFLICT (product_id, quarter) DO UPDATE SET
            approved_budget = EXCLUDED.approved_budget,
            actual_spend    = EXCLUDED.actual_spend,
            forecast        = EXCLUDED.forecast,
            notes           = EXCLUDED.notes,
            updated_at      = NOW()
        RETURNING id
    """), data)
    new_id = result.fetchone()[0]
    await db.commit()
    await log_action(db, user=current_user, action_type="create", entity_type="financial",
                     entity_id=new_id, entity_name=f"Product {payload.product_id}")
    await db.commit()
    return {"id": new_id, "message": "Financial data saved"}


@financials_router.patch("/{financial_id}")
async def update_financial(
    financial_id: int,
    payload: FinancialUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_finance_access),
):
    data = payload.model_dump(exclude_unset=True)
    if not data:
        raise HTTPException(status_code=400, detail="Nothing to update")
    fields = [f"{k} = :{k}" for k in data]
    data["id"] = financial_id
    await db.execute(text(f"UPDATE financials SET {', '.join(fields)}, updated_at = NOW() WHERE id = :id"), data)
    await db.commit()
    await log_action(db, user=current_user, action_type="update", entity_type="financial", entity_id=financial_id)
    await db.commit()
    return {"message": "Financial data updated"}


# ══════════════════════════════════════════════════════════
# RISKS
# ══════════════════════════════════════════════════════════
risks_router = APIRouter(prefix="/api/risks", tags=["risks"])


@risks_router.get("/")
async def list_risks(
    product_id: Optional[int] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = "SELECT * FROM risks"
    params = {}
    if product_id:
        query += " WHERE product_id = :product_id"
        params["product_id"] = product_id
    query += " ORDER BY risk_score DESC NULLS LAST"
    result = await db.execute(text(query), params)
    return [dict(r._mapping) for r in result.fetchall()]


@risks_router.post("/")
async def create_risk(
    payload: RiskCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_manager_or_above),
):
    data = payload.model_dump()
    data["created_by"] = current_user.id
    cols = list(data.keys())
    result = await db.execute(text(f"""
        INSERT INTO risks ({', '.join(cols)}) VALUES ({', '.join(':' + c for c in cols)})
        RETURNING id
    """), data)
    new_id = result.fetchone()[0]
    await db.commit()
    await log_action(db, user=current_user, action_type="create", entity_type="risk",
                     entity_id=new_id, entity_name=payload.title)
    await db.commit()
    return {"id": new_id, "message": "Risk created"}


@risks_router.patch("/{risk_id}")
async def update_risk(
    risk_id: int,
    payload: RiskUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_manager_or_above),
):
    data = payload.model_dump(exclude_unset=True)
    if not data:
        raise HTTPException(status_code=400, detail="Nothing to update")
    fields = [f"{k} = :{k}" for k in data]
    data["id"] = risk_id
    await db.execute(text(f"UPDATE risks SET {', '.join(fields)}, updated_at = NOW() WHERE id = :id"), data)
    await db.commit()
    await log_action(db, user=current_user, action_type="update", entity_type="risk", entity_id=risk_id)
    await db.commit()
    return {"message": "Risk updated"}


# ══════════════════════════════════════════════════════════
# COMMENTS
# ══════════════════════════════════════════════════════════
comments_router = APIRouter(prefix="/api/comments", tags=["comments"])


@comments_router.get("/{product_id}")
async def list_comments(
    product_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(text("""
        SELECT c.id, c.product_id, c.user_id, c.body, c.mentions, c.created_at,
               u.name AS author_name, u.initials AS author_initials
        FROM comments c
        JOIN users u ON u.id = c.user_id
        WHERE c.product_id = :pid
        ORDER BY c.created_at DESC
    """), {"pid": product_id})
    return [dict(r._mapping) for r in result.fetchall()]


@comments_router.post("/{product_id}")
async def create_comment(
    product_id: int,
    payload: CommentCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    prod_result = await db.execute(text("SELECT name FROM products WHERE id = :id"), {"id": product_id})
    prod_row = prod_result.fetchone()
    if not prod_row:
        raise HTTPException(status_code=404, detail="Product not found")

    result = await db.execute(text("""
        INSERT INTO comments (product_id, user_id, body, mentions)
        VALUES (:pid, :uid, :body, :mentions)
        RETURNING id, created_at
    """), {
        "pid": product_id, "uid": current_user.id,
        "body": payload.body, "mentions": payload.mentions or [],
    })
    row = result.fetchone()

    await notify_mentions(db, payload.mentions or [], product_id, prod_row.name, current_user.name)

    await db.commit()
    await log_action(db, user=current_user, action_type="comment",
                     entity_type="product", entity_id=product_id, entity_name=prod_row.name,
                     detail=payload.body[:200])
    await db.commit()
    return {"id": row[0], "created_at": row[1].isoformat(), "message": "Comment posted"}


@comments_router.delete("/{comment_id}")
async def delete_comment(
    comment_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(text("SELECT user_id FROM comments WHERE id = :id"), {"id": comment_id})
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Comment not found")
    if current_user.role != "Admin" and row.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="You can only delete your own comments")

    await db.execute(text("DELETE FROM comments WHERE id = :id"), {"id": comment_id})
    await db.commit()
    await log_action(db, user=current_user, action_type="delete", entity_type="comment", entity_id=comment_id)
    await db.commit()
    return {"message": "Comment deleted"}
