from datetime import date as _date
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text
from typing import List, Optional
from app.core.database import get_db
from app.core.security import get_current_user, require_admin
from app.models.user import User
from app.services.audit import log_action

router = APIRouter(prefix="/api/gates", tags=["gates"])


def _parse_date(value):
    # asyncpg requires a native date object (or None) for DATE columns —
    # a raw string (including '') makes it throw deep inside the driver
    # ("'str' object has no attribute 'toordinal'"), which surfaces to the
    # browser as a generic network failure rather than a clean 4xx.
    if not value:
        return None
    if isinstance(value, _date):
        return value
    try:
        return _date.fromisoformat(value)
    except (ValueError, TypeError):
        return None


# ── Get all gates with tasks ──────────────────────────────
@router.get("/")
async def list_gates(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(text("""
        SELECT
            g.id, g.gate_number, g.name, g.description, g.weight, g.is_active,
            json_agg(
                json_build_object(
                    'id',         gt.id,
                    'task_name',  gt.task_name,
                    'workstream', gt.workstream,
                    'sort_order', gt.sort_order,
                    'is_active',  gt.is_active
                ) ORDER BY gt.sort_order
            ) FILTER (WHERE gt.id IS NOT NULL) AS tasks
        FROM gates g
        LEFT JOIN gate_tasks gt ON gt.gate_id = g.id AND gt.is_active = TRUE
        WHERE g.is_active = TRUE
        GROUP BY g.id
        ORDER BY g.gate_number
    """))
    rows = result.fetchall()
    return [dict(r._mapping) for r in rows]


# ── Get gate progress for a specific product ──────────────
@router.get("/progress/{product_id}")
async def get_product_gate_progress(
    product_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Get gate progress from view
    result = await db.execute(text("""
        SELECT * FROM v_gate_progress WHERE product_id = :pid
        ORDER BY gate_number
    """), {"pid": product_id})
    gates = [dict(r._mapping) for r in result.fetchall()]

    # Get per-task status for this product
    task_result = await db.execute(text("""
        SELECT
            gt.id          AS task_id,
            gt.gate_id,
            gt.task_name,
            gt.workstream,
            gt.sort_order,
            COALESCE(pgt.status, 'Not Started') AS status,
            pgt.owner,
            pgt.owner_user_id,
            pgt.due_date,
            pgt.completed_date,
            pgt.notes,
            pgt.id         AS product_gate_task_id
        FROM gate_tasks gt
        LEFT JOIN product_gate_tasks pgt
            ON pgt.gate_task_id = gt.id AND pgt.product_id = :pid
        WHERE gt.is_active = TRUE
        ORDER BY gt.gate_id, gt.sort_order
    """), {"pid": product_id})
    tasks = [dict(r._mapping) for r in task_result.fetchall()]

    # Group tasks by gate
    task_map = {}
    for t in tasks:
        gid = t["gate_id"]
        if gid not in task_map:
            task_map[gid] = []
        task_map[gid].append(t)

    # Attach tasks to gates
    for g in gates:
        g["tasks"] = task_map.get(g["gate_id"], [])

    return gates


# ── Update a single task status ───────────────────────────
@router.put("/task-status")
async def update_task_status(
    payload: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    product_id   = payload.get("product_id")
    gate_task_id = payload.get("gate_task_id")
    status       = payload.get("status")
    owner        = payload.get("owner")
    notes        = payload.get("notes")
    due_date     = _parse_date(payload.get("due_date"))

    if not product_id or not gate_task_id:
        raise HTTPException(status_code=400, detail="product_id and gate_task_id are required")

    # status is optional — the UI also calls this endpoint to update just the
    # owner or just the due date (updateGateTaskOwner/updateGateTaskDate in
    # gates.js), without touching status.
    valid_statuses = ["Complete", "In Progress", "Not Started", "N/A"]
    if status is not None and status not in valid_statuses:
        raise HTTPException(status_code=400, detail=f"Status must be one of: {valid_statuses}")

    # Upsert — COALESCE(:status, ...) leaves status (and completed_date)
    # untouched on conflict when status wasn't part of this particular update.
    await db.execute(text("""
        INSERT INTO product_gate_tasks
            (product_id, gate_task_id, status, owner, notes, due_date,
             completed_date, updated_by)
        VALUES
            (:pid, :tid, COALESCE(:status, 'Not Started'), :owner, :notes, :due_date,
             CASE WHEN :status = 'Complete' THEN CURRENT_DATE ELSE NULL END,
             :updated_by)
        ON CONFLICT (product_id, gate_task_id)
        DO UPDATE SET
            status         = COALESCE(:status, product_gate_tasks.status),
            owner          = COALESCE(:owner, product_gate_tasks.owner),
            notes          = COALESCE(:notes, product_gate_tasks.notes),
            due_date       = COALESCE(:due_date, product_gate_tasks.due_date),
            completed_date = CASE
                                WHEN :status = 'Complete' THEN CURRENT_DATE
                                WHEN :status IS NOT NULL THEN NULL
                                ELSE product_gate_tasks.completed_date
                             END,
            updated_by     = :updated_by,
            updated_at     = NOW()
    """), {
        "pid":        product_id,
        "tid":        gate_task_id,
        "status":     status,
        "owner":      owner,
        "notes":      notes,
        "due_date":   due_date,
        "updated_by": current_user.id,
    })

    # Get task name for audit log
    task_res = await db.execute(
        text("SELECT task_name FROM gate_tasks WHERE id = :tid"),
        {"tid": gate_task_id}
    )
    task_row = task_res.fetchone()
    task_name = task_row[0] if task_row else str(gate_task_id)

    await db.commit()
    await log_action(
        db, user=current_user,
        action_type="update",
        entity_type="gate_task",
        entity_id=gate_task_id,
        entity_name=task_name,
        field_name="status" if status else None,
        new_value=status,
        detail=f"Product {product_id} — {task_name} → {status}" if status
               else f"Product {product_id} — {task_name} updated",
    )

    await db.commit()
    return {"message": "Task updated"}


# ── Get heatmap data for overview ─────────────────────────
@router.get("/heatmap")
async def get_heatmap(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(text("""
        SELECT
            product_id,
            product_name,
            gate_number,
            gate_name,
            gate_pct,
            gate_weight,
            total_tasks,
            complete_tasks,
            in_progress_tasks,
            na_tasks,
            not_started_tasks,
            COALESCE(has_overdue_task, FALSE) AS has_overdue_task,
            COALESCE(gate_overdue, FALSE)     AS gate_overdue,
            gate_due_date,
            time_consumed_pct
        FROM v_gate_progress
        ORDER BY product_id, gate_number
    """))
    rows = [dict(r._mapping) for r in result.fetchall()]

    # Get product dates for overall RAG, with fallback to earliest gate start date
    prod_result = await db.execute(text("""
        SELECT
            p.id,
            p.start_date,
            p.readiness_date,
            MIN(pgd.start_date) AS earliest_gate_start_date
        FROM products p
        LEFT JOIN product_gate_dates pgd ON pgd.product_id = p.id
        WHERE p.is_active = TRUE
        GROUP BY p.id, p.start_date, p.readiness_date
    """))
    prod_dates = {
        r[0]: {
            "start_date": str(r[1]) if r[1] else (str(r[3]) if r[3] else None),
            "readiness_date": str(r[2]) if r[2] else None,
        }
        for r in prod_result.fetchall()
    }

    # Group by product
    products = {}
    for r in rows:
        pid = r["product_id"]
        if pid not in products:
            pd_info = prod_dates.get(pid, {})
            products[pid] = {
                "product_id":     pid,
                "product_name":   r["product_name"],
                "start_date":     pd_info.get("start_date"),
                "readiness_date": pd_info.get("readiness_date"),
                "gates":          []
            }
        products[pid]["gates"].append({
            "gate_number":       r["gate_number"],
            "gate_name":         r["gate_name"],
            "gate_pct":          float(r["gate_pct"] or 0),
            "gate_weight":       float(r["gate_weight"]),
            "total_tasks":       r["total_tasks"],
            "complete_tasks":    r["complete_tasks"],
            "in_progress_tasks": r["in_progress_tasks"],
            "na_tasks":          r["na_tasks"],
            "not_started_tasks": r["not_started_tasks"],
            "has_overdue_task":  r["has_overdue_task"],
            "gate_overdue":      r["gate_overdue"],
            "gate_due_date":     str(r["gate_due_date"]) if r["gate_due_date"] else None,
            "time_consumed_pct": float(r["time_consumed_pct"]) if r["time_consumed_pct"] else None,
        })

    return list(products.values())


# ── Admin: Update gate name/weight ────────────────────────
@router.patch("/{gate_id}")
async def update_gate(
    gate_id: int,
    payload: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    fields = []
    params = {"gid": gate_id}
    if "name" in payload:
        fields.append("name = :name")
        params["name"] = payload["name"]
    if "weight" in payload:
        fields.append("weight = :weight")
        params["weight"] = payload["weight"]
    if "description" in payload:
        fields.append("description = :description")
        params["description"] = payload["description"]

    if not fields:
        raise HTTPException(status_code=400, detail="Nothing to update")

    await db.execute(
        text(f"UPDATE gates SET {', '.join(fields)}, updated_at=NOW() WHERE id = :gid"),
        params
    )
    await db.commit()
    await log_action(db, user=current_user, action_type="update",
                     entity_type="gate", entity_id=gate_id,
                     detail=f"Gate {gate_id} updated: {payload}")
    return {"message": "Gate updated"}


# ── Admin: Add task to a gate ─────────────────────────────
@router.post("/{gate_id}/tasks")
async def add_gate_task(
    gate_id: int,
    payload: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    task_name  = payload.get("task_name", "").strip()
    workstream = payload.get("workstream", "").strip()
    if not task_name:
        raise HTTPException(status_code=400, detail="task_name is required")

    result = await db.execute(text("""
        INSERT INTO gate_tasks (gate_id, task_name, workstream, sort_order)
        VALUES (:gid, :task_name, :workstream,
                COALESCE((SELECT MAX(sort_order)+1 FROM gate_tasks WHERE gate_id=:gid), 1))
        RETURNING id
    """), {"gid": gate_id, "task_name": task_name, "workstream": workstream})

    new_id = result.fetchone()[0]
    await db.commit()
    await log_action(db, user=current_user, action_type="create",
                     entity_type="gate_task", entity_id=new_id,
                     entity_name=task_name,
                     detail=f"Task added to gate {gate_id}")
    await db.commit()
    return {"id": new_id, "message": "Task added"}


# ── Admin: Delete/deactivate a task ───────────────────────
@router.delete("/tasks/{task_id}")
async def delete_gate_task(
    task_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    await db.execute(
        text("UPDATE gate_tasks SET is_active=FALSE, updated_at=NOW() WHERE id=:tid"),
        {"tid": task_id}
    )
    await db.commit()
    await log_action(db, user=current_user, action_type="delete",
                     entity_type="gate_task", entity_id=task_id)
    return {"message": "Task removed"}


# ── Set gate due date and lead ────────────────────────────
@router.put("/date")
async def set_gate_date(
    payload: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    product_id = payload.get("product_id")
    gate_id    = payload.get("gate_id")
    due_date   = _parse_date(payload.get("due_date"))
    gate_lead  = payload.get("gate_lead") or None

    if not product_id or not gate_id:
        raise HTTPException(status_code=400, detail="product_id and gate_id required")

    start_date = _parse_date(payload.get("start_date"))
    await db.execute(text("""
        INSERT INTO product_gate_dates (product_id, gate_id, due_date, start_date, gate_lead, updated_by)
        VALUES (:pid, :gid, :due_date, :start_date, :gate_lead, :uid)
        ON CONFLICT (product_id, gate_id)
        DO UPDATE SET
            due_date   = COALESCE(EXCLUDED.due_date, product_gate_dates.due_date),
            start_date = COALESCE(EXCLUDED.start_date, product_gate_dates.start_date),
            gate_lead  = COALESCE(EXCLUDED.gate_lead, product_gate_dates.gate_lead),
            updated_by = EXCLUDED.updated_by,
            updated_at = NOW()
    """), {"pid": product_id, "gid": gate_id,
           "due_date": due_date, "start_date": start_date,
           "gate_lead": gate_lead, "uid": current_user.id})

    await db.commit()
    await log_action(db, user=current_user, action_type="update",
                     entity_type="gate", entity_id=gate_id,
                     detail=f"Gate date set: {due_date}, lead: {gate_lead}")
    await db.commit()
    return {"message": "Gate date updated"}


# ── Admin: Reorder gates ──────────────────────────────────
@router.put("/reorder")
async def reorder_gates(
    payload: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    order = payload.get("order", [])  # list of gate_ids in new order
    for i, gate_id in enumerate(order, 1):
        await db.execute(
            text("UPDATE gates SET gate_number=:num, updated_at=NOW() WHERE id=:gid"),
            {"num": i, "gid": gate_id}
        )
    await db.commit()
    await log_action(db, user=current_user, action_type="update",
                     entity_type="gate", detail=f"Gates reordered: {order}")
    await db.commit()
    return {"message": "Gates reordered"}


# ── Get team members for owner dropdown ───────────────────
@router.get("/team-members")
async def get_team_members(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(text("""
        SELECT id, name, email, role, initials
        FROM users WHERE is_active = TRUE
        ORDER BY name
    """))
    return [dict(r._mapping) for r in result.fetchall()]
