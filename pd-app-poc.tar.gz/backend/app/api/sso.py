"""
SSO (OIDC) integration point — see SSO_SETUP.md for how to activate this.

This file is intentionally a *scaffold*, not a working integration: there is
no real identity provider configured yet. Once real OIDC values exist
(SSO_ENABLED=true + the four OIDC_* env vars), replace the two TODO blocks
below with the real authorization-code exchange. Nothing else in the app
needs to change — /login (auth.py) and this router both end by calling the
same create_access_token(), so every downstream permission check treats an
SSO session identically to a password session.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.config import settings
from app.core.database import get_db
from app.core.security import create_access_token
from app.models.user import User
from app.services.audit import log_action

router = APIRouter(prefix="/api/auth/sso", tags=["sso"])


@router.get("/status")
async def sso_status():
    """Frontend calls this on the login screen to decide whether to show
    the 'Sign in with SSO' button at all."""
    return {"enabled": settings.SSO_ENABLED}


@router.get("/login")
async def sso_login():
    """
    Real implementation (once configured): build the IdP authorization URL
    and redirect the browser there.

        from authlib.integrations.starlette_client import OAuth
        oauth = OAuth()
        oauth.register(
            name="oidc",
            server_metadata_url=f"{settings.OIDC_ISSUER}/.well-known/openid-configuration",
            client_id=settings.OIDC_CLIENT_ID,
            client_secret=settings.OIDC_CLIENT_SECRET,
            client_kwargs={"scope": "openid email profile"},
        )
        return await oauth.oidc.authorize_redirect(request, settings.OIDC_REDIRECT_URI)

    (Needs starlette's SessionMiddleware registered in main.py for the
    state/nonce round-trip — not added yet since there's nothing to
    protect until this is turned on.)
    """
    if not settings.SSO_ENABLED:
        raise HTTPException(
            status_code=501,
            detail="SSO is not configured. See SSO_SETUP.md to activate it.",
        )
    raise HTTPException(status_code=501, detail="SSO login not yet implemented.")


@router.post("/callback")
async def sso_callback(db: AsyncSession = Depends(get_db)):
    """
    Real implementation (once configured), in order:
      1. Exchange the authorization code for tokens with the IdP.
      2. Validate the ID token's signature against the IdP's JWKS and its
         issuer/audience/expiry claims.
      3. Read `sub` (stable subject id) and `email` from the validated claims.
      4. JIT-provision the local user record — this is the part worth
         keeping even after the real OIDC exchange is wired in:

            result = await db.execute(select(User).where(User.sso_subject == sub))
            user = result.scalar_one_or_none()
            if not user:
                result = await db.execute(select(User).where(User.email == email))
                user = result.scalar_one_or_none()
                if user:
                    user.sso_subject, user.auth_provider = sub, "oidc"
                else:
                    user = User(email=email, name=claims.get("name", email),
                                password_hash=None, auth_provider="oidc",
                                sso_subject=sub, role="Team Lead")
                    db.add(user)
                await db.commit()
                await db.refresh(user)
            if not user.is_active:
                raise HTTPException(status_code=403, detail="Account is deactivated")

      5. Issue our own app JWT exactly like /api/auth/login does, so
         everything downstream (get_current_user, role checks, audit log)
         works unchanged:

            token = create_access_token(user.id)
            await log_action(db, user=user, action_type="login",
                             entity_type="user", entity_id=user.id, detail="SSO login")
            await db.commit()
            return TokenResponse(access_token=token, user=UserOut.model_validate(user))
    """
    if not settings.SSO_ENABLED:
        raise HTTPException(
            status_code=501,
            detail="SSO is not configured. See SSO_SETUP.md to activate it.",
        )
    raise HTTPException(status_code=501, detail="SSO callback not yet implemented.")
