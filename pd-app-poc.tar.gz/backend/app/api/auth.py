from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.database import get_db
from app.core.security import (
    get_current_user, verify_password, hash_password, create_access_token,
)
from app.models.user import User
from app.schemas.schemas import LoginRequest, TokenResponse, UserOut, UserUpdate, PasswordChange
from app.services.audit import log_action

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/login", response_model=TokenResponse)
async def login(payload: LoginRequest, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(User).where(User.email == payload.email, User.is_active == True)  # noqa: E712
    )
    user = result.scalar_one_or_none()
    # SSO-provisioned accounts have no local password_hash to check against —
    # they must sign in via /api/auth/sso, not this endpoint.
    if not user or not user.password_hash or not verify_password(payload.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token(user.id)
    await log_action(db, user=user, action_type="login", entity_type="user", entity_id=user.id)
    await db.commit()

    return TokenResponse(access_token=token, user=UserOut.model_validate(user))


@router.post("/logout")
async def logout(current_user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    await log_action(db, user=current_user, action_type="logout", entity_type="user", entity_id=current_user.id)
    await db.commit()
    return {"message": "Logged out"}


@router.get("/me", response_model=UserOut)
async def me(current_user: User = Depends(get_current_user)):
    return current_user


@router.put("/me", response_model=UserOut)
async def update_me(
    payload: UserUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if payload.name is not None:
        current_user.name = payload.name
    if payload.department is not None:
        current_user.department = payload.department
    if payload.initials is not None:
        current_user.initials = payload.initials
    await db.commit()
    await db.refresh(current_user)
    return current_user


@router.post("/change-password")
async def change_password(
    payload: PasswordChange,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if not current_user.password_hash:
        raise HTTPException(status_code=400, detail="SSO accounts don't have a local password to change")
    if not verify_password(payload.current_password, current_user.password_hash):
        raise HTTPException(status_code=400, detail="Current password is incorrect")
    current_user.password_hash = hash_password(payload.new_password)
    await db.commit()
    await log_action(db, user=current_user, action_type="update",
                     entity_type="user", entity_id=current_user.id,
                     detail="Password changed")
    await db.commit()
    return {"message": "Password updated"}
