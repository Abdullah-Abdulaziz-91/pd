import io
from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from typing import Optional

from app.core.database import get_db
from app.core.security import get_current_user, require_admin, hash_password
from app.models.user import User
from app.schemas.schemas import UserCreate, UserOut
from app.services.audit import log_action

# ══════════════════════════════════════════════════════════
# USERS  (Admin only)
# ══════════════════════════════════════════════════════════
users_router = APIRouter(prefix="/api/users", tags=["users"])


@users_router.get("/", response_model=list[UserOut])
async def list_users(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    result = await db.execute(text("""
        SELECT id, email, name, role, department, initials, finance_access, is_active, auth_provider
        FROM users ORDER BY name
    """))
    return [dict(r._mapping) for r in result.fetchall()]


@users_router.post("/")
async def create_user(
    payload: UserCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    existing = await db.execute(text("SELECT id FROM users WHERE email = :email"), {"email": payload.email})
    if existing.fetchone():
        raise HTTPException(status_code=400, detail="A user with this email already exists")

    result = await db.execute(text("""
        INSERT INTO users (email, name, password_hash, role, department, initials)
        VALUES (:email, :name, :password_hash, :role, :department, :initials)
        RETURNING id
    """), {
        "email": payload.email, "name": payload.name,
        "password_hash": hash_password(payload.password),
        "role": payload.role, "department": payload.department,
        "initials": payload.initials,
    })
    new_id = result.fetchone()[0]
    await db.commit()
    await log_action(db, user=current_user, action_type="create", entity_type="user",
                     entity_id=new_id, entity_name=payload.name)
    await db.commit()
    return {"id": new_id, "message": "User created"}


@users_router.patch("/{user_id}/role")
async def change_role(
    user_id: int,
    payload: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    role = payload.get("role")
    if role not in ("Admin", "Manager", "Team Lead"):
        raise HTTPException(status_code=400, detail="Invalid role")
    await db.execute(text("UPDATE users SET role = :role, updated_at = NOW() WHERE id = :id"),
                     {"role": role, "id": user_id})
    await db.commit()
    await log_action(db, user=current_user, action_type="update", entity_type="user",
                     entity_id=user_id, field_name="role", new_value=role)
    await db.commit()
    return {"message": "Role updated"}


@users_router.delete("/{user_id}")
async def deactivate_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    if user_id == current_user.id:
        raise HTTPException(status_code=400, detail="You cannot deactivate your own account")
    await db.execute(text("UPDATE users SET is_active = FALSE, updated_at = NOW() WHERE id = :id"), {"id": user_id})
    await db.commit()
    await log_action(db, user=current_user, action_type="update", entity_type="user",
                     entity_id=user_id, detail="Deactivated")
    await db.commit()
    return {"message": "User deactivated"}


@users_router.post("/{user_id}/activate")
async def activate_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    result = await db.execute(
        text("UPDATE users SET is_active = TRUE, updated_at = NOW() WHERE id = :id RETURNING id"),
        {"id": user_id}
    )
    if not result.fetchone():
        raise HTTPException(status_code=404, detail="User not found")
    await db.commit()
    await log_action(db, user=current_user, action_type="update", entity_type="user",
                     entity_id=user_id, detail="Activated")
    await db.commit()
    return {"message": "User activated"}


# ══════════════════════════════════════════════════════════
# NOTIFICATIONS
# ══════════════════════════════════════════════════════════
notif_router = APIRouter(prefix="/api/notifications", tags=["notifications"])


@notif_router.get("/")
async def list_notifications(
    unread_only: bool = Query(False),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = "SELECT * FROM notifications WHERE user_id = :uid"
    if unread_only:
        query += " AND is_read = FALSE"
    query += " ORDER BY created_at DESC LIMIT 50"
    result = await db.execute(text(query), {"uid": current_user.id})
    return [dict(r._mapping) for r in result.fetchall()]


@notif_router.get("/unread-count")
async def unread_count(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        text("SELECT COUNT(*) FROM notifications WHERE user_id = :uid AND is_read = FALSE"),
        {"uid": current_user.id}
    )
    return {"count": result.scalar()}


@notif_router.post("/mark-read")
async def mark_all_read(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    await db.execute(
        text("UPDATE notifications SET is_read = TRUE WHERE user_id = :uid AND is_read = FALSE"),
        {"uid": current_user.id}
    )
    await db.commit()
    return {"message": "All notifications marked as read"}


@notif_router.post("/{notification_id}/read")
async def mark_read(
    notification_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        text("UPDATE notifications SET is_read = TRUE WHERE id = :id AND user_id = :uid RETURNING id"),
        {"id": notification_id, "uid": current_user.id}
    )
    if not result.fetchone():
        raise HTTPException(status_code=404, detail="Notification not found")
    await db.commit()
    return {"message": "Marked as read"}


# ══════════════════════════════════════════════════════════
# AUDIT LOGS  (Admin only)
# ══════════════════════════════════════════════════════════
logs_router = APIRouter(prefix="/api/logs", tags=["logs"])


@logs_router.get("/")
async def list_logs(
    limit: int = Query(200, le=1000),
    entity_type: Optional[str] = Query(None),
    user_id: Optional[int] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    query = "SELECT * FROM audit_logs WHERE 1=1"
    params = {"limit": limit}
    if entity_type:
        query += " AND entity_type = :entity_type"
        params["entity_type"] = entity_type
    if user_id:
        query += " AND user_id = :user_id"
        params["user_id"] = user_id
    query += " ORDER BY created_at DESC LIMIT :limit"
    result = await db.execute(text(query), params)
    return [dict(r._mapping) for r in result.fetchall()]


# ══════════════════════════════════════════════════════════
# EXCEL IMPORT  (Admin only)
# ══════════════════════════════════════════════════════════
excel_router = APIRouter(prefix="/api/import", tags=["import"])


@excel_router.post("/excel")
async def import_excel(
    file: UploadFile = File(...),
    current_user: User = Depends(require_admin),
):
    if not file.filename.endswith((".xlsx", ".xlsm")):
        raise HTTPException(status_code=400, detail="Only .xlsx files are supported")

    try:
        from openpyxl import load_workbook
    except ImportError:
        raise HTTPException(status_code=500, detail="openpyxl is not installed on the server")

    contents = await file.read()
    wb = load_workbook(io.BytesIO(contents), read_only=True)
    sheet = wb.active
    row_count = max(0, sheet.max_row - 1)  # minus header row

    return {
        "message": "File parsed (import into the database is not yet implemented)",
        "rows_found": row_count,
        "sheet_name": sheet.title,
    }
