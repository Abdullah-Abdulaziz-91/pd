from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from app.core.database import get_db
from app.core.security import get_current_user, require_manager_or_above
from app.models.user import User
from app.services.audit import log_action

router = APIRouter(prefix="/api/partnerships", tags=["partnerships"])


@router.get("/{product_id}")
async def list_partnerships(
    product_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(text("""
        SELECT p.*, u.name AS created_by_name
        FROM partnerships p
        LEFT JOIN users u ON u.id = p.created_by
        WHERE p.product_id = :pid
        ORDER BY p.type, p.partner_name
    """), {"pid": product_id})
    return [dict(r._mapping) for r in result.fetchall()]


@router.post("/{product_id}")
async def create_partnership(
    product_id: int,
    payload: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_manager_or_above),
):
    result = await db.execute(text("""
        INSERT INTO partnerships
            (product_id, partner_name, type, status,
             contact_name, contact_email, description, notes, created_by)
        VALUES
            (:pid, :name, :type, :status,
             :contact_name, :contact_email, :description, :notes, :uid)
        RETURNING id
    """), {
        "pid":           product_id,
        "name":          payload.get("partner_name", ""),
        "type":          payload.get("type", "Other"),
        "status":        payload.get("status", "Partner Identified"),
        "contact_name":  payload.get("contact_name"),
        "contact_email": payload.get("contact_email"),
        "description":   payload.get("description"),
        "notes":         payload.get("notes"),
        "uid":           current_user.id,
    })
    new_id = result.fetchone()[0]
    await db.commit()
    await log_action(db, user=current_user, action_type="create",
                     entity_type="partnership", entity_id=new_id,
                     entity_name=payload.get("partner_name"),
                     detail=f"Partnership added to product {product_id}")
    await db.commit()
    return {"id": new_id, "message": "Partnership created"}


@router.patch("/{partnership_id}")
async def update_partnership(
    partnership_id: int,
    payload: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_manager_or_above),
):
    allowed = ["partner_name","type","status","contact_name","contact_email","description","notes"]
    fields  = [f"{k} = :{k}" for k in allowed if k in payload]
    if not fields:
        raise HTTPException(status_code=400, detail="Nothing to update")
    params = {k: payload[k] for k in allowed if k in payload}
    params["pid"] = partnership_id
    await db.execute(
        text(f"UPDATE partnerships SET {', '.join(fields)}, updated_at=NOW() WHERE id=:pid"),
        params
    )
    await db.commit()
    await log_action(db, user=current_user, action_type="update",
                     entity_type="partnership", entity_id=partnership_id)
    await db.commit()
    return {"message": "Updated"}


@router.delete("/{partnership_id}")
async def delete_partnership(
    partnership_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_manager_or_above),
):
    await db.execute(
        text("DELETE FROM partnerships WHERE id=:pid"),
        {"pid": partnership_id}
    )
    await db.commit()
    await log_action(db, user=current_user, action_type="delete",
                     entity_type="partnership", entity_id=partnership_id)
    await db.commit()
    return {"message": "Deleted"}
