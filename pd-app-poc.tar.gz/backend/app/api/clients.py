from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from app.core.database import get_db
from app.core.security import get_current_user, require_manager_or_above
from app.models.user import User
from app.services.audit import log_action

router = APIRouter(prefix="/api/clients", tags=["clients"])


@router.get("/")
async def list_clients(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(text("""
        SELECT c.id, c.name, c.is_active, c.created_at,
               COUNT(pc.product_id) AS product_count
        FROM clients c
        LEFT JOIN product_clients pc ON pc.client_id = c.id
        WHERE c.is_active = TRUE
        GROUP BY c.id
        ORDER BY c.name
    """))
    return [dict(r._mapping) for r in result.fetchall()]


@router.post("/")
async def create_client(
    payload: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_manager_or_above),
):
    name = payload.get("name", "").strip()
    if not name:
        raise HTTPException(status_code=400, detail="name is required")
    result = await db.execute(text("""
        INSERT INTO clients (name, created_by)
        VALUES (:name, :uid)
        ON CONFLICT (name) DO UPDATE SET is_active = TRUE
        RETURNING id, name
    """), {"name": name, "uid": current_user.id})
    row = result.fetchone()
    await db.commit()
    await log_action(db, user=current_user, action_type="create",
                     entity_type="client", entity_id=row[0], entity_name=name)
    return {"id": row[0], "name": row[1]}


@router.delete("/{client_id}")
async def delete_client(
    client_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_manager_or_above),
):
    await db.execute(
        text("UPDATE clients SET is_active=FALSE WHERE id=:id"),
        {"id": client_id}
    )
    await db.commit()
    return {"message": "Client removed"}


# ── Product-client links ──────────────────────────────────
@router.get("/product/{product_id}")
async def get_product_clients(
    product_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(text("""
        SELECT c.id, c.name
        FROM clients c
        JOIN product_clients pc ON pc.client_id = c.id
        WHERE pc.product_id = :pid AND c.is_active = TRUE
        ORDER BY c.name
    """), {"pid": product_id})
    return [dict(r._mapping) for r in result.fetchall()]


@router.post("/product/{product_id}/{client_id}")
async def link_client(
    product_id: int,
    client_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_manager_or_above),
):
    await db.execute(text("""
        INSERT INTO product_clients (product_id, client_id)
        VALUES (:pid, :cid)
        ON CONFLICT DO NOTHING
    """), {"pid": product_id, "cid": client_id})
    await db.commit()
    await log_action(db, user=current_user, action_type="update",
                     entity_type="product", entity_id=product_id,
                     detail=f"Client {client_id} linked")
    await db.commit()
    return {"message": "Client linked"}


@router.delete("/product/{product_id}/{client_id}")
async def unlink_client(
    product_id: int,
    client_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_manager_or_above),
):
    await db.execute(text("""
        DELETE FROM product_clients
        WHERE product_id=:pid AND client_id=:cid
    """), {"pid": product_id, "cid": client_id})
    await db.commit()
    return {"message": "Client unlinked"}


# ── Summary for overview ──────────────────────────────────
@router.get("/summary")
async def client_summary(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(text("""
        SELECT
            c.id,
            c.name,
            COUNT(DISTINCT pc.product_id) AS product_count,
            ARRAY_AGG(p.name ORDER BY p.name) AS products
        FROM clients c
        JOIN product_clients pc ON pc.client_id = c.id
        JOIN products p ON p.id = pc.product_id AND p.is_active = TRUE
        WHERE c.is_active = TRUE
        GROUP BY c.id, c.name
        ORDER BY product_count DESC, c.name
    """))
    return [dict(r._mapping) for r in result.fetchall()]
