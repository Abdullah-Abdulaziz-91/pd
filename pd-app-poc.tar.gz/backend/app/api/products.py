from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from app.core.database import get_db
from app.core.security import get_current_user, require_manager_or_above, require_admin
from app.models.user import User
from app.schemas.schemas import ProductCreate, ProductUpdate, DashboardSummary
from app.services.audit import log_action

router = APIRouter(prefix="/api/products", tags=["products"])

_PRODUCT_COLUMNS = """
    id, product_code, name, description, status, priority, completion,
    action_required, team_lead, team_lead_user_id, start_date, readiness_date,
    pipeline_value, customer_count, notes, is_active, created_by, created_at, updated_at
"""


@router.get("/")
async def list_products(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(text(f"""
        SELECT {_PRODUCT_COLUMNS} FROM products
        WHERE is_active = TRUE
        ORDER BY name
    """))
    return [dict(r._mapping) for r in result.fetchall()]


@router.get("/summary", response_model=DashboardSummary)
async def products_summary(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    prod_res = await db.execute(text("""
        SELECT status, priority, completion FROM products WHERE is_active = TRUE
    """))
    products = prod_res.fetchall()

    by_status, by_priority = {}, {}
    total_completion = 0
    for status_, priority, completion in products:
        by_status[status_] = by_status.get(status_, 0) + 1
        by_priority[priority] = by_priority.get(priority, 0) + 1
        total_completion += completion or 0
    total_products = len(products)
    avg_completion = round(total_completion / total_products, 1) if total_products else 0.0

    ms_res = await db.execute(text("""
        SELECT
            COUNT(*) AS total,
            COUNT(*) FILTER (WHERE status = 'Done') AS done,
            COUNT(*) FILTER (WHERE status != 'Done' AND due_date < CURRENT_DATE) AS overdue
        FROM milestones
    """))
    ms_total, ms_done, ms_overdue = ms_res.fetchone()

    fin_res = await db.execute(text("""
        SELECT COALESCE(SUM(approved_budget),0), COALESCE(SUM(actual_spend),0) FROM financials
    """))
    total_budget, total_spend = fin_res.fetchone()

    risk_res = await db.execute(text("""
        SELECT
            COUNT(*) FILTER (WHERE status = 'Open') AS open_risks,
            COUNT(*) FILTER (WHERE status = 'Open' AND impact = 'Critical') AS critical_risks
        FROM risks
    """))
    open_risks, critical_risks = risk_res.fetchone()

    return DashboardSummary(
        total_products=total_products,
        by_status=by_status,
        by_priority=by_priority,
        avg_completion=avg_completion,
        milestone_total=ms_total or 0,
        milestone_done=ms_done or 0,
        milestone_overdue=ms_overdue or 0,
        total_budget=total_budget or 0,
        total_spend=total_spend or 0,
        open_risks=open_risks or 0,
        critical_risks=critical_risks or 0,
    )


@router.get("/{product_id}")
async def get_product(
    product_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        text(f"SELECT {_PRODUCT_COLUMNS} FROM products WHERE id = :id"),
        {"id": product_id}
    )
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Product not found")
    return dict(row._mapping)


@router.post("/")
async def create_product(
    payload: ProductCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_manager_or_above),
):
    existing = await db.execute(
        text("SELECT id FROM products WHERE product_code = :code"),
        {"code": payload.product_code}
    )
    if existing.fetchone():
        raise HTTPException(status_code=400, detail=f"Product code '{payload.product_code}' already exists")

    data = payload.model_dump()
    data["created_by"] = current_user.id
    columns = list(data.keys())
    result = await db.execute(text(f"""
        INSERT INTO products ({', '.join(columns)})
        VALUES ({', '.join(':' + c for c in columns)})
        RETURNING id
    """), data)
    new_id = result.fetchone()[0]
    await db.commit()
    await log_action(db, user=current_user, action_type="create",
                     entity_type="product", entity_id=new_id, entity_name=payload.name)
    await db.commit()
    return {"id": new_id, "message": "Product created"}


async def _get_product_row(db, product_id):
    result = await db.execute(
        text("SELECT id, name, team_lead_user_id FROM products WHERE id = :id"),
        {"id": product_id}
    )
    return result.fetchone()


async def _check_edit_permission(product_row, current_user):
    if current_user.role in ("Admin", "Manager"):
        return
    if product_row and product_row.team_lead_user_id == current_user.id:
        return
    raise HTTPException(status_code=403, detail="You do not have permission to edit this product")


@router.patch("/{product_id}")
async def update_product(
    product_id: int,
    payload: ProductUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    product_row = await _get_product_row(db, product_id)
    if not product_row:
        raise HTTPException(status_code=404, detail="Product not found")
    await _check_edit_permission(product_row, current_user)

    data = {k: v for k, v in payload.model_dump(exclude_unset=True).items()}
    if not data:
        raise HTTPException(status_code=400, detail="Nothing to update")

    if "product_code" in data:
        conflict = await db.execute(
            text("SELECT id FROM products WHERE product_code = :code AND id != :id"),
            {"code": data["product_code"], "id": product_id}
        )
        if conflict.fetchone():
            raise HTTPException(status_code=400, detail=f"Product code '{data['product_code']}' already exists")

    fields = [f"{k} = :{k}" for k in data]
    data["id"] = product_id
    await db.execute(
        text(f"UPDATE products SET {', '.join(fields)}, updated_at = NOW() WHERE id = :id"),
        data
    )
    await db.commit()
    await log_action(db, user=current_user, action_type="update",
                     entity_type="product", entity_id=product_id, entity_name=product_row.name,
                     detail=f"Fields updated: {list(payload.model_dump(exclude_unset=True).keys())}")
    await db.commit()
    return {"message": "Product updated"}


@router.put("/{product_id}/priority")
async def set_product_priority(
    product_id: int,
    payload: dict,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_manager_or_above),
):
    priority = payload.get("priority")
    if priority not in ("Critical", "High", "Medium", "Low"):
        raise HTTPException(status_code=400, detail="Invalid priority")
    await db.execute(
        text("UPDATE products SET priority = :priority, updated_at = NOW() WHERE id = :id"),
        {"priority": priority, "id": product_id}
    )
    await db.commit()
    await log_action(db, user=current_user, action_type="update",
                     entity_type="product", entity_id=product_id,
                     field_name="priority", new_value=priority)
    await db.commit()
    return {"message": "Priority updated"}


@router.delete("/{product_id}")
async def delete_product(
    product_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin),
):
    result = await db.execute(text("SELECT id, name FROM products WHERE id = :id"), {"id": product_id})
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Product not found")

    await db.execute(text("DELETE FROM products WHERE id = :id"), {"id": product_id})
    await db.commit()
    await log_action(db, user=current_user, action_type="delete",
                     entity_type="product", entity_id=product_id, entity_name=row.name)
    await db.commit()
    return {"message": "Product deleted"}
