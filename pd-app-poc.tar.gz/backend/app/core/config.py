from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    DATABASE_URL: str
    SYNC_DATABASE_URL: str = ""
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480
    APP_ENV: str = "development"
    FRONTEND_URL: str = "http://localhost:8080"

    # ── SSO (OIDC) — see SSO_SETUP.md ────────────────────────
    # All blank/False by default so the feature stays dormant until a real
    # identity provider's values are dropped in here — no code changes
    # needed to go live, just these four env vars + flipping the flag.
    SSO_ENABLED: bool = False
    OIDC_ISSUER: str = ""          # e.g. https://login.microsoftonline.com/{tenant-id}/v2.0
    OIDC_CLIENT_ID: str = ""
    OIDC_CLIENT_SECRET: str = ""
    OIDC_REDIRECT_URI: str = ""    # e.g. https://your-backend/api/auth/sso/callback

    class Config:
        env_file = ".env"


settings = Settings()
