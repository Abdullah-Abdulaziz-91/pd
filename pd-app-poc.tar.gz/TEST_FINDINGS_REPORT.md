# PD Dashboard — Functional Test Findings Report

> **Status: historical snapshot.** This was the first QA pass, run right
> after the missing backend/frontend files were reconstructed (see
> `MISSING_IMPLEMENTATION_SPEC.md`). Every "Broken/non-functional" item
> below was fixed in the same session — for the current, up-to-date list of
> what was found and fixed (including everything after this report, like the
> Graphite/Daylight theming work and the gates.py date-handling bug), see
> `BUGS_AND_FIXES.md`. Kept here as the original evidence/methodology, not
> as the current state of the app.

Tested locally: FastAPI backend (reconstructed, see `MISSING_IMPLEMENTATION_SPEC.md`) +
Postgres 15 + static frontend. Every finding below was verified by performing
the UI action and independently querying the database, unless noted otherwise.

---

## 0. Setup blocker (resolved)

The delivered package was missing ~40% of the backend (`app/core/config.py`,
`database.py`, `security.py`, `app/models/user.py`, `app/services/audit.py`,
`notifications.py`, `app/api/auth.py`, `products.py`, `data.py`, `admin.py`,
`requirements.txt`) and 4 frontend pages (`financials.js`, `decisions.js`,
`team.js`, `logs.js`) — entire files absent, not bugs. `main.py` imported all
of these unconditionally, so the app could not boot at all. These were
reconstructed from `database/schema.sql`, `schemas.py`, the 3 existing
routers, and the frontend's own API contract (see spec doc for exact
behavior). The **default admin credential
(`pd.admin@aramcodigital.com` / `admin`) is only live in this local test DB** —
confirm it has been rotated everywhere else it may have been seeded.

---

## 1. Broken / non-functional (found, and fixed during this pass)

These were **pre-existing bugs in the delivered frontend code**, not introduced
by the reconstruction above. All three are now fixed; details included so the
root cause doesn't need re-discovery.

### 1.1 Every confirm dialog in the app was non-functional
**File:** `frontend/js/components/modals.js`, `Modals.confirm()`
**Symptom:** Archive Product, Delete Product, Delete Milestone, Deactivate
User, Remove Gate Task, and Remove Partnership all showed their confirmation
modal correctly, but clicking the confirm button did nothing to the database.
**Root cause:** `onclick="Modals.close();(${onConfirm.toString()})()"` —
the callback was serialized to a string via `.toString()` and re-injected
into an inline `onclick` attribute. Inline event handlers execute in global
scope, so any closure variable the callback referenced (e.g. `id`, `p`) was
lost, causing `ReferenceError`s inside an async function (silently swallowed
as an unhandled promise rejection — no console error surfaced, no toast
shown). Confirmed via network log: repeated `PATCH /api/products/ → 405`
(missing id in the URL).
**Fix applied:** `Modals.confirm()` now stores the callback directly
(`Modals._onConfirm`) and the button calls `Modals._confirmNow()`, preserving
the closure. Verified: Archive now correctly sets `is_active=false`, Delete
now correctly removes the row.

### 1.2 Stage-pipeline click-to-change, @mention autocomplete, and client
manager were all dead code
**File:** `frontend/js/pages/product.js`
**Symptom:** Clicking a stage dot on the Product Overview did nothing;
typing `@` in a comment did nothing; clicking "Manage" or "Add a client"
under Clients did nothing.
**Root cause:** `window.handleMentionInput = ...`, `window.selectStageForChange = ...`,
`window.openClientManager = ...` (and 3 others) were written **after** a
`return {...}` statement inside the `Pages.Product` IIFE — unreachable code,
never executed, so none of these globals were ever attached to `window`,
even though the HTML calls them as bare globals via `onclick`.
**Fix applied:** moved all `window.x = ...` assignments before the `return`.
Verified: stage-pipeline confirm now updates `products.status` +
`updated_at`; Manage Clients modal now opens and create/link/unlink all work.

### 1.3 Adding/editing Financial data failed whenever an optional numeric
field was left blank
**File:** `frontend/js/pages/product.js`, `openEditFinancials()`
**Symptom:** "Add Financial Data" modal stayed open with no visible error
after clicking Save, if Forecast (or Actual Spend) was left blank.
**Root cause:** the generic `Modals.form` submit collects every field as a
trimmed string, including `""` for untouched optional fields, and this
handler — unlike `openAddProduct`/`openEditProduct`, which do sanitize —
passed the raw data straight to the API. The backend correctly rejects an
empty string against a `Decimal` field (422 `decimal_parsing`).
**Fix applied:** blank `approved_budget`/`actual_spend`/`forecast` now
default to `0` before submit. Verified: entry now persists correctly.

### 1.4 Any user without finance access saw a completely broken app
**File:** `frontend/js/router.js`, `Router.loadAll()`
**Symptom:** For any Team Lead, or any Manager not explicitly granted
finance access (i.e. most non-Admin accounts by default), the Executive
Overview showed **0 Total Products, 0% Avg Completion, empty everything** —
while the gate heatmap on the *same page* (a separate fetch) correctly showed
real data. Every subsequent navigation silently re-fetched and failed again.
**Root cause:** `loadAll()` fetched products/milestones/**financials**/risks/summary
via `Promise.all()`. The financials endpoint correctly returns 403 for users
without finance access — but because `Promise.all` is all-or-nothing, that
one 403 discarded the other four calls' results too, even though they had
already succeeded over the network. `state.loaded` also got stuck `false`
forever, so the failure repeated on every click.
**Fix applied:** switched to `Promise.allSettled`; each of the 5 results is
now applied independently, defaulting a failed one to empty. Verified with a
clean session as a Manager account without finance access: Overview now
shows correct KPIs (1 product, 35% completion, 1 open risk), Financials page
correctly stays locked, and the underlying data leak check (see 2.1) confirmed
no financial figures actually render anywhere for that user.

---

## 2. Partially working — bugs, missing validation, or design gaps

### 2.1 Gate weight "must sum to 100%" is enforced client-side only
**File:** `frontend/js/pages/settings.js` (`saveGateWeights`) vs.
`backend/app/api/gates.py` (`PATCH /api/gates/{id}`)
The Settings UI correctly blocks saving if the total isn't 100%. A direct API
call (`PATCH /api/gates/1 {"weight": 90}`) succeeds with no validation,
producing gate weights that don't sum to 100% and silently skewing every
product's Overall score. Needs a server-side check (sum of all *other*
gates' weights + the new value == 100) before accepting the update.

### 2.2 `DashboardSummary` (`GET /api/products/summary`) is not gated by
finance access
`total_budget`/`total_spend` are included in the summary response returned to
*any* authenticated user, including those without finance access. The
Executive Overview UI happens not to render these two fields directly (it
recomputes its Financial Snapshot from the separately-restricted
`/api/financials/` list, which correctly returns empty), so there's no
visible leak in the current UI — but the raw numbers are sitting in
`Router.state.summary` in the browser, inspectable via devtools. Recommend
either restricting these two fields to finance-access users at the API layer,
or explicitly documenting that portfolio-level totals are intentionally not
finance-restricted (only per-product/per-quarter detail is).

### 2.3 Deleting a Client silently orphans its product links
**File:** `backend/app/api/clients.py`, `DELETE /api/clients/{id}`
This is a soft delete (`is_active=false`). It does **not** touch
`product_clients`, so any product still linked to that client just has the
client silently vanish from its Clients section (the join filters on
`is_active=TRUE`) — no warning, no cascade, no orphan cleanup. Separately:
**there is no "Delete Client" button anywhere in the current UI** — the
Manage Clients modal only exposes unlink (×) and create. The delete endpoint
is only reachable by a direct API call today, so this is a low-severity gap,
but worth deciding intentionally (block delete while linked / cascade-unlink
/ leave as-is) rather than leaving it implicit.

### 2.4 Excel import has no UI entry point
`api.js` defines `API.importExcel(file)` and the backend now implements
`POST /api/import/excel` (parses the sheet, returns a row count) — but no
button in any page calls it. Functionally inert from a user's perspective.

### 2.5 `product.js` contains dead/shadowed code (cosmetic, not a bug today)
- `tabPartnerships(product)` in `product.js` is a fully-built placeholder that
  is never called (the real Partnerships tab renders via `renderPartnershipsTab`
  in `gates.js`). Safe to delete.
- `product.js`'s own `openAddPartnership(type, productId)` is shadowed by a
  same-named **global** function in `gates.js` with a swapped argument order,
  which wins purely because `gates.js` loads after `product.js` in
  `index.html`. It happens to work today only by accident of script order.

---

## 3. Working as expected (confirmed via UI action → DB row)

| Flow | Verified |
|---|---|
| Login (default admin) | ✅ token issued, `audit_logs` row written |
| Create Product | ✅ row persisted with correct fields, `created_by` set |
| Edit Product (completion %, pipeline value) | ✅ persisted, `updated_at` bumped |
| Archive Product (after fix) | ✅ soft delete, `is_active=false`, row preserved |
| Delete Product (after fix) | ✅ true hard delete, row removed; distinct from Archive |
| Create Client inline from Product Overview (after fix) | ✅ client row + `product_clients` link both created |
| Create Partnership | ✅ persisted with correct type/status/contact |
| Create Risk | ✅ persisted; `risk_score` trigger correctly computed (e.g. High×Critical = 12) |
| Gate task status update | ✅ persisted; `completed_date` auto-set on "Complete" |
| Editable stage pipeline click → confirm (after fix) | ✅ `products.status` updated |
| Create user (Settings → Manage Users, Admin only) | ✅ persisted, bcrypt-hashed password |
| Post comment with @mention | ✅ comment + `mentions[]` persisted |
| @mention → notification (after verifying `notify_mentions`) | ✅ real `notifications` row created for the mentioned user, correct title |
| Notification bell — real data, mark-read | ✅ badge shows live unread count, click marks `is_read=true` in DB |
| Add Financial entry (after fix) | ✅ persisted, `v_financials` view correctly computes utilization %/variance |
| Financials access control | ✅ backend correctly 403s users without finance access; frontend correctly shows lock screen |
| Gate weight edit — valid case (sums to 100%) | ✅ persisted correctly |
| Executive Overview KPIs / heatmap / Gantt / client portfolio / at-risk list | ✅ all render correctly once `loadAll()` fix applied |
| Portfolio-wide Financials & ROI, Decisions & Risks, Team pages (newly built) | ✅ render correctly for both Admin and a restricted Manager account |
| Audit Logs | ✅ every action taken during this entire test session (30 rows) correctly attributed, timestamped, and detailed |
| Role-based nav visibility (Audit Logs / Admin section hidden for non-Admin) | ✅ |

---

## Not exercised in this pass (lower priority / harder to automate)

- Drag-and-drop gate reordering (Admin) — reviewed the code (`gates.js`
  `gateDragStart/Over/Drop`), pattern is standard HTML5 DnD calling
  `API.gates.reorder()`; not run through an actual mouse-drag simulation.
- Excel import (no UI entry point to exercise, see 2.4).
- Milestone create/edit/delete (legacy tab, same CRUD pattern as
  Risks/Partnerships, backed by a real endpoint — not separately clicked
  through given time constraints, but implementation is symmetric).
