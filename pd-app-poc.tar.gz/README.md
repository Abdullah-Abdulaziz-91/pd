# PD Dashboard — Aramco Digital

Product Portfolio Management Platform

## Quick Start (Local)

**Backend:**
```bash
cd backend
python -m venv venv
source venv/bin/activate    # macOS/Linux
venv\Scripts\activate       # Windows
pip install -r requirements.txt
cp .env.example .env        # Fill in your values (DB creds, SECRET_KEY)
uvicorn app.main:app --port 8000
```

**Frontend:**
```bash
cd frontend
python -m http.server 8080
# or: python nocache_server.py 8080
# (disables browser caching — useful while actively editing JS/CSS,
#  since a stale cached copy of a changed file can otherwise look like
#  a bug that isn't actually there)
```

Open: http://localhost:8080
Login: `pd.admin@aramcodigital.com` / `admin` — **change this password
immediately**, and confirm this credential isn't live anywhere it
shouldn't be before going further than local testing.

## Database Setup
```bash
psql -U pd_user -d pd_dashboard -f database/schema.sql
```
`schema.sql` is the single consolidated file — it creates every table,
view, trigger, and seeds the 10 gates / 58 gate tasks / default admin
account in one pass. Nothing else needs to run against a fresh database.

## SSO
The app ships SSO-ready but inactive (`SSO_ENABLED=false` by default) —
see [SSO_SETUP.md](SSO_SETUP.md) for what's already built and the exact
steps to connect a real identity provider.

## Deploy to GCP
See DEPLOYMENT_HANDOVER.md for full instructions.

## Tech Stack
- **Backend:** FastAPI, SQLAlchemy (async), asyncpg, bcrypt, JWT
- **Frontend:** Vanilla HTML/CSS/JS (no framework, no build step), Chart.js
- **Database:** PostgreSQL 15
- **Deploy:** Google Cloud Run + Cloud SQL
