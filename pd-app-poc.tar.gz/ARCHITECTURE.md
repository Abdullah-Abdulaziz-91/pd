# PD Dashboard — Architecture Document
## Aramco Digital — Product Development Portfolio Management
### Version 1.0 — July 2026

---

# 1. SYSTEM ARCHITECTURE OVERVIEW

```
┌─────────────────────────────────────────────────────────────────────┐
│                        USER (Browser)                               │
│                    Chrome / Edge / Firefox                          │
└──────────────────────────────┬──────────────────────────────────────┘
                               │  HTTPS
                               ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    GOOGLE CLOUD PLATFORM                            │
│                                                                     │
│  ┌─────────────────────┐          ┌─────────────────────────────┐  │
│  │   Cloud Run         │  HTTPS   │   Cloud Run                 │  │
│  │   FRONTEND          │─────────▶│   BACKEND                   │  │
│  │                     │  /api/*  │                             │  │
│  │   nginx             │          │   FastAPI (Python 3.11)     │  │
│  │   serves static     │          │   Uvicorn ASGI server       │  │
│  │   HTML/CSS/JS       │          │   2 workers                 │  │
│  │                     │          │                             │  │
│  │   Port 8080         │          │   Port 8000                 │  │
│  └─────────────────────┘          └──────────────┬──────────────┘  │
│                                                  │                  │
│                                                  │ asyncpg          │
│                                                  │ Private IP       │
│                                                  ▼                  │
│                                   ┌──────────────────────────────┐  │
│                                   │   Cloud SQL                  │  │
│                                   │   PostgreSQL 15              │  │
│                                   │                              │  │
│                                   │   15 Tables                  │  │
│                                   │   3 Views                    │  │
│                                   │   Triggers                   │  │
│                                   └──────────────────────────────┘  │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │   Secret Manager                                            │   │
│  │   pd-database-url  │  pd-secret-key                        │   │
│  └─────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

---

# 2. FRONTEND ARCHITECTURE

```
index.html  (Single Page Application shell)
│
├── CSS
│   ├── main.css          Layout, typography, CSS variables, grid
│   └── components.css    Cards, tables, modals, badges, forms
│
└── JavaScript (loaded in order)
    │
    ├── CDN Scripts
    │   ├── chart.js      Chart.js library (jsdelivr CDN)
    │   └── fontawesome   Icons (CDN)
    │
    ├── Core Layer
    │   ├── api.js        All HTTP calls to backend
    │   ├── auth.js       JWT storage, role checks, user state, SSO button wiring
    │   ├── theme.js      Brand mark (PdLogo) + shared particle background
    │   └── router.js     Client-side routing + shared state
    │
    ├── Component Layer
    │   ├── charts.js     Chart wrappers (colors read live from CSS vars)
    │   ├── modals.js     Modal system (form/confirm/custom)
    │   └── notifications.js  Toast messages + bell alerts
    │
    └── Page Layer
        ├── gates.js      Gate heatmap + accordion + partnerships
        ├── overview.js   Executive dashboard + Gantt + KPIs
        ├── portfolio.js  Product list + CRUD
        ├── product.js    Product detail (6 tabs)
        ├── financials.js Financial reports
        ├── decisions.js  Decision priorities
        ├── team.js       Team directory
        ├── logs.js       Audit log viewer
        └── settings.js   Profile + admin tools
```

## Frontend Data Flow

```
User Action (click/input)
        │
        ▼
Page Function (e.g. openAddProduct)
        │
        ▼
API Call (api.js)  ──────────────────▶  Backend
        │                                  │
        ▼                                  ▼
Router.state updated              Database write/read
        │
        ▼
Re-render page HTML
        │
        ▼
User sees updated UI
```

## Shared State (Router.state)

```javascript
Router.state = {
    products:   [ ...all active products ],
    milestones: [ ...all milestones ],
    financials: [ ...all financials ],
    risks:      [ ...all risks ],
    loaded:     true
}
```
Populated once on login via `loadAll()`.
Refreshed on any create/update/delete via `Router.refresh()`.

---

# 3. BACKEND ARCHITECTURE

```
FastAPI Application (app/main.py)
│
├── Middleware
│   ├── CORSMiddleware       Whitelist frontend URL
│   └── Exception handlers   Global error responses
│
├── Routers (app/api/)       11 route prefixes across 8 files — several
│   │                        prefixes share one file (noted below) since
│   │                        they're small and closely related.
│   ├── /api/auth/           auth.py       — Login, token, profile
│   ├── /api/auth/sso/       sso.py        — OIDC scaffold, inactive by
│   │                                        default (see SSO_SETUP.md)
│   ├── /api/products/       products.py   — Product CRUD
│   ├── /api/gates/          gates.py      — Gates, tasks, heatmap, dates
│   ├── /api/clients/        clients.py    — Client management
│   ├── /api/partnerships/   partnerships.py — Partnership CRUD
│   ├── /api/financials/  ┐
│   ├── /api/milestones/  │  data.py       — Financials, legacy milestones,
│   ├── /api/risks/       │                  risk register, product comments
│   ├── /api/comments/    ┘
│   ├── /api/users/       ┐
│   ├── /api/notifications/│ admin.py      — User management, notifications,
│   ├── /api/logs/        │                  audit logs, Excel import
│   └── /api/import/      ┘                  (all Admin-only except notifications)
│
├── Core (app/core/)
│   ├── config.py            Loads .env variables, incl. SSO_* settings
│   ├── database.py          Async SQLAlchemy engine + session
│   └── security.py          JWT encode/decode, bcrypt verify
│
├── Models (app/models/)     SQLAlchemy ORM table definitions
│   ├── user.py              User model (password_hash nullable — NULL for
│   │                        SSO accounts; auth_provider + sso_subject cols)
│   └── models.py            All other models
│
├── Schemas (app/schemas/)   Pydantic request/response validation
│   └── schemas.py           All schemas (Base, Create, Update, Out)
│
└── Services (app/services/)
    ├── audit.py             Writes to audit_logs table
    └── notifications.py     Creates in-app notifications
```

## Request Lifecycle

```
HTTP Request
     │
     ▼
FastAPI Router
     │
     ▼
Depends(get_current_user)  ──── JWT validation
     │                              │
     │                     ┌────────▼────────┐
     │                     │  users table    │
     │                     │  verify active  │
     │                     └────────┬────────┘
     │                              │
     ▼                              ▼
Depends(get_db)            User object injected
     │
     ▼
AsyncSession (asyncpg)
     │
     ▼
Business logic + DB query
     │
     ▼
await db.commit()   ◀──── Explicit commit (critical)
     │
     ▼
await log_action()  ◀──── Audit trail
     │
     ▼
Pydantic response model
     │
     ▼
JSON Response
```

---

# 4. DATABASE ARCHITECTURE

## Entity Relationship Diagram

```
┌────────────────┐   ┌───────────────────────┐     ┌──────────────┐
│    users       │   │       products         │     │    gates     │
│────────────────│   │───────────────────────│     │──────────────│
│ id (PK)        │◀──│ team_lead_user_id (FK) │     │ id (PK)      │
│ email          │   │ created_by (FK)        │     │ gate_number  │
│ name           │   │──────────────────────  │     │ name         │
│ password_hash  │   │ id (PK)               │     │ weight %     │
│  (NULL if SSO) │   │ product_code          │     └──────┬───────┘
│ auth_provider  │   │ name                  │            │
│ sso_subject    │   │ status                │     ┌──────▼───────┐
│ role           │   │ priority              │     │  gate_tasks  │
│ finance_access │   │ completion            │     │──────────────│
│ is_active      │   │ start_date            │     │ id (PK)      │
└────────────────┘   │ readiness_date        │     │ gate_id (FK) │
                     │ pipeline_value        │     │ task_name    │
                     │ customer_count        │     │ workstream   │
                     │ is_active             │     │ sort_order   │
                     └───────────┬───────────┘     └──────┬───────┘
                                 │                        │
              ┌──────────────────┼───────────────┐       │
              │                  │               │        │
              ▼                  ▼               ▼        ▼
   ┌──────────────────┐ ┌─────────────┐ ┌───────────────────────┐
   │  product_clients │ │partnerships │ │  product_gate_tasks   │
   │──────────────────│ │─────────────│ │───────────────────────│
   │ product_id (FK)  │ │product_id   │ │ product_id (FK)       │
   │ client_id (FK)   │ │partner_name │ │ gate_task_id (FK)     │
   └────────┬─────────┘ │type         │ │ status                │
            │           │status       │ │ owner                 │
            ▼           └─────────────┘ │ due_date              │
   ┌──────────────┐                     └───────────────────────┘
   │   clients    │
   │──────────────│     ┌─────────────────────────┐
   │ id (PK)      │     │   product_gate_dates    │
   │ name         │     │─────────────────────────│
   │ is_active    │     │ product_id (FK)         │
   └──────────────┘     │ gate_id (FK)            │
                        │ start_date              │
              ┌─────────│ due_date                │
              │         │ gate_lead               │
              ▼         └─────────────────────────┘
   ┌──────────────────┐
   │    financials    │     ┌──────────────────┐
   │──────────────────│     │      risks       │
   │ product_id (FK)  │     │──────────────────│
   │ approved_budget  │     │ product_id (FK)  │
   │ actual_spend     │     │ risk_code        │
   │ forecast         │     │ likelihood       │
   │ quarter          │     │ impact           │
   └──────────────────┘     │ risk_score (auto)│
                            └──────────────────┘

   ┌──────────────────┐     ┌──────────────────┐
   │    comments      │     │   audit_logs     │
   │──────────────────│     │──────────────────│
   │ product_id (FK)  │     │ user_id (FK)     │
   │ user_id (FK)     │     │ action_type      │
   │ body             │     │ entity_type      │
   │ mentions[]       │     │ old_value        │
   └──────────────────┘     │ new_value        │
                            │ ip_address       │
                            └──────────────────┘
```

## View Architecture

```
v_gate_progress  (most critical view)
│
├── Input tables
│   ├── products          (base entities)
│   ├── gates             (CROSS JOIN — every product × every gate)
│   ├── gate_tasks        (LEFT JOIN — all tasks even without status)
│   ├── product_gate_tasks (LEFT JOIN — actual task statuses)
│   └── product_gate_dates (LEFT JOIN — gate dates and lead)
│
└── Output columns
    ├── gate_pct          Completion % (N/A tasks excluded)
    ├── time_consumed_pct Schedule % elapsed (start→due vs today)
    ├── has_overdue_task  Any task past its due date
    ├── gate_overdue      Gate itself past due date
    └── total/complete/   Task count breakdown
        in_progress/na/
        not_started tasks

v_product_gate_completion
└── SUM(gate_pct × gate_weight / 100) = overall_pct per product

v_financials
└── financials + product name + utilization_pct + variance
```

---

# 5. AUTHENTICATION ARCHITECTURE

Two login paths converge on the same JWT: password (below) and SSO/OIDC
(scaffolded but inactive — see SSO_SETUP.md for the full picture). Both end
by calling the same `create_access_token(user.id)`, so `get_current_user`,
role checks, finance-access gating, and audit logging all work identically
regardless of which one a session started from.

```
LOGIN FLOW
──────────
User submits email + password
          │
          ▼
POST /api/auth/login
          │
          ▼
SELECT user WHERE email = ? AND is_active = TRUE
          │
          ▼
bcrypt.verify(password, password_hash)   ← rounds=12
          │
          ├── FAIL → 401 Unauthorized
          │
          └── PASS
                │
                ▼
          Create JWT token
          {
            sub: user_id,
            exp: now + 480 minutes
          }
                │
                ▼
          Log login to audit_logs
                │
                ▼
          Return { access_token, user }


AUTHENTICATED REQUEST FLOW
──────────────────────────
Request with Authorization: Bearer <token>
          │
          ▼
Depends(get_current_user)
          │
          ▼
Decode JWT → extract user_id
          │
          ├── Invalid/expired → 401
          │
          └── Valid
                │
                ▼
          SELECT user WHERE id = ? AND is_active = TRUE
                │
                ├── Not found → 401
                │
                └── Found → inject User into endpoint
```

---

# 6. GATE SCORING ARCHITECTURE

```
58 Gate Tasks (system config, never changes per product)
          │
          ▼  per product
product_gate_tasks rows (status per task)
          │
          ▼
v_gate_progress VIEW

Gate Score Formula:
┌─────────────────────────────────────────────────────┐
│                                                     │
│  eligible = total_tasks - na_tasks                  │
│                                                     │
│  score = (complete × 1.0 + in_progress × 0.5)      │
│          ────────────────────────────────── × 100   │
│                    eligible                         │
│                                                     │
└─────────────────────────────────────────────────────┘

Overall Product Score:
┌─────────────────────────────────────────────────────┐
│                                                     │
│  overall = Σ (gate_score[i] × gate_weight[i] / 100) │
│            for i = 1 to 10                          │
│                                                     │
│  Default: all weights = 10% (sum = 100%)            │
│  Admin can adjust via Settings → Gate Weights       │
│                                                     │
└─────────────────────────────────────────────────────┘

RAG Color Logic:
┌─────────────────────────────────────────────────────┐
│                                                     │
│  time_consumed = (today - start) / (due - start)   │
│                                                     │
│  RED    → due_date < today AND progress < 100%      │
│  YELLOW → progress < time_consumed × 0.75           │
│  GREEN  → progress ≥ time_consumed × 0.75           │
│  GRAY   → no dates set AND progress = 0%            │
│                                                     │
└─────────────────────────────────────────────────────┘
```

---

# 7. CI/CD PIPELINE ARCHITECTURE

```
Developer
    │
    │  git push
    ▼
┌─────────────────────────────────────────────────────┐
│                    GitLab                           │
│                                                     │
│  Stage 1: LINT                                      │
│  └── flake8 backend/app --max-line-length=120       │
│                                                     │
│  Stage 2: SECURITY SCAN                             │
│  ├── bandit -r backend/app (SAST)                   │
│  └── safety check -r requirements.txt              │
│                                                     │
│  Stage 3: BUILD (on merge to main)                  │
│  ├── docker build backend → gcr.io/PROJECT/backend  │
│  └── docker build frontend → gcr.io/PROJECT/frontend│
│                                                     │
│  Stage 4: DEPLOY (on merge to main)                 │
│  ├── gcloud run deploy pd-backend                   │
│  └── gcloud run deploy pd-frontend                  │
└─────────────────────────────────────────────────────┘
    │
    ▼
┌─────────────────────────────────────────────────────┐
│              Google Cloud Platform                  │
│                                                     │
│  Artifact Registry ◀── Docker images pushed        │
│         │                                           │
│         ▼                                           │
│  Cloud Run ◀────────── Deployed from image         │
│         │                                           │
│         ▼                                           │
│  Cloud SQL ◀──────── Connected via Cloud SQL proxy │
└─────────────────────────────────────────────────────┘
```

---

# 8. SECURITY ARCHITECTURE

```
┌─────────────────────────────────────────────────────────┐
│  LAYER 1 — Transport                                    │
│  • HTTPS enforced on Cloud Run                          │
│  • HTTP → HTTPS redirect                                │
└─────────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────────┐
│  LAYER 2 — Authentication                               │
│  • JWT token (HS256, expires 8 hours)                   │
│  • bcrypt password hashing (rounds=12)                  │
│  • All endpoints require valid JWT except /login        │
└─────────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────────┐
│  LAYER 3 — Authorization                                │
│  • Role-based: Admin / Manager / Team Lead              │
│  • Finance access: explicit flag per user               │
│  • Team Leads can only edit their own products          │
└─────────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────────┐
│  LAYER 4 — Data                                         │
│  • Parameterized SQL queries (no SQL injection)         │
│  • Soft delete (archive) preserves data integrity       │
│  • Foreign key constraints enforce referential integrity│
└─────────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────────┐
│  LAYER 5 — Audit                                        │
│  • Every action logged: who, what, when, old, new, IP  │
│  • Audit logs are append-only (no update/delete)        │
└─────────────────────────────────────────────────────────┘
                        │
┌─────────────────────────────────────────────────────────┐
│  LAYER 6 — Infrastructure                               │
│  • Secrets in GCP Secret Manager (not env files)        │
│  • Cloud SQL on Private IP (not public internet)        │
│  • CORS whitelist (only frontend URL allowed)           │
│  • Non-root user in Docker containers                   │
└─────────────────────────────────────────────────────────┘
```

---

# 9. DEPLOYMENT ARCHITECTURE

```
                    ┌─────────────────┐
                    │   Developer     │
                    │   Workstation   │
                    └────────┬────────┘
                             │ git push
                             ▼
                    ┌─────────────────┐
                    │    GitLab       │
                    │  Repository     │
                    └────────┬────────┘
                             │ CI/CD triggers
                             ▼
               ┌─────────────────────────────┐
               │        Jenkins / GitLab CI  │
               │  1. Lint + Security Scan    │
               │  2. Docker Build            │
               │  3. Push to GCR             │
               │  4. Deploy to Cloud Run     │
               └─────────────┬───────────────┘
                             │
          ┌──────────────────┴──────────────────┐
          │                                     │
          ▼                                     ▼
┌──────────────────────┐             ┌──────────────────────┐
│  Cloud Run           │             │  Cloud Run           │
│  pd-frontend         │             │  pd-backend          │
│                      │             │                      │
│  Image: nginx:alpine │             │  Image: python:3.11  │
│  Memory: 256Mi       │             │  Memory: 512Mi       │
│  Min instances: 1    │             │  Min instances: 1    │
│  Max instances: 5    │             │  Max instances: 10   │
│  Port: 8080          │             │  Port: 8000          │
└──────────────────────┘             └──────────┬───────────┘
          │                                     │
          │  Serves static files                │  asyncpg
          │  index.html, JS, CSS                │  Private IP
          │                                     ▼
          │                          ┌──────────────────────┐
          │                          │  Cloud SQL           │
          │                          │  PostgreSQL 15       │
          │                          │  db-f1-micro         │
          │                          │  Private IP only     │
          │                          └──────────────────────┘
          │
          │  ┌──────────────────────────────────────────────┐
          │  │  Secret Manager                              │
          └──│  pd-database-url  ──▶ DATABASE_URL           │
             │  pd-secret-key    ──▶ SECRET_KEY             │
             └──────────────────────────────────────────────┘
```

---

# 10. TECHNOLOGY DECISIONS

| Decision | Choice | Reason |
|----------|--------|--------|
| Backend framework | FastAPI | Async support, auto Swagger docs, Pydantic validation |
| Frontend framework | None (Vanilla JS) | No build step, easy to read, no dependencies to maintain |
| ORM | SQLAlchemy async | Industry standard, type-safe, async-native |
| DB driver | asyncpg | Fastest PostgreSQL driver for Python |
| Auth | JWT + bcrypt | Stateless, secure, industry standard |
| Database | PostgreSQL | ACID compliant, views, triggers, BOOL_OR aggregation |
| Container | Docker + nginx | Portable, Cloud Run compatible |
| Hosting | Cloud Run | Serverless, auto-scaling, no infrastructure management |
| Secrets | Secret Manager | Never store secrets in code or env files |
| CI/CD | GitLab + Jenkins | Both pipelines provided for flexibility |

---

*PD Dashboard — Architecture Document*
*Aramco Digital — July 2026*
