/* ═══════════════════════════════════════════════════════════
   PD Dashboard — Aramco Digital
   auth.js  —  login, logout, session restore
═══════════════════════════════════════════════════════════ */

const Auth = (() => {

  // ── UI helpers ─────────────────────────────────────────
  function showLogin(errorMsg = null) {
    document.getElementById('login-screen').classList.remove('hidden');
    document.getElementById('app-shell').style.display = 'none';
    if (errorMsg) showError(errorMsg);
  }

  function showApp() {
    document.getElementById('login-screen').classList.add('hidden');
    document.getElementById('app-shell').style.display = 'block';
  }

  function showError(msg) {
    const el = document.getElementById('login-error');
    const msgEl = document.getElementById('login-error-msg');
    msgEl.textContent = msg;
    el.style.display = 'flex';
  }

  function hideError() {
    document.getElementById('login-error').style.display = 'none';
  }

  function setLoading(loading) {
    const btn  = document.getElementById('login-btn');
    const text = document.getElementById('login-btn-text');
    const spin = document.getElementById('login-spinner');
    btn.disabled   = loading;
    text.textContent = loading ? 'Signing in…' : 'Sign In';
    spin.style.display = loading ? 'inline-block' : 'none';
  }

  // ── Apply user to UI ────────────────────────────────────
  function applyUser(u) {
    const initials = u.initials ||
      u.name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();

    // Topbar
    document.getElementById('topbar-avatar').textContent = initials;
    document.getElementById('topbar-name').textContent   = u.name;
    document.getElementById('topbar-role').textContent   = u.role;

    // Sidebar
    document.getElementById('sidebar-avatar').textContent = initials;
    document.getElementById('sidebar-name').textContent   = u.name;
    document.getElementById('sidebar-role').textContent   = u.role;

    // Admin-only elements
    const isAdmin    = u.role === 'Admin';
    const hasFinance = isAdmin || u.finance_access === true;
    document.getElementById('nav-admin-section').style.display = isAdmin    ? 'block' : 'none';
    document.getElementById('nav-logs').style.display          = isAdmin    ? 'flex'  : 'none';
    const finNav = document.getElementById('nav-financials');
    if (finNav) finNav.style.display = hasFinance ? 'flex' : 'none';
  }

  // ── Login ───────────────────────────────────────────────
  async function login() {
    hideError();
    const email    = document.getElementById('login-email').value.trim().toLowerCase();
    const password = document.getElementById('login-password').value;

    if (!email)    { showError('Please enter your email address.'); return; }
    if (!password) { showError('Please enter your password.');      return; }

    setLoading(true);
    try {
      const res = await API.auth.login(email, password);

      // Store token + user
      API.token.set(res.access_token);
      API.user.set(res.user);

      applyUser(res.user);
      showApp();

      // Load data and render first page
      await Router.init();

    } catch (err) {
      showError(err.message || 'Invalid email or password.');
    } finally {
      setLoading(false);
    }
  }

  // ── Logout ──────────────────────────────────────────────
  async function logout() {
    try { await API.auth.logout(); } catch (_) {}
    API.token.clear();
    API.user.clear();
    // Clear any cached page state
    if (window.Router) Router.reset();
    showLogin();
    // Clear password field for security
    document.getElementById('login-password').value = '';
  }

  // ── Restore session on page reload ──────────────────────
  async function restore() {
    const storedToken = API.token.get();
    const storedUser  = API.user.get();

    if (!storedToken || !storedUser) {
      showLogin();
      return;
    }

    try {
      // Verify token is still valid
      const me = await API.auth.me();
      API.user.set(me);
      applyUser(me);
      showApp();
      await Router.init();
    } catch (_) {
      // Token expired or invalid
      API.token.clear();
      API.user.clear();
      showLogin();
    }
  }

  // ── Current user convenience ─────────────────────────────
  function currentUser() {
    return API.user.get();
  }

  function isAdmin() {
    const u = currentUser();
    return u && u.role === 'Admin';
  }

  function isManagerOrAbove() {
    const u = currentUser();
    return u && ['Admin', 'Manager'].includes(u.role);
  }

  // ── SSO (scaffold — see SSO_SETUP.md) ────────────────────
  // Shows the "Sign in with SSO" button only if the backend reports it's
  // actually configured; stays hidden otherwise so there's no dead button
  // pointing at a 501.
  async function checkSso() {
    try {
      const { enabled } = await API.auth.ssoStatus();
      document.getElementById('sso-login-btn').style.display = enabled ? 'flex' : 'none';
      document.getElementById('sso-divider').style.display   = enabled ? 'flex'  : 'none';
    } catch (_) { /* backend not reachable yet — leave the button hidden */ }
  }

  function ssoLogin() {
    window.location.href = API.auth.ssoLoginUrl;
  }

  // ── Boot on DOM ready ────────────────────────────────────
  document.addEventListener('DOMContentLoaded', () => { restore(); checkSso(); });

  return {
    login,
    logout,
    showLogin,
    showApp,
    currentUser,
    isAdmin,
    isManagerOrAbove,
    applyUser,
    ssoLogin,
  };

})();
