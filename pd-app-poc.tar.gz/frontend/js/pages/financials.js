/* ═══════════════════════════════════════════════════════════
   financials.js  —  Financials & ROI (portfolio-wide report)
═══════════════════════════════════════════════════════════ */

Pages.Financials = (() => {

  async function render() {
    const el = document.getElementById('page-financials');
    if (!el) return;

    const u = Auth.currentUser() || {};
    const hasAccess = u.role === 'Admin' || u.finance_access === true;

    if (!hasAccess) {
      el.innerHTML = `
        <div class="page-header">
          <div class="page-header-left"><h2>Financials & ROI</h2></div>
        </div>
        <div class="empty-state" style="padding:60px">
          <i class="fas fa-lock"></i>
          <p>Finance access required. Contact an Admin to be granted access.</p>
        </div>`;
      return;
    }

    let financials = [];
    try { financials = await API.financials.list(); }
    catch (err) {
      el.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-circle"></i>
        <p>Failed to load financials: ${err.message}</p></div>`;
      return;
    }

    const products = Router.state.products || [];
    const byProduct = {};
    products.forEach(p => { byProduct[p.id] = p; });

    const totalBudget = financials.reduce((a, f) => a + Number(f.approved_budget || 0), 0);
    const totalSpend  = financials.reduce((a, f) => a + Number(f.actual_spend || 0), 0);
    const totalForecast = financials.reduce((a, f) => a + Number(f.forecast || 0), 0);
    const avgUtil = totalBudget > 0 ? Math.round((totalSpend / totalBudget) * 100) : 0;

    el.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2>Financials & ROI</h2>
          <p>${financials.length} financial record${financials.length !== 1 ? 's' : ''} across the portfolio</p>
        </div>
      </div>

      <div class="grid-4 mb-24">
        ${finKpi('Total Budget', fmt.currency(totalBudget), 'fa-wallet', 'blue')}
        ${finKpi('Total Spend', fmt.currency(totalSpend), 'fa-receipt', totalSpend > totalBudget ? 'red' : 'green')}
        ${finKpi('Total Forecast', fmt.currency(totalForecast), 'fa-chart-line', 'blue')}
        ${finKpi('Avg Utilization', avgUtil + '%', 'fa-chart-bar', avgUtil > 90 ? 'red' : avgUtil > 70 ? 'amber' : 'green')}
      </div>

      <div class="card mb-24">
        <div class="card-header"><div class="card-title"><i class="fas fa-chart-bar"></i> Budget vs. actual spend</div></div>
        <div class="card-body"><div class="chart-wrap" style="height:280px"><canvas id="fin-budget-chart"></canvas></div></div>
      </div>

      <div class="card">
        <div class="card-header"><div class="card-title"><i class="fas fa-table"></i> Financial detail</div></div>
        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Product</th><th>Quarter</th><th>Approved Budget</th>
                <th>Actual Spend</th><th>Forecast</th><th>Utilization</th><th>Variance</th>
              </tr>
            </thead>
            <tbody>
              ${financials.length ? financials.map(f => {
                const util = Number(f.utilization_pct || 0);
                const variance = Number(f.variance || 0);
                return `
                <tr style="cursor:pointer" onclick="Router.go('product',{id:${f.product_id}})">
                  <td class="primary">${f.product_name || byProduct[f.product_id]?.name || 'Product ' + f.product_id}</td>
                  <td>${f.quarter || '—'}</td>
                  <td>${fmt.currency(f.approved_budget)}</td>
                  <td style="color:${Number(f.actual_spend) > Number(f.approved_budget) ? 'var(--color-danger)' : 'var(--gray-900)'}">${fmt.currency(f.actual_spend)}</td>
                  <td>${fmt.currency(f.forecast)}</td>
                  <td>
                    <span style="font-weight:700;color:${util > 90 ? 'var(--color-danger)' : util > 70 ? 'var(--color-warning)' : 'var(--green-600)'}">
                      ${Math.round(util)}%
                    </span>
                  </td>
                  <td style="color:${variance < 0 ? 'var(--color-danger)' : 'var(--green-600)'};font-weight:600">
                    ${variance >= 0 ? '+' : ''}${fmt.currency(variance)}
                  </td>
                </tr>`;
              }).join('')
              : `<tr><td colspan="7" style="text-align:center;padding:40px;color:var(--gray-400)">
                   No financial data recorded yet. Add it from a product's Financials tab.
                 </td></tr>`}
            </tbody>
          </table>
        </div>
      </div>`;

    const topFin = financials.slice().sort((a, b) => Number(b.approved_budget) - Number(a.approved_budget)).slice(0, 10);
    Charts.budgetBars('fin-budget-chart', topFin);
  }

  function finKpi(label, value, icon, color) {
    const colors = { blue: 'var(--blue-600)', green: 'var(--green-600)', red: 'var(--color-danger)', amber: 'var(--color-warning)' };
    return `
      <div style="text-align:center;padding:14px;background:var(--gray-50);border-radius:var(--radius-md);border:1px solid var(--gray-200)">
        <i class="fas ${icon}" style="font-size:18px;color:${colors[color] || colors.blue};margin-bottom:8px"></i>
        <div style="font-size:18px;font-weight:700;color:var(--gray-900)">${value}</div>
        <div style="font-size:11px;color:var(--gray-500);margin-top:3px">${label}</div>
      </div>`;
  }

  return { render };

})();
