/* ═══════════════════════════════════════════════════════════
   overview.js  —  Executive Overview
═══════════════════════════════════════════════════════════ */

const Pages = window.Pages || {};

Pages.Overview = (() => {

  async function render() {
    const el = document.getElementById('page-overview');
    if (!el) return;

    const S = Router.state;
    const products   = S.products   || [];
    const milestones = S.milestones || [];
    const financials = S.financials || [];
    const risks      = S.risks      || [];

    const totalProducts = products.length;
    const atRiskCount   = products.filter(function(x){ return x.action_required && x.action_required !== 'On Track'; }).length;
    const overdueMs     = milestones.filter(function(x){ return x.status === 'Overdue'; }).length; // legacy, unused below
    const totalBudget   = financials.reduce(function(a,f){ return a + Number(f.approved_budget||0); }, 0);
    const totalSpend    = financials.reduce(function(a,f){ return a + Number(f.actual_spend||0); }, 0);
    const openRisks     = risks.filter(function(x){ return x.status === 'Open'; }).length;
    const avgComp       = totalProducts
      ? Math.round(products.reduce(function(a,x){ return a+(x.completion||0); }, 0) / totalProducts) : 0;

    const stages = ['Concept','Development','Validation','Pilot','Scale-up','Commercial'];

    const atRiskProds = products
      .filter(function(x){ return x.action_required && x.action_required !== 'On Track'; })
      .sort(function(a,b){
        var o = {Critical:0,High:1,Medium:2,Low:3};
        return (o[a.priority]||9)-(o[b.priority]||9);
      }).slice(0,5);

    // Fetch heatmap once - reused for both the heatmap render AND
    // to fill in missing start_date on products (fallback to earliest gate start)
    var heatmapData = [];
    try { heatmapData = await API.gates.heatmap(); } catch(e) {}
    var startDateByProduct = {};
    heatmapData.forEach(function(p) {
      if (p.start_date) startDateByProduct[p.product_id] = p.start_date;
    });
    var productsForGantt = products.map(function(p) {
      if (!p.start_date && startDateByProduct[p.id]) {
        return Object.assign({}, p, { start_date: startDateByProduct[p.id] });
      }
      return p;
    });

    var clientHTML = '<div class="empty-state" style="padding:32px"><i class="fas fa-building"></i><p>No clients linked yet.</p></div>';
    try {
      var cs = await API.clients.summary();
      if (cs && cs.length) {
        clientHTML = cs.map(function(c){
          var prods = (c.products||[]).slice(0,3).join(' · ');
          if ((c.products||[]).length > 3) prods += ' +' + (c.products.length-3) + ' more';
          return '<div style="display:flex;align-items:center;gap:12px;padding:12px 20px;border-bottom:1px solid var(--gray-100)">'
            + '<div style="width:36px;height:36px;border-radius:var(--radius-sm);background:linear-gradient(135deg,var(--blue-600),var(--green-600));color:#fff;font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0">' + c.name.charAt(0).toUpperCase() + '</div>'
            + '<div style="flex:1"><div style="font-size:13px;font-weight:600;color:var(--gray-900)">' + c.name + '</div>'
            + '<div style="font-size:11px;color:var(--gray-500)">' + prods + '</div></div>'
            + '<div style="text-align:right"><div style="font-size:18px;font-weight:700;color:var(--blue-700)">' + c.product_count + '</div>'
            + '<div style="font-size:10px;color:var(--gray-400)">products</div></div></div>';
        }).join('');
      }
    } catch(e) {}

    el.innerHTML = ''
      + '<div class="page-header">'
        + '<div class="page-header-left"><h2>Executive Overview</h2>'
        + '<p>Portfolio health — ' + new Date().toLocaleDateString('en-GB',{day:'2-digit',month:'long',year:'numeric'}) + '</p></div>'
        + '<div class="page-header-actions">'
          + '<button class="btn btn-secondary btn-sm" onclick="Router.refresh()"><i class="fas fa-sync-alt"></i> Refresh</button>'
          + (Auth.isManagerOrAbove() ? '<button class="btn btn-primary btn-sm" onclick="Pages.Portfolio.openAddProduct()"><i class="fas fa-plus"></i> Add Product</button>' : '')
        + '</div></div>'

      // KPIs
      + '<div class="grid-5 mb-24">'
        + kpi('Total Products',     totalProducts,   'fa-cubes',               'blue',  'Across all stages')
        + kpi('Avg Completion',     avgComp+'%',     'fa-chart-line',           'blue', 'Portfolio progress')
        + kpi('Needs Attention',    atRiskCount,     'fa-exclamation-triangle', 'amber', 'Action required')
        + kpiCustom('kpi-overdue-products', 'Overdue Products', 0, 'fa-calendar-times', 'red', 'Products with overdue gates')
        + kpi('Open Risks',         openRisks,       'fa-shield-alt',           openRisks>0?'amber':'green', 'All monitored')
      + '</div>'

      // Heatmap
      + '<div class="card mb-24">'
        + '<div class="card-header"><div class="card-title"><i class="fas fa-chart-bar"></i> Products Progress</div>'
        + '<div style="font-size:12px;color:var(--gray-500)">Schedule health across all gates &middot; Click a row to open the product</div></div>'
        + '<div class="card-body" id="gate-heatmap-container"><div class="loading"><i class="fas fa-spinner fa-spin"></i> Loading…</div></div>'
      + '</div>'

      // Stage funnel + Gantt
      + '<div class="grid-2 mb-24">'
        + '<div class="card"><div class="card-header"><div class="card-title"><i class="fas fa-stream"></i> Portfolio by stage</div>'
          + '<button class="btn btn-secondary btn-sm" onclick="Router.go(\'portfolio\')">View all <i class="fas fa-arrow-right"></i></button></div>'
          + '<div class="card-body">' + stageBars(products, stages) + '</div></div>'
        + '<div class="card"><div class="card-header"><div class="card-title"><i class="fas fa-calendar-alt"></i> Product launch timeline</div></div>'
          + '<div class="card-body">' + ganttChart(productsForGantt) + '</div></div>'
      + '</div>'

      // Clients + At-risk
      + '<div class="grid-2 mb-24">'
        + '<div class="card"><div class="card-header"><div class="card-title"><i class="fas fa-building"></i> Client portfolio</div></div>'
          + '<div class="card-body-flush">' + clientHTML + '</div></div>'
        + '<div class="card"><div class="card-header"><div class="card-title" style="color:var(--color-danger)"><i class="fas fa-exclamation-triangle"></i> Needs attention</div>'
          + '<span style="font-size:12px;color:var(--gray-500)">' + atRiskCount + ' products</span></div>'
          + '<div class="card-body-flush">' + atRiskList(atRiskProds) + '</div></div>'
      + '</div>'

      // Financial
      + '<div class="card mb-24"><div class="card-header"><div class="card-title"><i class="fas fa-dollar-sign"></i> Financial snapshot</div>'
        + '<button class="btn btn-secondary btn-sm" onclick="Router.go(\'financials\')">Full report <i class="fas fa-arrow-right"></i></button></div>'
        + '<div class="card-body">'
          + '<div class="grid-4" style="margin-bottom:20px">'
            + finKpi('Total Budget',  fmt.currency(totalBudget), 'fa-wallet',    'blue')
            + finKpi('Total Spend',   fmt.currency(totalSpend),  'fa-receipt',   totalSpend>totalBudget?'red':'green')
            + finKpi('Remaining',     fmt.currency(Math.max(0,totalBudget-totalSpend)), 'fa-piggy-bank', 'green')
            + finKpi('Avg Utilization', totalBudget>0 ? Math.round((totalSpend/totalBudget)*100)+'%' : '—', 'fa-chart-bar', totalSpend/totalBudget>0.9?'red':'blue')
          + '</div>'
          + '<div class="chart-wrap" style="height:200px"><canvas id="ov-budget-chart"></canvas></div>'
        + '</div></div>';

    // Async renders
    try {
      var hmData = await API.gates.heatmap();
      var now = new Date();
      var overdueProductCount = hmData.filter(function(p) {
        // Same logic as Overall column color: gate-level overdue OR product launch date passed while incomplete
        var gateOverdue = p.gates.some(function(g) { return g.has_overdue_task || g.gate_overdue; });
        var overallPct  = p.gates.reduce(function(s,g){ return s + parseFloat(g.gate_pct||0) * parseFloat(g.gate_weight)/100; }, 0);
        var launchPassed = p.readiness_date && new Date(p.readiness_date) < now && overallPct < 100;
        return gateOverdue || launchPassed;
      }).length;
      var ovEl = document.getElementById('kpi-overdue-products');
      if (ovEl) {
        ovEl.textContent = overdueProductCount;
        var card = ovEl.closest('.kpi-card');
        if (card) {
          card.classList.remove('red','green');
          card.classList.add(overdueProductCount > 0 ? 'red' : 'green');
        }
      }
    } catch(e) {}
    renderGateHeatmap('gate-heatmap-container');
    var topFin = financials.slice().sort(function(a,b){ return Number(b.approved_budget)-Number(a.approved_budget); }).slice(0,6);
    Charts.budgetBars('ov-budget-chart', topFin);
  }

  // ── Stage bars ────────────────────────────────────────
  function stageBars(products, stages) {
    var total = products.length;
    return stages.map(function(s) {
      var count = products.filter(function(x){ return x.status===s; }).length;
      var pct   = total ? Math.round((count/total)*100) : 0;
      var color = Charts.COLORS.status[s] || 'var(--ink3)';
      return '<div style="margin-bottom:14px">'
        + '<div class="progress-label">'
          + '<span style="display:flex;align-items:center;gap:8px">' + badge.stage(s)
          + '<span style="font-size:12px;color:var(--gray-500)">' + count + ' product' + (count!==1?'s':'') + '</span></span>'
          + '<span class="pct">' + pct + '%</span>'
        + '</div>'
        + '<div class="progress-track"><div class="progress-fill" style="width:' + pct + '%;background:' + color + '"></div></div>'
      + '</div>';
    }).join('');
  }

  // ── At-risk list ──────────────────────────────────────
  function atRiskList(prods) {
    if (!prods.length) return '<div class="empty-state"><i class="fas fa-check-circle" style="color:var(--green-400)"></i><p>All products on track</p></div>';
    return prods.map(function(prod) {
      var barColor = prod.priority==='Critical'?'#7C2D2D'
        : prod.priority==='High'?'var(--color-danger)'
        : prod.priority==='Medium'?'var(--color-warning)':'var(--color-success)';
      return '<div style="display:flex;align-items:center;gap:12px;padding:12px 20px;border-bottom:1px solid var(--gray-100);cursor:pointer"'
        + ' onclick="Router.go(\'product\',{id:' + prod.id + '})"'
        + ' onmouseover="this.style.background=\'var(--gray-50)\'"'
        + ' onmouseout="this.style.background=\'\'">'
        + '<div style="width:4px;height:40px;border-radius:2px;flex-shrink:0;background:' + barColor + '"></div>'
        + '<div style="flex:1;min-width:0">'
          + '<div style="font-size:13px;font-weight:600;color:var(--gray-900);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + prod.name + '</div>'
          + '<div style="font-size:11px;color:var(--gray-500);margin-top:2px">' + badge.stage(prod.status) + ' ' + badge.action(prod.action_required) + '</div>'
        + '</div>'
        + '<div style="text-align:right;flex-shrink:0">'
          + '<div style="font-size:13px;font-weight:700;color:var(--gray-800)">' + (prod.completion||0) + '%</div>'
          + '<div style="font-size:10px;color:var(--gray-400)">complete</div>'
        + '</div></div>';
    }).join('');
  }

  // ── Gantt chart ───────────────────────────────────────
  function ganttChart(products) {
    var withDates = products.filter(function(x){ return x.readiness_date; });
    if (!withDates.length) return '<div class="empty-state" style="padding:32px"><i class="fas fa-calendar-alt"></i><p>Set target launch dates on products to see the timeline.</p></div>';

    var now      = new Date();
    var allDates = withDates.map(function(x){ return new Date(x.readiness_date); });
    var minD     = new Date(Math.min.apply(null, [now].concat(allDates)));
    var maxD     = new Date(Math.max.apply(null, allDates));
    minD.setDate(1);
    maxD.setMonth(maxD.getMonth()+1);
    maxD.setDate(1);

    var months = [];
    var cur = new Date(minD);
    while (cur < maxD) { months.push(new Date(cur)); cur.setMonth(cur.getMonth()+1); }
    if (!months.length) return '<div class="empty-state"><p>No date range</p></div>';

    var totalMs = maxD - minD;
    function posLeft(d) { return Math.max(0, Math.min(100, ((new Date(d)-minD)/totalMs)*100)); }
    function posW(s,e)  {
      var st = Math.max(new Date(s), minD);
      var en = Math.min(new Date(e), maxD);
      // Minimum 4% width so the bar is always visibly clickable,
      // even when start and launch dates are close together or
      // start_date is missing/defaulted.
      return Math.max(4, ((en-st)/totalMs)*100);
    }

    var barColors = ['#8B5CF6','#5B9BFF','#A783FF','#4D8FFF','#C9B4FA','#78ADFF'];

    var monthHeaders = months.map(function(m) {
      return '<div style="position:absolute;left:' + posLeft(m) + '%;font-size:10px;color:var(--gray-500);font-weight:600;white-space:nowrap">'
        + m.toLocaleString('en-GB',{month:'short'}) + ' ' + m.getFullYear() + '</div>';
    }).join('');

    var gridLines = months.map(function(m) {
      return '<div style="position:absolute;left:' + posLeft(m) + '%;top:0;bottom:0;width:1px;background:var(--gray-200)"></div>';
    }).join('');
    gridLines += '<div style="position:absolute;left:' + posLeft(now) + '%;top:0;bottom:0;width:2px;background:var(--color-danger);opacity:.6"></div>';

    var rows = withDates.map(function(prod, i) {
      var launch   = new Date(prod.readiness_date);
      var start    = prod.start_date ? new Date(prod.start_date) : now;
      var barStart = posLeft(start < minD ? minD : start);
      var barW     = posW(start < minD ? minD : start, launch);
      var color    = barColors[i % barColors.length];
      var pct      = prod.completion || 0;
      var quarter  = 'Q' + Math.ceil((launch.getMonth()+1)/3) + ' ' + launch.getFullYear();

      return '<div style="display:flex;align-items:center;height:34px;margin-bottom:4px;cursor:pointer"'
        + ' onclick="Router.go(\'product\',{id:' + prod.id + '})"'
        + ' onmouseover="this.style.background=\'var(--gray-50)\'"'
        + ' onmouseout="this.style.background=\'\'">'
        + '<div style="width:140px;flex-shrink:0;font-size:12px;font-weight:600;color:var(--gray-800);padding-right:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="' + prod.name + '">' + prod.name + '</div>'
        + '<div style="flex:1;position:relative;height:20px">'
          + '<div style="position:absolute;left:' + barStart + '%;width:' + barW + '%;height:100%;background:' + color + '22;border-radius:4px;border:1px solid ' + color + '44"></div>'
          + '<div style="position:absolute;left:' + barStart + '%;width:' + (barW*pct/100) + '%;height:100%;background:' + color + ';border-radius:4px;opacity:.85"></div>'
          + (pct>15 ? '<div style="position:absolute;left:' + (barStart+1) + '%;top:50%;transform:translateY(-50%);font-size:9px;font-weight:700;color:#fff;white-space:nowrap">' + pct + '%</div>' : '')
          + '<div style="position:absolute;left:calc(' + posLeft(launch) + '% - 5px);top:50%;transform:translateY(-50%) rotate(45deg);width:10px;height:10px;background:' + color + ';border:2px solid #fff;border-radius:1px" title="Launch: ' + fmt.date(prod.readiness_date) + '"></div>'
        + '</div>'
        + '<div style="width:50px;flex-shrink:0;font-size:10px;color:var(--gray-400);text-align:right;padding-left:6px">' + quarter + '</div>'
        + '</div>';
    }).join('');

    return '<div style="overflow-x:auto">'
      + '<div style="position:relative;height:24px;margin-left:140px;min-width:400px">' + monthHeaders + '</div>'
      + '<div style="position:relative;min-width:400px">'
        + '<div style="position:absolute;top:0;bottom:0;left:140px;right:0;pointer-events:none">' + gridLines + '</div>'
        + rows
      + '</div>'
      + '<div style="display:flex;align-items:center;gap:16px;margin-top:10px;padding-top:10px;border-top:1px solid var(--gray-100)">'
        + '<div style="display:flex;align-items:center;gap:5px"><div style="width:20px;height:3px;background:var(--color-danger);opacity:.6"></div><span style="font-size:10px;color:var(--gray-500)">Today</span></div>'
        + '<div style="display:flex;align-items:center;gap:5px"><div style="width:10px;height:10px;background:var(--gray-600);transform:rotate(45deg);border-radius:1px"></div><span style="font-size:10px;color:var(--gray-500)">Launch date</span></div>'
        + '<span style="font-size:10px;color:var(--gray-400);margin-left:auto">Bar fill = completion %</span>'
      + '</div></div>';
  }

  // ── Helper components ─────────────────────────────────
  function kpi(label, value, icon, color, sub) {
    return '<div class="kpi-card ' + color + '">'
      + '<div class="kpi-label">' + label + '</div>'
      + '<div class="kpi-value">' + value + '</div>'
      + '<div class="kpi-sub">' + sub + '</div>'
      + '<i class="fas ' + icon + ' kpi-icon"></i></div>';
  }

  function kpiCustom(spanId, label, value, icon, color, sub) {
    return '<div class="kpi-card ' + color + '">'
      + '<div class="kpi-label">' + label + '</div>'
      + '<div class="kpi-value" id="' + spanId + '">' + value + '</div>'
      + '<div class="kpi-sub">' + sub + '</div>'
      + '<i class="fas ' + icon + ' kpi-icon"></i></div>';
  }

  function finKpi(label, value, icon, color) {
    var colors = {blue:'var(--blue-600)',green:'var(--green-600)',red:'var(--color-danger)',amber:'var(--color-warning)'};
    return '<div style="text-align:center;padding:14px;background:var(--gray-50);border-radius:var(--radius-md);border:1px solid var(--gray-200)">'
      + '<i class="fas ' + icon + '" style="font-size:18px;color:' + (colors[color]||colors.blue) + ';margin-bottom:8px"></i>'
      + '<div style="font-size:18px;font-weight:700;color:var(--gray-900)">' + value + '</div>'
      + '<div style="font-size:11px;color:var(--gray-500);margin-top:3px">' + label + '</div></div>';
  }

  return { render };

})();
