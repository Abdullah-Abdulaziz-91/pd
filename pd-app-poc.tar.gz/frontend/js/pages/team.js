/* ═══════════════════════════════════════════════════════════
   team.js  —  Team directory
═══════════════════════════════════════════════════════════ */

Pages.Team = (() => {

  async function render() {
    const el = document.getElementById('page-team');
    if (!el) return;
    el.innerHTML = `<div class="loading"><i class="fas fa-spinner fa-spin"></i> Loading…</div>`;

    let members = [];
    try { members = await API.gates.teamMembers(); }
    catch (err) {
      el.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-circle"></i>
        <p>Failed to load team: ${err.message}</p></div>`;
      return;
    }

    const products = Router.state.products || [];
    const workload = {};
    products.forEach(p => {
      if (p.team_lead) workload[p.team_lead] = (workload[p.team_lead] || 0) + 1;
    });

    el.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2>Team</h2>
          <p>${members.length} team member${members.length !== 1 ? 's' : ''}</p>
        </div>
      </div>

      <div class="grid-3">
        ${members.length ? members.map(m => memberCard(m, workload[m.name] || 0)).join('')
          : '<div class="empty-state" style="padding:40px"><i class="fas fa-users"></i><p>No team members found.</p></div>'}
      </div>`;
  }

  function memberCard(m, productCount) {
    const roleBadge = m.role === 'Admin' ? 'badge-critical' : m.role === 'Manager' ? 'badge-on-track' : 'badge-upcoming';
    return `
      <div class="card mb-16">
        <div class="card-body" style="display:flex;align-items:center;gap:14px">
          <div style="width:48px;height:48px;border-radius:50%;background:linear-gradient(135deg,var(--green-500),var(--blue-600));
                      color:#fff;font-size:16px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0">
            ${m.initials || fmt.initials(m.name)}
          </div>
          <div style="flex:1;min-width:0">
            <div style="font-size:14px;font-weight:700;color:var(--gray-900)">${m.name}</div>
            <div style="font-size:12px;color:var(--gray-500);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${m.email}</div>
            <div style="margin-top:6px;display:flex;align-items:center;gap:8px">
              <span class="badge ${roleBadge}">${m.role}</span>
              <span style="font-size:11px;color:var(--gray-400)">${productCount} product${productCount !== 1 ? 's' : ''} led</span>
            </div>
          </div>
        </div>
      </div>`;
  }

  return { render };

})();
