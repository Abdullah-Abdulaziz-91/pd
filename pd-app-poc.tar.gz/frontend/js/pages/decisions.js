/* ═══════════════════════════════════════════════════════════
   decisions.js  —  Decisions & Risks (portfolio-wide)
═══════════════════════════════════════════════════════════ */

Pages.Decisions = (() => {

  async function render() {
    const el = document.getElementById('page-decisions');
    if (!el) return;

    const products = Router.state.products || [];
    const risks    = Router.state.risks    || [];

    const atRiskProds = products
      .filter(p => p.action_required && p.action_required !== 'On Track')
      .sort((a, b) => {
        const o = { Critical: 0, High: 1, Medium: 2, Low: 3 };
        return (o[a.priority] || 9) - (o[b.priority] || 9);
      });

    const sortedRisks = [...risks].sort((a, b) => (b.risk_score || 0) - (a.risk_score || 0));
    const openRisks = risks.filter(r => r.status === 'Open').length;
    const criticalRisks = risks.filter(r => (r.risk_score || 0) >= 9).length;

    const byProduct = {};
    products.forEach(p => { byProduct[p.id] = p; });

    el.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2>Decisions & Risks</h2>
          <p>${atRiskProds.length} products need attention · ${openRisks} open risks</p>
        </div>
      </div>

      <div class="grid-3 mb-24">
        ${miniKpi('Needs Attention', atRiskProds.length, 'fa-exclamation-triangle', atRiskProds.length > 0 ? 'amber' : 'green')}
        ${miniKpi('Open Risks', openRisks, 'fa-shield-alt', openRisks > 0 ? 'red' : 'green')}
        ${miniKpi('Critical Risk Score (≥9)', criticalRisks, 'fa-fire', criticalRisks > 0 ? 'red' : 'green')}
      </div>

      <div class="card mb-24">
        <div class="card-header">
          <div class="card-title" style="color:var(--color-danger)"><i class="fas fa-exclamation-triangle"></i> Products needing attention</div>
        </div>
        <div class="card-body-flush">
          ${atRiskProds.length ? atRiskProds.map(p => `
            <div style="display:flex;align-items:center;gap:12px;padding:12px 20px;border-bottom:1px solid var(--gray-100);cursor:pointer"
                 onclick="Router.go('product',{id:${p.id}})"
                 onmouseover="this.style.background='var(--gray-50)'"
                 onmouseout="this.style.background=''">
              <div style="flex:1;min-width:0">
                <div style="font-size:13px;font-weight:600;color:var(--gray-900)">${p.name}</div>
                <div style="font-size:11px;color:var(--gray-500);margin-top:2px">${badge.stage(p.status)} ${badge.action(p.action_required)}</div>
              </div>
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:13px;font-weight:700;color:var(--gray-800)">${p.completion || 0}%</div>
                <div style="font-size:10px;color:var(--gray-400)">complete</div>
              </div>
            </div>`).join('')
            : '<div class="empty-state" style="padding:32px"><i class="fas fa-check-circle" style="color:var(--green-400)"></i><p>All products on track</p></div>'}
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <div class="card-title"><i class="fas fa-shield-alt"></i> Risk register (${risks.length})</div>
        </div>
        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Product</th><th>Risk Title</th><th>Category</th><th>Likelihood</th>
                <th>Impact</th><th>Score</th><th>Status</th><th>Owner</th>
              </tr>
            </thead>
            <tbody>
              ${sortedRisks.length ? sortedRisks.map(r => {
                const scoreColor = (r.risk_score || 0) >= 9 ? '#7C2D2D'
                  : (r.risk_score || 0) >= 6 ? 'var(--color-danger)'
                  : (r.risk_score || 0) >= 4 ? 'var(--color-warning)'
                  : 'var(--green-600)';
                const prod = byProduct[r.product_id];
                return `
                <tr style="cursor:pointer" onclick="Router.go('product',{id:${r.product_id}})">
                  <td class="primary">${prod ? prod.name : 'Product ' + r.product_id}</td>
                  <td>${r.title}</td>
                  <td><span class="badge" style="background:var(--gray-100);color:var(--gray-700)">${r.category || '—'}</span></td>
                  <td>${badge.priority(r.likelihood)}</td>
                  <td>${badge.priority(r.impact)}</td>
                  <td><strong style="color:${scoreColor};font-size:15px">${r.risk_score || '—'}</strong></td>
                  <td>${badge.riskStatus(r.status)}</td>
                  <td style="font-size:12px">${r.owner || '—'}</td>
                </tr>`;
              }).join('')
              : `<tr><td colspan="8" style="text-align:center;padding:40px;color:var(--gray-400)">No risks recorded across the portfolio</td></tr>`}
            </tbody>
          </table>
        </div>
      </div>`;
  }

  function miniKpi(label, value, icon, color) {
    const colors = { green: 'var(--green-600)', red: 'var(--color-danger)', amber: 'var(--color-warning)', blue: 'var(--blue-600)' };
    const bgs    = { green: 'var(--color-success-bg)', red: 'var(--color-danger-bg)', amber: 'var(--color-warning-bg)', blue: 'var(--color-info-bg)' };
    return `
      <div style="background:${bgs[color] || 'var(--gray-50)'};border-radius:var(--radius-md);padding:16px;display:flex;align-items:center;gap:12px">
        <div style="width:40px;height:40px;border-radius:var(--radius-sm);background:rgba(255,255,255,0.12);display:flex;align-items:center;justify-content:center;color:${colors[color] || 'var(--gray-500)'};font-size:18px;flex-shrink:0">
          <i class="fas ${icon}"></i>
        </div>
        <div>
          <div style="font-size:20px;font-weight:700;color:var(--gray-900)">${value}</div>
          <div style="font-size:12px;color:var(--gray-600)">${label}</div>
        </div>
      </div>`;
  }

  return { render };

})();
