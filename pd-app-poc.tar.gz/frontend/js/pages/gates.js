/* ═══════════════════════════════════════════════════════════
   gates.js  —  Gates accordion + Heatmap + Partnerships
═══════════════════════════════════════════════════════════ */

let _teamMembers   = [];
let _openGateId    = null;
let _dragGateId    = null;
let _gateOrder     = [];

// ── Load team members once ────────────────────────────────
async function loadTeamMembers() {
  try {
    _teamMembers = await API.gates.teamMembers();
  } catch (_) { _teamMembers = []; }
}

// ── Shared gate health/color logic ────────────────────────
// States: overdue (red) > at risk (amber) > active gate (purple, "you are
// here") > on track (green) > not started (gray). Active-gate = the first
// gate, in order, that isn't yet 100% complete — i.e. where the product
// currently stands in its lifecycle.
const GATE_COLORS = {
  overdue:  { bg: 'var(--red-soft)',    text: 'var(--red)',        border: 'var(--red)' },
  atRisk:   { bg: 'var(--amber-soft)',  text: 'var(--amber)',      border: 'var(--amber)' },
  active:   { bg: 'var(--purple-soft)', text: 'var(--purple-text)',border: 'var(--purple)' },
  onTrack:  { bg: 'var(--green-soft)',  text: 'var(--green-text)', border: 'var(--green)' },
  notStarted: { bg: 'var(--none-bg)',   text: 'var(--ink3)',       border: 'var(--line)' },
};

function findActiveGateNumber(gates) {
  const sorted = [...gates].sort((a, b) => a.gate_number - b.gate_number);
  const g = sorted.find(x => parseFloat(x.gate_pct || 0) < 100);
  return g ? g.gate_number : null;
}

function gateHealthState(g, isActive) {
  const pct      = parseFloat(g.gate_pct || 0);
  const hasDates = g.gate_due_date;
  const now      = new Date();
  const due      = g.gate_due_date ? new Date(g.gate_due_date) : null;
  const start    = g.gate_start_date ? new Date(g.gate_start_date) : null;

  if (g.has_overdue_task || g.gate_overdue || (due && now > due && pct < 100)) return 'overdue';

  if (due && start) {
    const timePct = Math.min(100, ((now - start) / (due - start)) * 100);
    if (timePct > 0 && pct < timePct * 0.75) return 'atRisk';
  }

  if (isActive) return 'active';
  if (!hasDates && pct === 0) return 'notStarted';
  return 'onTrack';
}

// ═══════════════════════════════════════════════════════════
// HEATMAP
// ═══════════════════════════════════════════════════════════
async function renderGateHeatmap(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = `<div class="loading"><i class="fas fa-spinner fa-spin"></i> Loading…</div>`;

  let data;
  try { data = await API.gates.heatmap(); }
  catch (_) { data = []; }

  if (!data.length) {
    el.innerHTML = `<div class="empty-state" style="padding:30px">
      <i class="fas fa-th"></i>
      <p>Add products and set gate dates to see the heatmap.</p>
    </div>`;
    return;
  }

  const shortNames = ['Prod Def','Sol Design','Partnership','Build',
                      'Pilot','Commerc.','Ops Ready','GTM','Launch','Revenue'];

  el.innerHTML = `
    <div style="overflow-x:auto">
      <table style="width:100%;border-collapse:separate;border-spacing:2px;min-width:880px">
        <thead>
          <tr>
            <th style="text-align:left;padding:8px 12px;font-size:11px;font-weight:700;
                       color:var(--ink3);text-transform:uppercase;letter-spacing:.05em;
                       background:var(--glass2);border-radius:6px;min-width:160px">
              Progress
            </th>
            <th style="text-align:center;padding:6px 8px;font-size:10px;font-weight:700;
                       color:var(--ink2);background:var(--glass2);border-radius:4px;
                       min-width:64px;border:1px solid var(--line)">Overall</th>
            ${shortNames.map((n,i) => `
              <th style="text-align:center;padding:6px 4px;font-size:10px;font-weight:700;
                         color:var(--ink2);background:var(--glass2);border-radius:4px;
                         min-width:72px" title="Gate ${i+1}">
                <div>G${i+1}</div>
                <div style="font-weight:400;color:var(--ink3);font-size:9px">${n}</div>
              </th>`).join('')}
          </tr>
        </thead>
        <tbody>
          ${data.map(p => {
            const overall = p.gates.reduce((s,g) =>
              s + parseFloat(g.gate_pct||0) * parseFloat(g.gate_weight) / 100, 0);
            const ov  = Math.round(overall * 10) / 10;
            const activeGateNumber = findActiveGateNumber(p.gates);

            // Overall RAG uses product start_date → readiness_date only —
            // "active gate" is a per-gate concept, not shown on Overall.
            function overallState(pct, startDate, launchDate) {
              const now    = new Date();
              const start  = startDate  ? new Date(startDate)  : null;
              const launch = launchDate ? new Date(launchDate) : null;
              if (launch && now > launch && pct < 100) return 'overdue';
              if (start && launch) {
                const timePct = Math.min(100, ((now - start) / (launch - start)) * 100);
                if (timePct > 0 && pct < timePct * 0.75) return 'atRisk';
              }
              if (!start && !launch && pct === 0) return 'notStarted';
              return 'onTrack';
            }

            const ovc = GATE_COLORS[overallState(ov, p.start_date, p.readiness_date)];
            return `
              <tr onclick="Router.go('product',{id:${p.product_id}})"
                  style="cursor:pointer"
                  onmouseover="this.querySelectorAll('td').forEach(td=>td.style.opacity='.85')"
                  onmouseout="this.querySelectorAll('td').forEach(td=>td.style.opacity='1')">
                <td style="padding:8px 12px;font-size:13px;font-weight:600;
                           color:var(--ink);background:var(--glass);border-radius:6px">
                  ${p.product_name}
                </td>
                <td style="padding:0;border-radius:4px;overflow:hidden">
                  <div style="background:${ovc.bg};color:${ovc.text};
                              border:1px solid ${ovc.border};
                              border-radius:4px;padding:8px 4px;text-align:center;
                              font-weight:800;font-size:12px">
                    ${ov}%
                  </div>
                </td>
                ${p.gates.map(g => {
                  const c   = GATE_COLORS[gateHealthState(g, g.gate_number === activeGateNumber)];
                  const pct = Math.round(parseFloat(g.gate_pct||0));
                  const timeC = parseFloat(g.time_consumed_pct||0);
                  const tip = `Gate ${g.gate_number}: ${g.gate_name}\n${pct}% complete${timeC>0?' · '+Math.round(timeC)+'% time used':''}\n${g.complete_tasks} done · ${g.in_progress_tasks} in progress · ${g.not_started_tasks} not started${g.na_tasks>0?' · '+g.na_tasks+' N/A':''}${g.gate_due_date?'\nDue: '+g.gate_due_date:''}${g.has_overdue_task||g.gate_overdue?' ⚠ OVERDUE':''}`;
                  return `
                    <td style="padding:0;border-radius:4px;overflow:hidden">
                      <div style="background:${c.bg};color:${c.text};
                                  border:1px solid ${c.border};border-radius:4px;
                                  padding:8px 4px;text-align:center;
                                  font-weight:700;font-size:11px;min-height:42px;
                                  display:flex;flex-direction:column;align-items:center;
                                  justify-content:center;gap:2px"
                           title="${tip}">
                        ${pct > 0 ? `<span>${pct}%</span>` : '<span style="opacity:.4">—</span>'}
                        ${g.has_overdue_task || g.gate_overdue
                          ? '<i class="fas fa-exclamation-circle" style="font-size:9px"></i>' : ''}
                      </div>
                    </td>`;
                }).join('')}
              </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>

    <!-- Legend -->
    <div style="display:flex;align-items:center;gap:12px;margin-top:12px;flex-wrap:wrap">
      <span style="font-size:11px;font-weight:700;color:var(--ink3)">Legend:</span>
      ${[
        ['Overdue',     GATE_COLORS.overdue],
        ['At risk',     GATE_COLORS.atRisk],
        ['On track',    GATE_COLORS.onTrack],
        ['Active gate', GATE_COLORS.active],
        ['Not Started', GATE_COLORS.notStarted],
    ].map(([l,c]) => `
        <div style="display:flex;align-items:center;gap:5px">
          <div style="width:26px;height:18px;background:${c.bg};border:1px solid ${c.border};
                      border-radius:3px"></div>
          <span style="font-size:11px;color:var(--ink2);font-weight:600">${l}</span>
        </div>`).join('')}
    </div>`;
}

// ═══════════════════════════════════════════════════════════
// GATES TAB — Accordion G1–G10
// ═══════════════════════════════════════════════════════════
async function renderGatesTab(productId) {
  const el = document.getElementById('product-tab-content');
  if (!el) return;
  el.innerHTML = `<div class="loading"><i class="fas fa-spinner fa-spin"></i> Loading gates…</div>`;

  await loadTeamMembers();

  let gateData;
  try { gateData = await API.gates.progress(productId); }
  catch (err) {
    el.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-circle"></i>
      <p>Failed to load gates: ${err.message}</p></div>`;
    return;
  }

  _gateOrder = gateData.map(g => g.gate_id);
  const isAdmin  = Auth.isAdmin();
  const canEdit  = Auth.isManagerOrAbove();

  const overall = gateData.reduce((s,g) =>
    s + parseFloat(g.gate_pct||0) * parseFloat(g.gate_weight) / 100, 0);

  const _activeGateNumber = findActiveGateNumber(gateData);
  function cardColor(g) {
    const state = gateHealthState(g, g.gate_number === _activeGateNumber);
    const c = GATE_COLORS[state];
    return { bg: c.bg, accent: c.border, text: c.text };
  }

  el.innerHTML = `
    <!-- Overall progress -->
    <div class="card mb-20">
      <div class="card-body">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">
          <div>
            <div style="font-size:13px;font-weight:700;color:var(--gray-700)">
              Overall Gate Progress
            </div>
            <div style="font-size:11px;color:var(--gray-500)">
              Weighted average across 10 gates · N/A excluded
            </div>
          </div>
          <div style="font-size:30px;font-weight:800;color:${
            overall>=75?'var(--green-600)':overall>=50?'var(--blue-600)':
            overall>=25?'var(--color-warning)':'var(--gray-400)'}">
            ${Math.round(overall*10)/10}%
          </div>
        </div>
        <div class="progress-track thick">
          <div class="progress-fill" style="width:${Math.min(100,overall)}%;background:${
            overall>=75?'var(--green-500)':overall>=50?'var(--blue-600)':
            overall>=25?'var(--color-warning)':'var(--gray-300)'}"></div>
        </div>
      </div>
    </div>

    <!-- Gate cards -->
    <div id="gates-container" style="display:flex;flex-direction:column;gap:8px">
      ${gateData.map(g => {
        const c    = cardColor(g);
        const pct  = Math.round(parseFloat(g.gate_pct||0));
        const open = _openGateId === g.gate_id;
        const total    = (g.tasks||[]).filter(t=>t.status!=='N/A').length;
        const complete = (g.tasks||[]).filter(t=>t.status==='Complete').length;

        return `
          <div id="gate-card-${g.gate_id}"
               data-gate-id="${g.gate_id}"
               style="background:var(--glass);backdrop-filter:blur(10px);border-radius:var(--radius-lg);
                      border:1px solid var(--line);
                      overflow:hidden;
                      transition:box-shadow .2s"
               ${isAdmin ? `draggable="true"
                 ondragstart="gateDragStart(event,${g.gate_id})"
                 ondragover="gateDragOver(event,${g.gate_id})"
                 ondrop="gateDrop(event,${g.gate_id})"
                 ondragend="gateDragEnd(event)"` : ''}>

            <!-- Gate header (click to toggle) -->
            <div onclick="toggleGate(${g.gate_id},${productId})"
                 style="display:flex;align-items:center;gap:12px;padding:14px 18px;
                        cursor:pointer;background:${c.bg};
                        border-bottom:${open?'1px solid var(--line)':'none'}">

              ${isAdmin ? `
              <div style="color:var(--ink3);cursor:grab;padding:2px 4px;font-size:14px"
                   title="Drag to reorder" onclick="event.stopPropagation()">
                <i class="fas fa-grip-vertical"></i>
              </div>` : ''}

              <!-- Gate number badge -->
              <div style="width:40px;height:40px;border-radius:var(--radius-md);
                          background:${c.accent};color:#fff;display:flex;
                          align-items:center;justify-content:center;
                          font-size:12px;font-weight:800;flex-shrink:0">
                G${g.gate_number}
              </div>

              <div style="flex:1;min-width:0">
                <div style="font-size:14px;font-weight:700;color:var(--ink)">
                  ${g.gate_name}
                </div>
                <div style="font-size:11px;color:var(--ink3);margin-top:2px">
                  ${complete}/${total} tasks
                  ${g.has_overdue_task||g.gate_overdue
                    ? '<span style="color:var(--red);font-weight:600;margin-left:6px"><i class="fas fa-exclamation-circle"></i> Overdue</span>' : ''}
                  ${g.gate_due_date ? `· Due: <strong>${fmt.date(g.gate_due_date)}</strong>` : ''}
                </div>
              </div>

              <!-- Progress -->
              <div style="text-align:right;flex-shrink:0">
                <div style="font-size:20px;font-weight:800;color:${c.accent}">${pct}%</div>
                <div style="font-size:10px;color:var(--ink3)">Weight ${g.gate_weight}%</div>
              </div>

              <!-- Gate lead badge -->
              <div title="Gate Lead" style="flex-shrink:0;display:flex;align-items:center;gap:6px;
                          padding:5px 10px;border-radius:20px;font-size:11px;font-weight:600;
                          background:${g.gate_lead ? 'var(--glass2)' : 'var(--none-bg)'};
                          color:${g.gate_lead ? 'var(--ink2)' : 'var(--ink3)'};
                          border:1px solid ${g.gate_lead ? c.accent : 'var(--line)'}">
                <i class="fas fa-user" style="font-size:10px"></i>
                ${g.gate_lead || 'Unassigned'}
              </div>

              <!-- Set date/lead (manager+) -->
              ${canEdit ? `
              <button class="btn btn-secondary btn-sm"
                      style="flex-shrink:0"
                      title="Set dates &amp; gate lead"
                      onclick="event.stopPropagation();openGateDateModal(${g.gate_id},'${g.gate_name}',${productId},'${g.gate_due_date||''}','${g.gate_lead||''}')">
                <i class="fas fa-calendar-alt"></i>
              </button>` : ''}

              <!-- Chevron -->
              <i class="fas fa-chevron-${open?'up':'down'}"
                 style="color:${c.accent};flex-shrink:0;font-size:12px"></i>
            </div>

            <!-- Subtasks (accordion) -->
            <div id="gate-tasks-${g.gate_id}" style="display:${open?'block':'none'}">
              ${renderGateTasksTable(g, productId, canEdit, isAdmin)}
            </div>
          </div>`;
      }).join('')}
    </div>
  `;
}

function renderGateTasksTable(g, productId, canEdit, isAdmin) {
  const tasks = g.tasks || [];
  const memberOptions = _teamMembers.map(m =>
    `<option value="${m.name}">${m.name} (${m.role})</option>`
  ).join('');

  return `
    <div style="padding:0 0 8px 0">
      <table class="data-table">
        <thead>
          <tr>
            <th>Task</th>
            <th>Workstream</th>
            <th>Status</th>
            <th>Owner</th>
            <th>Due Date</th>
            ${isAdmin ? '<th style="width:40px"></th>' : ''}
          </tr>
        </thead>
        <tbody>
          ${tasks.map(t => `
            <tr id="task-row-${t.task_id}">
              <td style="font-weight:500;color:var(--gray-900)">${t.task_name}</td>
              <td>
                <span style="font-size:11px;padding:2px 8px;border-radius:10px;
                             background:var(--gray-100);color:var(--gray-600);font-weight:600">
                  ${t.workstream||'—'}
                </span>
              </td>
              <td>
                <select onchange="updateGateTaskStatus(${productId},${t.task_id},this.value,this,${g.gate_id})"
                        ${!canEdit?'disabled':''}
                        style="padding:5px 8px;border-radius:var(--radius-sm);font-size:12px;
                               font-weight:600;border:1.5px solid;outline:none;
                               cursor:${canEdit?'pointer':'default'};
                               ${statusStyle(t.status)}">
                  ${['Not Started','In Progress','Complete','N/A'].map(s=>
                    `<option value="${s}" ${t.status===s?'selected':''}>${s}</option>`
                  ).join('')}
                </select>
              </td>
              <td>
                ${canEdit ? `
                  <select onchange="updateGateTaskOwner(${productId},${t.task_id},this.value)"
                          style="padding:5px 8px;border-radius:var(--radius-sm);font-size:12px;
                                 border:1px solid var(--gray-200);outline:none;max-width:140px">
                    <option value="">— Assign —</option>
                    ${memberOptions.replace(
                      `value="${t.owner||''}"`,
                      `value="${t.owner||''}" selected`
                    )}
                  </select>
                ` : `<span style="font-size:12px;color:var(--gray-600)">${t.owner||'—'}</span>`}
              </td>
              <td>
                ${canEdit ? `
                  <input type="date" value="${t.due_date||''}"
                         onchange="updateGateTaskDate(${productId},${t.task_id},this.value)"
                         style="border:1px solid var(--gray-200);border-radius:var(--radius-sm);
                                padding:4px 6px;font-size:12px;outline:none">
                ` : `<span style="font-size:12px;color:var(--gray-600)">${t.due_date?fmt.date(t.due_date):'—'}</span>`}
              </td>
              ${isAdmin ? `
              <td>
                <button class="btn-icon danger" title="Remove"
                        onclick="deleteGateTask(${t.task_id},${productId})">
                  <i class="fas fa-times"></i>
                </button>
              </td>` : ''}
            </tr>`).join('')}
        </tbody>
      </table>
      ${isAdmin ? `
      <div style="padding:8px 16px">
        <button class="btn btn-secondary btn-sm"
                onclick="openAddGateTask(${g.gate_id},'${g.gate_name}',${productId})">
          <i class="fas fa-plus"></i> Add Task
        </button>
      </div>` : ''}
    </div>`;
}

function statusStyle(s) {
  return {
    'Complete':    'border-color:var(--green);background:var(--green-soft);color:var(--green-text)',
    'In Progress': 'border-color:var(--purple);background:var(--purple-soft);color:var(--purple-text)',
    'Not Started': 'border-color:var(--line);background:var(--glass2);color:var(--ink3)',
    'N/A':         'border-color:var(--line);background:var(--none-bg);color:var(--ink3)',
  }[s] || '';
}

// ── Toggle gate accordion ─────────────────────────────────
async function toggleGate(gateId, productId) {
  const el = document.getElementById(`gate-tasks-${gateId}`);
  if (!el) return;
  const isOpen = el.style.display !== 'none';
  if (isOpen) {
    el.style.display = 'none';
    _openGateId = null;
  } else {
    // Close all others
    document.querySelectorAll('[id^="gate-tasks-"]').forEach(e => e.style.display = 'none');
    el.style.display = 'block';
    _openGateId = gateId;
  }
}

// ── Update task status ────────────────────────────────────
async function updateGateTaskStatus(productId, taskId, status, sel, gateId) {
  sel.style.cssText = `padding:5px 8px;border-radius:var(--radius-sm);font-size:12px;font-weight:600;border:1.5px solid;outline:none;cursor:pointer;${statusStyle(status)}`;
  try {
    await API.gates.updateTaskStatus({ product_id: productId, gate_task_id: taskId, status });
    Toast.show(`Marked as ${status}`, 'success');
    // Full refresh of gates tab to show updated scores
    await renderGatesTab(productId);
  } catch (err) { Toast.show(err.message, 'error'); }
}

async function updateGateTaskOwner(productId, taskId, owner) {
  try { await API.gates.updateTaskStatus({ product_id: productId, gate_task_id: taskId, owner }); }
  catch (_) {}
}

async function updateGateTaskDate(productId, taskId, date) {
  try { await API.gates.updateTaskStatus({ product_id: productId, gate_task_id: taskId, due_date: date }); }
  catch (_) {}
}

// ── Gate date/lead modal ──────────────────────────────────
function openGateDateModal(gateId, gateName, productId, currentDate, currentLead, currentStart) {
  const memberOptions = _teamMembers.map(m =>
    `<option value="${m.name}" ${currentLead===m.name?'selected':''}>${m.name}</option>`
  ).join('');

  Modals.open({
    title: `Set Dates & Lead — ${gateName}`,
    size:  'sm',
    body: `
      <div class="form-group">
        <label class="form-label">Start Date</label>
        <input type="date" class="form-input" id="gate-start-input" value="${currentStart||''}">
        <div class="form-hint">Default: previous gate due date. Gates can run in parallel.</div>
      </div>
      <div class="form-group">
        <label class="form-label">Due Date</label>
        <input type="date" class="form-input" id="gate-date-input" value="${currentDate||''}">
      </div>
      <div class="form-group">
        <label class="form-label">Gate Lead</label>
        <select class="form-select" id="gate-lead-input">
          <option value="">— Select lead —</option>
          ${memberOptions}
        </select>
      </div>`,
    footer: `
      <button class="btn btn-secondary" onclick="Modals.close()">Cancel</button>
      <button class="btn btn-primary" onclick="saveGateDate(${gateId},${productId})">
        <i class="fas fa-save"></i> Save
      </button>`,
  });
}

async function saveGateDate(gateId, productId) {
  const due_date   = document.getElementById('gate-date-input')?.value;
  const start_date = document.getElementById('gate-start-input')?.value;
  const gate_lead  = document.getElementById('gate-lead-input')?.value;
  try {
    await API.gates.setDate({ product_id: productId, gate_id: gateId, due_date, start_date, gate_lead });
    Modals.close();
    Toast.show('Gate updated.', 'success');
    await renderGatesTab(productId);
  } catch (err) { Toast.show(err.message, 'error'); }
}

// ── Add gate task ─────────────────────────────────────────
function openAddGateTask(gateId, gateName, productId) {
  Modals.form({
    title: `Add Task — ${gateName}`,
    fields: [
      { key:'task_name',  label:'Task Name',  required:true },
      { key:'workstream', label:'Workstream', placeholder:'e.g. Product Development' },
    ],
    submitText: 'Add Task',
    onSubmit: async (data) => {
      try {
        await API.gates.addTask(gateId, data);
        Modals.close();
        Toast.show('Task added.', 'success');
        _openGateId = gateId;
        await renderGatesTab(productId);
      } catch (err) { Toast.show(err.message, 'error'); }
    },
  });
}

async function deleteGateTask(taskId, productId) {
  Modals.confirm({
    title: 'Remove Task', danger: true,
    message: 'Remove this task from all products?',
    confirmText: 'Remove',
    onConfirm: async () => {
      try {
        await API.gates.deleteTask(taskId);
        Toast.show('Task removed.', 'success');
        await renderGatesTab(productId);
      } catch (err) { Toast.show(err.message, 'error'); }
    },
  });
}

// ── Drag and drop (Admin) ─────────────────────────────────
function gateDragStart(e, gateId) {
  _dragGateId = gateId;
  e.currentTarget.style.opacity = '0.5';
  e.dataTransfer.effectAllowed = 'move';
}

function gateDragOver(e, gateId) {
  e.preventDefault();
  e.dataTransfer.dropEffect = 'move';
  if (_dragGateId !== gateId) {
    const target = document.getElementById(`gate-card-${gateId}`);
    if (target) target.style.borderColor = 'var(--green-500)';
  }
}

function gateDragEnd(e) {
  e.currentTarget.style.opacity = '1';
  document.querySelectorAll('[id^="gate-card-"]').forEach(el => {
    el.style.borderColor = '';
  });
}

async function gateDrop(e, targetGateId) {
  e.preventDefault();
  if (_dragGateId === targetGateId) return;

  const container = document.getElementById('gates-container');
  const dragEl  = document.getElementById(`gate-card-${_dragGateId}`);
  const targetEl = document.getElementById(`gate-card-${targetGateId}`);
  if (!dragEl || !targetEl || !container) return;

  // Reorder in DOM
  const cards = [...container.querySelectorAll('[id^="gate-card-"]')];
  const dragIdx   = cards.indexOf(dragEl);
  const targetIdx = cards.indexOf(targetEl);
  if (dragIdx < targetIdx) {
    container.insertBefore(dragEl, targetEl.nextSibling);
  } else {
    container.insertBefore(dragEl, targetEl);
  }

  // Save new order
  const newOrder = [...container.querySelectorAll('[id^="gate-card-"]')]
    .map(el => parseInt(el.dataset.gateId));

  try {
    await API.gates.reorder({ order: newOrder });
    Toast.show('Gate order saved.', 'success');
  } catch (err) { Toast.show(err.message, 'error'); }

  _dragGateId = null;
  document.querySelectorAll('[id^="gate-card-"]').forEach(el => {
    el.style.opacity = '1';
    el.style.borderColor = '';
  });
}

// ═══════════════════════════════════════════════════════════
// PARTNERSHIPS TAB
// ═══════════════════════════════════════════════════════════
async function renderPartnershipsTab(productId) {
  const el = document.getElementById('product-tab-content');
  if (!el) return;
  el.innerHTML = `<div class="loading"><i class="fas fa-spinner fa-spin"></i> Loading…</div>`;

  let partners;
  try { partners = await API.partnerships.list(productId); }
  catch (_) { partners = []; }

  const canEdit = Auth.isManagerOrAbove();
  const types   = ['Hardware', 'Software', 'Other'];
  const statusColors = {
    'Partner Identified':   { bg:'var(--glass2)',       text:'var(--ink3)' },
    'Agreement Development':{ bg:'var(--purple-soft)',  text:'var(--purple-text)' },
    'Agreement Signed':     { bg:'var(--green-soft)',   text:'var(--green-text)' },
    'On Hold':              { bg:'var(--red-soft)',     text:'var(--red)' },
  };
  const typeColors = {
    Hardware: { icon:'fa-microchip',  color:'var(--blue-600)',  bg:'var(--color-info-bg)' },
    Software: { icon:'fa-code',       color:'var(--green-600)', bg:'var(--color-success-bg)' },
    Other:    { icon:'fa-handshake',  color:'var(--color-warning)', bg:'var(--color-warning-bg)' },
  };

  el.innerHTML = `
    <div class="page-header" style="margin-bottom:16px">
      <div>
        <div style="font-size:16px;font-weight:700;color:var(--gray-900)">Partnerships</div>
        <div style="font-size:13px;color:var(--gray-500)">${partners.length} partner${partners.length!==1?'s':''} across all categories</div>
      </div>
      ${canEdit ? `
      <button class="btn btn-primary btn-sm"
              onclick="openAddPartnership(${productId})">
        <i class="fas fa-plus"></i> Add Partner
      </button>` : ''}
    </div>

    ${types.map(type => {
      const tc   = typeColors[type];
      const list = partners.filter(p => p.type === type);
      return `
        <div class="card mb-16">
          <div class="card-header" style="background:${tc.bg}">
            <div class="card-title" style="color:var(--ink)">
              <i class="fas ${tc.icon}" style="color:${tc.color}"></i> ${type} Partnerships
              <span style="font-size:12px;font-weight:400;color:var(--ink2);margin-left:6px">
                (${list.length})
              </span>
            </div>
            ${canEdit ? `
            <button class="btn btn-secondary btn-sm"
                    onclick="openAddPartnership(${productId},'${type}')">
              <i class="fas fa-plus"></i>
            </button>` : ''}
          </div>
          ${list.length ? `
          <div class="table-wrap">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Partner</th><th>Status</th><th>Contact</th>
                  <th>Description</th>${canEdit?'<th></th>':''}
                </tr>
              </thead>
              <tbody>
                ${list.map(p => {
                  const sc = statusColors[p.status] || statusColors['Partner Identified'];
                  return `
                    <tr>
                      <td class="primary">${p.partner_name}</td>
                      <td>
                        <span style="padding:3px 10px;border-radius:20px;font-size:11px;
                                     font-weight:700;background:${sc.bg};color:${sc.text}">
                          ${p.status}
                        </span>
                      </td>
                      <td style="font-size:12px;color:var(--gray-600)">
                        ${p.contact_name||'—'}
                        ${p.contact_email?`<br><a href="mailto:${p.contact_email}"
                          style="color:var(--blue-600);font-size:11px">${p.contact_email}</a>`:''}
                      </td>
                      <td style="font-size:12px;color:var(--gray-500);max-width:200px">
                        ${p.description||p.notes||'—'}
                      </td>
                      ${canEdit ? `
                      <td>
                        <div style="display:flex;gap:4px">
                          <button class="btn-icon" onclick="openEditPartnership(${p.id},${productId})">
                            <i class="fas fa-edit"></i>
                          </button>
                          <button class="btn-icon danger" onclick="deletePartnership(${p.id},${productId})">
                            <i class="fas fa-trash"></i>
                          </button>
                        </div>
                      </td>` : ''}
                    </tr>`;
                }).join('')}
              </tbody>
            </table>
          </div>` : `
          <div class="empty-state" style="padding:30px">
            <i class="fas ${tc.icon}" style="color:${tc.color}"></i>
            <p>No ${type.toLowerCase()} partners yet.
              ${canEdit?`<button class="btn-link" onclick="openAddPartnership(${productId},'${type}')">Add one</button>`:''}
            </p>
          </div>`}
        </div>`;
    }).join('')}
  `;
}

function openAddPartnership(productId, defaultType = 'Hardware') {
  Modals.form({
    title: 'Add Partnership',
    fields: [
      { key:'partner_name',  label:'Partner Name',   required:true },
      { key:'type',          label:'Type', type:'select',
        options:['Hardware','Software','Other'], value:defaultType },
      { key:'status',        label:'Status', type:'select',
        options:['Partner Identified','Agreement Development','Agreement Signed','On Hold'],
        value:'Partner Identified' },
      { key:'contact_name',  label:'Contact Name',  placeholder:'Full name' },
      { key:'contact_email', label:'Contact Email', type:'email' },
      { key:'description',   label:'Description',   type:'textarea' },
    ],
    submitText: 'Add Partner',
    onSubmit: async (data) => {
      try {
        await API.partnerships.create(productId, data);
        Modals.close();
        Toast.show('Partner added.', 'success');
        await renderPartnershipsTab(productId);
      } catch (err) { Toast.show(err.message, 'error'); }
    },
  });
}

function openEditPartnership(partnerId, productId) {
  // Fetch and pre-fill — simplified
  Modals.open({
    title: 'Edit Partnership',
    size: 'sm',
    body: `
      <div class="form-group">
        <label class="form-label">Status</label>
        <select class="form-select" id="ep-status">
          ${['Partner Identified','Agreement Development','Agreement Signed','On Hold']
            .map(s => `<option value="${s}">${s}</option>`).join('')}
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Notes</label>
        <textarea class="form-textarea" id="ep-notes" rows="3"></textarea>
      </div>`,
    footer: `
      <button class="btn btn-secondary" onclick="Modals.close()">Cancel</button>
      <button class="btn btn-primary" onclick="saveEditPartnership(${partnerId},${productId})">
        Save
      </button>`,
  });
}

async function saveEditPartnership(partnerId, productId) {
  const status = document.getElementById('ep-status')?.value;
  const notes  = document.getElementById('ep-notes')?.value;
  try {
    await API.partnerships.update(partnerId, { status, notes });
    Modals.close();
    Toast.show('Updated.', 'success');
    await renderPartnershipsTab(productId);
  } catch (err) { Toast.show(err.message, 'error'); }
}

async function deletePartnership(partnerId, productId) {
  Modals.confirm({
    title: 'Remove Partner', danger: true,
    message: 'Remove this partnership?',
    confirmText: 'Remove',
    onConfirm: async () => {
      try {
        await API.partnerships.delete(partnerId);
        Toast.show('Removed.', 'success');
        await renderPartnershipsTab(productId);
      } catch (err) { Toast.show(err.message, 'error'); }
    },
  });
}
