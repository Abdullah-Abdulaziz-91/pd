/* ═══════════════════════════════════════════════════════════
   portfolio.js  —  Product Portfolio page
═══════════════════════════════════════════════════════════ */

Pages.Portfolio = (() => {

  var _filter = 'All';
  var _search = '';
  var _sortBy = 'priority';

  // ── RENDER ───────────────────────────────────────────────
  async function render(params) {
    params = params || {};
    var el = document.getElementById('page-portfolio');
    if (!el) return;

    if (params.search) _search = params.search;

    var products = Router.state.products || [];
    var stages   = ['All','Concept','Development','Validation','Pilot','Scale-up','Commercial'];

    // Filter
    var filtered = products.filter(function(p) {
      var matchStage  = _filter === 'All' || p.status === _filter;
      var matchSearch = !_search
        || p.name.toLowerCase().includes(_search.toLowerCase())
        || (p.description||'').toLowerCase().includes(_search.toLowerCase())
        || (p.team_lead||'').toLowerCase().includes(_search.toLowerCase());
      return matchStage && matchSearch;
    });

    // Sort
    var priorityOrder = {Critical:0,High:1,Medium:2,Low:3};
    if (_sortBy === 'priority') {
      filtered.sort(function(a,b){ return (priorityOrder[a.priority]||9)-(priorityOrder[b.priority]||9); });
    } else if (_sortBy === 'completion') {
      filtered.sort(function(a,b){ return b.completion-a.completion; });
    } else if (_sortBy === 'name') {
      filtered.sort(function(a,b){ return a.name.localeCompare(b.name); });
    }

    // Stage counts
    var stageCounts = {};
    stages.slice(1).forEach(function(s) {
      stageCounts[s] = products.filter(function(p){ return p.status===s; }).length;
    });

    // Filter buttons
    var filterBtns = stages.map(function(s) {
      var count = s === 'All' ? '' : ' <span style="opacity:.7">('+stageCounts[s]+')</span>';
      return '<button class="filter-btn ' + (_filter===s?'active':'') + '" onclick="Pages.Portfolio.setFilter(\''+s+'\')">'
        + s + count + '</button>';
    }).join('');

    // Sort + search bar
    var controls = '<select onchange="Pages.Portfolio.setSort(this.value)"'
      + ' style="padding:7px 12px;border:1.5px solid var(--gray-200);border-radius:20px;font-size:12px;outline:none;background:var(--gray-50);cursor:pointer">'
      + '<option value="priority"'   + (_sortBy==='priority'   ?' selected':'') + '>Sort: Priority</option>'
      + '<option value="completion"' + (_sortBy==='completion' ?' selected':'') + '>Sort: Completion</option>'
      + '<option value="name"'       + (_sortBy==='name'       ?' selected':'') + '>Sort: Name</option>'
      + '</select>'
      + '<div class="filter-search-wrap">'
        + '<i class="fas fa-search"></i>'
        + '<input class="filter-search-input" id="portfolio-search" placeholder="Search products…" value="'
        + (_search||'') + '" oninput="Pages.Portfolio.setSearch(this.value)">'
      + '</div>';

    // Stat row
    var statRow = '<div class="stat-row mb-24">'
      + stages.slice(1).map(function(s) {
          return '<div class="stat-cell" onclick="Pages.Portfolio.setFilter(\''+s+'\')" style="cursor:pointer">'
            + '<div class="stat-cell-label">'+s+'</div>'
            + '<div class="stat-cell-value" style="color:'+( Charts.COLORS.status[s]||'var(--ink3)')+'">'+stageCounts[s]+'</div>'
            + '</div>';
        }).join('')
      + '</div>';

    // Cards
    var cardsHtml = filtered.length
      ? filtered.map(function(p){ return productCard(p); }).join('')
      : '<div class="empty-state"><i class="fas fa-search"></i><p>No products match your filter.</p></div>';

    el.innerHTML = ''
      + '<div class="page-header">'
        + '<div class="page-header-left"><h2>Product Portfolio</h2>'
          + '<p>' + products.length + ' products · ' + filtered.length + ' shown</p></div>'
        + '<div class="page-header-actions">'
          + (Auth.isManagerOrAbove() ? '<button class="btn btn-primary" onclick="Pages.Portfolio.openAddProduct()"><i class="fas fa-plus"></i> Add Product</button>' : '')
        + '</div></div>'
      + statRow
      + '<div class="filter-bar">' + filterBtns
        + '<div class="filter-search" style="margin-left:auto;gap:8px">' + controls + '</div>'
      + '</div>'
      + '<div id="portfolio-grid">' + cardsHtml + '</div>';
  }

  // ── PRODUCT CARD ─────────────────────────────────────────
  function productCard(p) {
    var milestones = Router.getMilestones(p.id);
    var nextMs     = milestones.find(function(m){ return m.status !== 'Done'; });
    var fin        = Router.getFinancials(p.id)[0];
    var pct        = p.completion || 0;

    var priorityCls = (p.priority||'').toLowerCase();
    var barColor = pct>=75 ? 'var(--green-500)' : pct>=40 ? 'var(--blue-600)' : 'var(--color-warning)';

    var metaHtml = ''
      + '<div class="meta-item"><label>Owner</label><span>'+(p.team_lead||'—')+'</span></div>'
      + '<div class="meta-item"><label>Next Milestone</label><span style="font-size:12px">'+(nextMs?nextMs.name:'—')+'</span></div>'
      + '<div class="meta-item"><label>Target Launch</label><span>'+(p.readiness_date?fmt.date(p.readiness_date):'—')+'</span></div>'
      + '<div class="meta-item"><label>Action</label>'+badge.action(p.action_required)+'</div>';

    var footerLeft = '';
    if (p.pipeline_value) footerLeft += '<div style="font-size:12px;color:var(--gray-600)"><i class="fas fa-dollar-sign" style="color:var(--green-500)"></i> <strong style="color:var(--gray-800)">'+fmt.currency(p.pipeline_value)+'</strong> pipeline</div>';
    if (p.customer_count) footerLeft += '<div style="font-size:12px;color:var(--gray-600)"><i class="fas fa-users" style="color:var(--blue-600)"></i> <strong style="color:var(--gray-800)">'+p.customer_count+'</strong> customers</div>';
    if (fin) footerLeft += '<div style="font-size:12px;color:var(--gray-600)"><i class="fas fa-wallet" style="color:var(--color-warning)"></i> <strong style="color:var(--gray-800)">'+Math.round(fin.utilization_pct||0)+'%</strong> budget used</div>';

    var footerRight = '';
    if (Auth.isManagerOrAbove()) {
      footerRight += '<button class="btn-icon" title="Edit" onclick="event.stopPropagation();Pages.Portfolio.openEditProduct('+p.id+')"><i class="fas fa-edit"></i></button>';
    }
    if (Auth.isManagerOrAbove()) {
      footerRight += '<button class="btn-icon" title="Archive" onclick="event.stopPropagation();Pages.Portfolio.confirmArchive('+p.id+')"><i class="fas fa-archive"></i></button>';
    }
    if (Auth.isAdmin()) {
      footerRight += '<button class="btn-icon danger" title="Delete permanently" onclick="event.stopPropagation();Pages.Portfolio.confirmDelete('+p.id+')"><i class="fas fa-trash"></i></button>';
    }
    footerRight += '<button class="btn btn-secondary btn-sm" onclick="event.stopPropagation();Router.go(\'product\',{id:'+p.id+'})">View Details <i class="fas fa-arrow-right"></i></button>';

    return '<div class="product-card ' + priorityCls + ' mb-16" onclick="Router.go(\'product\',{id:'+p.id+'})" style="cursor:pointer">'
      + '<div class="product-card-header">'
        + '<div class="product-card-top">'
          + '<div><div class="product-card-name">'+p.name+'</div>'
            + '<div class="product-card-desc">'+(p.description||'')+'</div></div>'
          + '<div style="display:flex;flex-direction:column;align-items:flex-end;gap:6px;flex-shrink:0">'
            + badge.stage(p.status) + badge.priority(p.priority)
          + '</div>'
        + '</div>'
        + Router.stagePipeline(p.status)
        + '<div style="margin-top:12px">'
          + '<div class="progress-label"><span style="font-size:12px;color:var(--gray-600)">Completion</span><span class="pct">'+pct+'%</span></div>'
          + '<div class="progress-track"><div class="progress-fill" style="width:'+pct+'%;background:'+barColor+'"></div></div>'
        + '</div>'
      + '</div>'
      + '<div class="product-card-meta" style="grid-template-columns:1fr 1fr 1fr 1fr">'+metaHtml+'</div>'
      + '<div class="product-card-footer" onclick="event.stopPropagation()">'
        + '<div style="display:flex;gap:16px;align-items:center">'+footerLeft+'</div>'
        + '<div style="display:flex;gap:8px">'+footerRight+'</div>'
      + '</div>'
    + '</div>';
  }

  // ── FILTER / SEARCH / SORT ────────────────────────────────
  function setFilter(f) { _filter = f; render(); }
  function setSearch(q) { _search = q; render(); }
  function setSort(s)   { _sortBy = s; render(); }

  // ── ADD PRODUCT ───────────────────────────────────────────
  async function openAddProduct() {
    // Auto-generate next product code based on existing products
    var existing = Router.state.products || [];
    var maxNum = 0;
    existing.forEach(function(p) {
      var m = (p.product_code||'').match(/P0*(\d+)/i);
      if (m) { var n = parseInt(m[1]); if (n > maxNum) maxNum = n; }
    });
    var nextCode = 'P' + String(maxNum + 1).padStart(3, '0');

    // Load team members for dropdown
    var teamOptions = ['—'];
    try {
      var members = await API.gates.teamMembers();
      teamOptions = members.map(function(m){ return m.name; });
    } catch(e) {}

    var actionOptions = ['On Track','Review Required','Schedule Risk','Partnership Gap','Needs Assessment','Budget Risk','Resource Gap'];

    Modals.form({
      title: 'Add New Product',
      fields: [
        { key:'product_code', label:'Product Code',   value:nextCode, required:true,
          hint:'Auto-generated — you can edit it' },
        { key:'name',         label:'Product Name',   required:true },
        { key:'description',  label:'Description',    type:'textarea' },
        { type:'divider', label:'Status & Priority' },
        { key:'status',   label:'Stage',    type:'select', options:['Concept','Development','Validation','Pilot','Scale-up','Commercial'], value:'Concept' },
        { key:'priority', label:'Priority', type:'select', options:['Critical','High','Medium','Low'], value:'Medium' },
        { key:'completion', label:'Completion %', type:'number', placeholder:'0', value:'0' },
        { type:'divider', label:'Ownership' },
        { key:'team_lead',       label:'Owner',      type:'select', options:teamOptions },
        { key:'action_required', label:'Action Required', type:'select', options:actionOptions, value:'On Track' },
        { key:'readiness_date',  label:'Target Launch',  type:'date' },
        { key:'start_date',      label:'Start Date',     type:'date' },
        { type:'divider', label:'Commercial' },
        { key:'pipeline_value',  label:'Pipeline Value (USD)', type:'number', placeholder:'0' },
        { key:'customer_count',  label:'Number of Customers',  type:'number', placeholder:'0' },
        { key:'notes', label:'Notes', type:'textarea' },
      ],
      submitText: 'Create Product',
      onSubmit: async function(data) {
        try {
          data.completion     = parseInt(data.completion)      || 0;
          data.pipeline_value = parseFloat(data.pipeline_value) || null;
          data.customer_count = parseInt(data.customer_count)   || null;
          if (!data.readiness_date) delete data.readiness_date;
          if (!data.start_date)     delete data.start_date;
          await API.products.create(data);
          Modals.close();
          Toast.show('Product created.', 'success');
          await Router.refresh();
        } catch(err) { Toast.show(err.message, 'error'); }
      },
    });
  }

  // ── EDIT PRODUCT ──────────────────────────────────────────
  async function openEditProduct(id) {
    var p = Router.getProduct(id);
    if (!p) return;

    var teamOptions = ['—'];
    try {
      var members = await API.gates.teamMembers();
      teamOptions = members.map(function(m){ return m.name; });
    } catch(e) {}

    var actionOptions = ['On Track','Review Required','Schedule Risk','Partnership Gap','Needs Assessment','Budget Risk','Resource Gap'];
    if (p.action_required && actionOptions.indexOf(p.action_required) === -1) {
      actionOptions.push(p.action_required);
    }
    if (p.team_lead && teamOptions.indexOf(p.team_lead) === -1) {
      teamOptions.push(p.team_lead);
    }

    Modals.form({
      title: 'Edit — ' + p.name,
      fields: [
        { key:'product_code', label:'Product Code', value:p.product_code||'', required:true,
          hint:'Edit with caution — must stay unique' },
        { key:'name',        label:'Product Name', value:p.name, required:true },
        { key:'description', label:'Description',  type:'textarea', value:p.description||'' },
        { type:'divider', label:'Status & Priority' },
        { key:'status',   label:'Stage', type:'select', value:p.status,
          options:['Concept','Development','Validation','Pilot','Scale-up','Commercial'] },
        { key:'priority', label:'Priority', type:'select', value:p.priority,
          options:['Critical','High','Medium','Low'] },
        { key:'completion',      label:'Completion %',     type:'number', value:String(p.completion||0) },
        { key:'action_required', label:'Action Required',  type:'select', value:p.action_required||'On Track', options:actionOptions },
        { type:'divider', label:'Ownership' },
        { key:'team_lead',      label:'Owner', type:'select', value:p.team_lead||'', options:teamOptions },
        { key:'readiness_date', label:'Target Launch Date', type:'date', value:p.readiness_date||'' },
        { key:'start_date',     label:'Start Date',         type:'date', value:p.start_date||'' },
        { type:'divider', label:'Commercial' },
        { key:'pipeline_value', label:'Pipeline Value (USD)', type:'number', value:String(p.pipeline_value||'') },
        { key:'customer_count', label:'Number of Customers',  type:'number', value:String(p.customer_count||'') },
        { key:'notes', label:'Notes', type:'textarea', value:p.notes||'' },
      ],
      submitText: 'Save Changes',
      onSubmit: async function(data) {
        try {
          data.completion     = parseInt(data.completion)      || 0;
          data.pipeline_value = parseFloat(data.pipeline_value) || null;
          data.customer_count = parseInt(data.customer_count)   || null;
          if (!data.readiness_date) delete data.readiness_date;
          if (!data.start_date)     delete data.start_date;
          await API.products.update(id, data);
          Modals.close();
          Toast.show('Product updated.', 'success');
          await Router.refresh();
        } catch(err) { Toast.show(err.message, 'error'); }
      },
    });
  }

  // ── DELETE PRODUCT ────────────────────────────────────────
  function confirmDelete(id) {
    var p = Router.getProduct(id);
    if (!p) return;
    Modals.confirm({
      title:       'Delete Product',
      message:     'Are you sure you want to delete <strong>' + p.name + '</strong>? This cannot be undone.',
      confirmText: 'Delete',
      danger:      true,
      onConfirm:   async function() {
        try {
          await API.products.delete(id);
          Toast.show('Product deleted.', 'success');
          await Router.refresh();
          Router.go('portfolio');
        } catch(err) { Toast.show(err.message, 'error'); }
      },
    });
  }

  // ── ARCHIVE PRODUCT ──────────────────────────────────────
  function confirmArchive(id) {
    var p = Router.getProduct(id);
    if (!p) return;
    Modals.confirm({
      title:       'Archive Product',
      message:     'Archive <strong>' + p.name + '</strong>? It will be hidden from the portfolio but all data is kept. You can restore it later from the database.',
      confirmText: 'Archive',
      danger:      false,
      onConfirm:   async function() {
        try {
          await API.products.update(id, { is_active: false });
          Toast.show(p.name + ' archived.', 'success');
          await Router.refresh();
        } catch(err) { Toast.show(err.message, 'error'); }
      },
    });
  }

  return {
    render,
    setFilter,
    setSearch,
    setSort,
    openAddProduct,
    openEditProduct,
    confirmDelete,
    confirmArchive,
  };

})();
