/* ═══════════════════════════════════════════════════════════
   settings.js  —  Account Settings page
═══════════════════════════════════════════════════════════ */

Pages.Settings = (() => {

  function render() {
    const el = document.getElementById('page-settings');
    if (!el) return;

    const u = Auth.currentUser() || {};

    el.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2>Account Settings</h2>
          <p>Manage your profile, password and notification preferences</p>
        </div>
      </div>

      <div class="grid-2 mb-20">

        <!-- Profile -->
        <div class="card">
          <div class="card-header">
            <div class="card-title"><i class="fas fa-user"></i> Profile information</div>
          </div>
          <div class="card-body">
            <div style="display:flex;align-items:center;gap:16px;margin-bottom:20px;
                        padding-bottom:20px;border-bottom:1px solid var(--gray-100)">
              <div style="width:56px;height:56px;border-radius:50%;
                          background:linear-gradient(135deg,var(--green-500),var(--blue-600));
                          color:#fff;font-size:18px;font-weight:700;
                          display:flex;align-items:center;justify-content:center;flex-shrink:0">
                ${fmt.initials(u.name||'?')}
              </div>
              <div>
                <div style="font-size:15px;font-weight:700;color:var(--gray-900)">${u.name||'—'}</div>
                <div style="font-size:12px;color:var(--gray-500)">${u.email||'—'}</div>
                <span class="badge ${u.role==='Admin'?'badge-critical':u.role==='Manager'?'badge-on-track':'badge-upcoming'}"
                      style="margin-top:5px">${u.role||'—'}</span>
              </div>
            </div>
            <div class="form-group">
              <label class="form-label">Full Name</label>
              <input type="text" class="form-input" id="set-name" value="${u.name||''}">
            </div>
            <div class="form-group">
              <label class="form-label">Email Address</label>
              <input type="email" class="form-input" value="${u.email||''}" disabled
                     style="background:var(--gray-100);color:var(--gray-500)">
              <div class="form-hint">Email cannot be changed. Contact admin to update.</div>
            </div>
            <div class="form-group">
              <label class="form-label">Department</label>
              <input type="text" class="form-input" id="set-dept" value="${u.department||''}"
                     placeholder="Your department">
            </div>
            <button class="btn btn-primary w-full" onclick="Pages.Settings.saveProfile()">
              <i class="fas fa-save"></i> Save Profile
            </button>
          </div>
        </div>

        <!-- Password -->
        <div class="card">
          <div class="card-header">
            <div class="card-title"><i class="fas fa-lock"></i> Change password</div>
          </div>
          <div class="card-body">
            <div class="form-group">
              <label class="form-label">Current Password <span class="required">*</span></label>
              <input type="password" class="form-input" id="set-pass-cur" placeholder="Current password">
            </div>
            <div class="form-group">
              <label class="form-label">New Password <span class="required">*</span></label>
              <input type="password" class="form-input" id="set-pass-new" placeholder="Minimum 6 characters">
            </div>
            <div class="form-group">
              <label class="form-label">Confirm New Password <span class="required">*</span></label>
              <input type="password" class="form-input" id="set-pass-conf" placeholder="Repeat new password">
            </div>
            <button class="btn btn-primary w-full" onclick="Pages.Settings.changePassword()">
              <i class="fas fa-key"></i> Update Password
            </button>
          </div>
        </div>

      </div>

      <!-- Admin zone -->
      ${Auth.isAdmin() ? `
      <div class="card mt-20" style="border:1px solid var(--color-danger)">
        <div class="card-header" style="background:var(--color-danger-bg)">
          <div class="card-title" style="color:var(--color-danger)">
            <i class="fas fa-exclamation-triangle"></i> Admin zone
          </div>
        </div>
        <div class="card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:20px">

            <div>
              <div style="font-size:13px;font-weight:600;color:var(--gray-900);margin-bottom:4px">
                Manage users
              </div>
              <div style="font-size:12px;color:var(--gray-500);margin-bottom:10px">
                Create, edit roles, or deactivate team member accounts
              </div>
              <button class="btn btn-secondary btn-sm" onclick="Pages.Settings.openUserManager()">
                <i class="fas fa-users-cog"></i> Manage users
              </button>
            </div>

            <div>
              <div style="font-size:13px;font-weight:600;color:var(--gray-900);margin-bottom:4px">
                Audit logs
              </div>
              <div style="font-size:12px;color:var(--gray-500);margin-bottom:10px">
                View full record of all actions taken in the platform
              </div>
              <button class="btn btn-secondary btn-sm" onclick="Router.go('logs')">
                <i class="fas fa-history"></i> View logs
              </button>
            </div>

            <div>
              <div style="font-size:13px;font-weight:600;color:var(--gray-900);margin-bottom:4px">
                Gate weights
              </div>
              <div style="font-size:12px;color:var(--gray-500);margin-bottom:10px">
                Edit the weight (%) of each gate in the progress calculation
              </div>
              <button class="btn btn-secondary btn-sm" onclick="Pages.Settings.openGateWeights()">
                <i class="fas fa-sliders-h"></i> Edit weights
              </button>
            </div>

          </div>
        </div>
      </div>` : ''}
    `;
  }

  // ── Profile ───────────────────────────────────────────────
  async function saveProfile() {
    const name = document.getElementById('set-name')?.value.trim();
    const dept = document.getElementById('set-dept')?.value.trim();
    if (!name) { Toast.show('Name cannot be empty.','warning'); return; }
    try {
      const updated = await API.auth.updateMe({ name, department: dept });
      API.user.set(updated);
      Auth.applyUser(updated);
      Toast.show('Profile saved.','success');
    } catch (err) { Toast.show(err.message,'error'); }
  }

  // ── Password ──────────────────────────────────────────────
  async function changePassword() {
    const cur  = document.getElementById('set-pass-cur')?.value;
    const nw   = document.getElementById('set-pass-new')?.value;
    const conf = document.getElementById('set-pass-conf')?.value;
    if (!cur)          { Toast.show('Enter your current password.','warning'); return; }
    if (nw.length < 6) { Toast.show('New password must be at least 6 characters.','warning'); return; }
    if (nw !== conf)   { Toast.show('Passwords do not match.','warning'); return; }
    try {
      await API.auth.changePassword(cur, nw);
      Toast.show('Password updated successfully.','success');
      ['set-pass-cur','set-pass-new','set-pass-conf'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
      });
    } catch (err) { Toast.show(err.message,'error'); }
  }

  // ── Gate Weights ──────────────────────────────────────────
  async function openGateWeights() {
    let gates = [];
    try { gates = await API.gates.list(); }
    catch(err) { Toast.show('Failed to load gates: ' + err.message, 'error'); return; }

    const total = gates.reduce((s,g) => s + Number(g.weight), 0);

    Modals.open({
      title: 'Edit Gate Weights',
      size:  'sm',
      body: `
        <p style="font-size:12px;color:var(--gray-500);margin-bottom:16px">
          Weights must add up to <strong>100%</strong>.
          Current total: <strong id="weight-total" style="color:${Math.abs(total-100)<0.1?'var(--green-600)':'var(--color-danger)'}">${total}%</strong>
        </p>
        <div style="display:flex;flex-direction:column;gap:10px">
          ${gates.map(g => `
            <div style="display:flex;align-items:center;gap:12px">
              <div style="width:32px;height:32px;border-radius:var(--radius-sm);
                          background:var(--green-600);color:#fff;font-size:11px;font-weight:700;
                          display:flex;align-items:center;justify-content:center;flex-shrink:0">
                G${g.gate_number}
              </div>
              <div style="flex:1;font-size:13px;font-weight:500;color:var(--gray-800)">${g.name}</div>
              <div style="display:flex;align-items:center;gap:6px;flex-shrink:0">
                <input type="number" id="gw-${g.id}"
                       value="${Number(g.weight)}" min="0" max="100" step="1"
                       oninput="Pages.Settings.updateWeightTotal()"
                       style="width:60px;padding:5px 8px;border:1.5px solid var(--gray-200);
                              border-radius:var(--radius-sm);font-size:13px;text-align:center;outline:none">
                <span style="font-size:12px;color:var(--gray-500)">%</span>
              </div>
            </div>`).join('')}
        </div>`,
      footer: `
        <button class="btn btn-secondary" onclick="Modals.close()">Cancel</button>
        <button class="btn btn-primary" onclick="Pages.Settings.saveGateWeights()">
          <i class="fas fa-save"></i> Save Weights
        </button>`,
    });
  }

  function updateWeightTotal() {
    let total = 0;
    document.querySelectorAll('[id^="gw-"]').forEach(inp => { total += Number(inp.value)||0; });
    const el = document.getElementById('weight-total');
    if (el) {
      el.textContent = total + '%';
      el.style.color = Math.abs(total-100) < 0.1 ? 'var(--green-600)' : 'var(--color-danger)';
    }
  }

  async function saveGateWeights() {
    let total = 0;
    const updates = [];
    document.querySelectorAll('[id^="gw-"]').forEach(inp => {
      const id     = parseInt(inp.id.replace('gw-',''));
      const weight = Number(inp.value) || 0;
      total += weight;
      updates.push({ id, weight });
    });
    if (Math.abs(total-100) > 0.1) {
      Toast.show('Weights must add up to 100%. Currently: ' + total + '%', 'error');
      return;
    }
    try {
      await Promise.all(updates.map(u => API.gates.updateGate(u.id, { weight: u.weight })));
      Modals.close();
      Toast.show('Gate weights saved.', 'success');
    } catch(err) { Toast.show(err.message,'error'); }
  }

  // ── User Manager ──────────────────────────────────────────
  function openUserManager() {
    API.users.list().then(users => {
      Modals.open({
        title: 'User Management',
        size:  'lg',
        body: `
          <div class="table-wrap">
            <table class="data-table">
              <thead>
                <tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th></th></tr>
              </thead>
              <tbody>
                ${users.map(u => `
                  <tr>
                    <td class="primary">${u.name}</td>
                    <td style="font-size:12px;color:var(--gray-600)">${u.email}</td>
                    <td>
                      <select onchange="Pages.Settings.changeRole(${u.id},this.value)"
                              class="form-select"
                              style="padding:4px 8px;width:auto;
                                     border-radius:var(--radius-sm);font-size:12px">
                        ${['Admin','Manager','Team Lead'].map(r =>
                          `<option ${u.role===r?'selected':''}>${r}</option>`).join('')}
                      </select>
                    </td>
                    <td>
                      <span class="badge ${u.is_active?'badge-on-track':'badge-not-started'}">
                        ${u.is_active?'Active':'Inactive'}
                      </span>
                    </td>
                    <td>
                      ${u.id !== Auth.currentUser()?.id ? (
                        u.is_active
                          ? `<button class="btn-icon danger" title="Deactivate"
                              onclick="Pages.Settings.deactivateUser(${u.id},'${u.name}')">
                              <i class="fas fa-user-slash"></i>
                            </button>`
                          : `<button class="btn-icon" title="Activate"
                              onclick="Pages.Settings.activateUser(${u.id},'${u.name}')">
                              <i class="fas fa-user-check"></i>
                            </button>`
                      ) : ''}
                    </td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>`,
        footer: `
          <button class="btn btn-primary" onclick="Pages.Settings.openAddUser()">
            <i class="fas fa-user-plus"></i> Add User
          </button>
          <button class="btn btn-secondary" onclick="Modals.close()">Close</button>`,
      });
    }).catch(err => Toast.show(err.message,'error'));
  }

  async function changeRole(userId, role) {
    try {
      await API.users.changeRole(userId, role);
      Toast.show('Role updated.','success');
    } catch (err) { Toast.show(err.message,'error'); }
  }

  function deactivateUser(userId, name) {
    Modals.confirm({
      title: 'Deactivate User',
      message: `Deactivate <strong>${name}</strong>? They will no longer be able to sign in.`,
      confirmText: 'Deactivate', danger: true,
      onConfirm: async () => {
        try {
          await API.users.deactivate(userId);
          Toast.show('User deactivated.','success');
          openUserManager();
        } catch (err) { Toast.show(err.message,'error'); }
      },
    });
  }

  function activateUser(userId, name) {
    Modals.confirm({
      title: 'Activate User',
      message: `Activate <strong>${name}</strong>? They will be able to sign in again.`,
      confirmText: 'Activate', danger: false,
      onConfirm: async () => {
        try {
          await API.users.activate(userId);
          Toast.show('User activated.','success');
          openUserManager();
        } catch (err) { Toast.show(err.message,'error'); }
      },
    });
  }

  function openAddUser() {
    Modals.form({
      title: 'Add New User',
      fields: [
        { key:'name',     label:'Full Name',     required:true },
        { key:'email',    label:'Email Address', type:'email', required:true },
        { key:'password', label:'Password',      type:'password', required:true,
          hint:'Minimum 6 characters' },
        { key:'role',     label:'Role', type:'select',
          options:['Team Lead','Manager','Admin'], value:'Team Lead' },
        { key:'department', label:'Department', placeholder:'e.g. Engineering' },
      ],
      submitText: 'Create User',
      onSubmit: async (data) => {
        try {
          await API.users.create(data);
          Modals.close();
          Toast.show('User created.','success');
          openUserManager();
        } catch (err) { Toast.show(err.message,'error'); }
      },
    });
  }

  return {
    render,
    saveProfile,
    changePassword,
    openUserManager,
    changeRole,
    deactivateUser,
    activateUser,
    openAddUser,
    openGateWeights,
    updateWeightTotal,
    saveGateWeights,
  };
})();
