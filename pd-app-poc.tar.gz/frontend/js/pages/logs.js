/* ═══════════════════════════════════════════════════════════
   logs.js  —  Audit Log viewer (Admin only)
═══════════════════════════════════════════════════════════ */

Pages.Logs = (() => {

  async function render() {
    const el = document.getElementById('page-logs');
    if (!el) return;

    if (!Auth.isAdmin()) {
      el.innerHTML = `<div class="empty-state" style="padding:60px"><i class="fas fa-lock"></i><p>Admin access required.</p></div>`;
      return;
    }

    el.innerHTML = `<div class="loading"><i class="fas fa-spinner fa-spin"></i> Loading…</div>`;

    let logs = [];
    try { logs = await API.logs.list(); }
    catch (err) {
      el.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-circle"></i>
        <p>Failed to load audit logs: ${err.message}</p></div>`;
      return;
    }

    // Use the -text tokens (already measured to pass AA against their
    // -soft background) instead of hand-picked hex.
    const actionColors = {
      login:  { bg: 'var(--purple-soft)',      text: 'var(--purple-text)' },
      logout: { bg: 'var(--surface-hover)',    text: 'var(--ink)' },
      create: { bg: 'var(--color-success-bg)', text: 'var(--green-text)' },
      update: { bg: 'var(--color-warning-bg)', text: 'var(--amber-text)' },
      delete: { bg: 'var(--color-danger-bg)',  text: 'var(--red-text)' },
      comment:{ bg: 'var(--purple-soft)',      text: 'var(--purple-text)' },
    };

    el.innerHTML = `
      <div class="page-header">
        <div class="page-header-left">
          <h2>Audit Logs</h2>
          <p>${logs.length} recent action${logs.length !== 1 ? 's' : ''} · who, what, when</p>
        </div>
      </div>

      <div class="card">
        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>When</th><th>User</th><th>Action</th><th>Entity</th><th>Detail</th>
              </tr>
            </thead>
            <tbody>
              ${logs.length ? logs.map(l => {
                const c = actionColors[l.action_type] || { bg: 'var(--surface-hover)', text: 'var(--ink)' };
                return `
                <tr>
                  <td style="white-space:nowrap;font-size:12px;color:var(--gray-600)">${fmt.timeAgo(l.created_at)}</td>
                  <td class="primary">${l.user_name || '—'}</td>
                  <td><span style="padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;background:${c.bg};color:${c.text};text-transform:capitalize">${l.action_type}</span></td>
                  <td style="font-size:12px;color:var(--gray-700)">
                    ${l.entity_type ? l.entity_type + (l.entity_name ? ': ' + l.entity_name : l.entity_id ? ' #' + l.entity_id : '') : '—'}
                  </td>
                  <td style="font-size:12px;color:var(--gray-500);max-width:320px">
                    ${l.field_name ? `<strong>${l.field_name}</strong>: ${l.old_value || '—'} → ${l.new_value || '—'}` : (l.detail || '—')}
                  </td>
                </tr>`;
              }).join('')
              : `<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--gray-400)">No audit log entries yet</td></tr>`}
            </tbody>
          </table>
        </div>
      </div>`;
  }

  return { render };

})();
