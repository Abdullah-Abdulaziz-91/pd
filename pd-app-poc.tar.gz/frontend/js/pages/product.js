/* ═══════════════════════════════════════════════════════════
   PD Dashboard — Aramco Digital
   product.js  —  Product Detail page
═══════════════════════════════════════════════════════════ */

Pages.Product = (() => {

  let _currentId   = null;
  let _comments    = [];
  let _activeTab   = 'overview';

  // ── RENDER ───────────────────────────────────────────────
  async function render(params = {}) {
    const el = document.getElementById('page-product');
    if (!el) return;

    const id = params.id || _currentId;
    if (!id) { Router.go('portfolio'); return; }
    _currentId = id;
    Router.state.currentProduct = { id };

    // Fetch full product detail from API (includes milestones, risks, etc.)
    let product, milestones, financials, risks, clients;
    try {
      [product, milestones, financials, risks, clients] = await Promise.all([
        API.products.get(id),
        API.milestones.list({ product_id: id }),
        API.financials.list({ product_id: id }),
        API.risks.list({ product_id: id }),
        API.clients.forProduct(id).catch(() => []),
      ]);
    } catch (err) {
      el.innerHTML = `<div class="empty-state"><i class="fas fa-exclamation-circle"></i>
        <p>Failed to load product: ${err.message}</p></div>`;
      return;
    }

    const fin    = financials[0] || null;
    const pct    = product.completion || 0;
    const canEdit = Auth.isManagerOrAbove() ||
      (Auth.currentUser()?.id === product.team_lead_user_id);

    el.innerHTML = `
      <!-- Breadcrumb -->
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;
                  font-size:13px;color:var(--gray-500)">
        <button class="btn-link" onclick="Router.go('portfolio')">
          <i class="fas fa-arrow-left"></i> Portfolio
        </button>
        <span>/</span>
        <span style="color:var(--gray-800);font-weight:600">${product.name}</span>
      </div>

      <!-- Hero header -->
      <div class="card mb-20">
        <div style="padding:24px">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;
                      gap:16px;flex-wrap:wrap">
            <div style="flex:1;min-width:0">
              <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;flex-wrap:wrap">
                <h2 style="font-size:22px;font-weight:700;color:var(--gray-900)">${product.name}</h2>
                ${badge.stage(product.status)}
                ${badge.priority(product.priority)}
                ${badge.action(product.action_required)}
              </div>
              <p style="font-size:14px;color:var(--gray-600);line-height:1.6;margin-bottom:16px">
                ${product.description || 'No description provided.'}
              </p>
              ${canEdit ? renderEditableStagePipeline(product.status, id) : Router.stagePipeline(product.status)}
            </div>
            <div style="display:flex;gap:8px;flex-shrink:0">
              ${canEdit ? `
              <button class="btn btn-secondary btn-sm"
                      onclick="Pages.Portfolio.openEditProduct(${id})">
                <i class="fas fa-edit"></i> Edit
              </button>` : ''}
              ${Auth.isManagerOrAbove() ? `
              <button class="btn btn-secondary btn-sm"
                      onclick="Pages.Portfolio.confirmArchive(${id})">
                <i class="fas fa-archive"></i> Archive
              </button>` : ''}
              ${Auth.isAdmin() ? `
              <button class="btn btn-danger btn-sm"
                      onclick="Pages.Portfolio.confirmDelete(${id})">
                <i class="fas fa-trash"></i>
              </button>` : ''}
            </div>
          </div>

          <!-- Progress + key metrics -->
          <div style="margin-top:16px">
            <div class="progress-label">
              <span style="font-size:13px;font-weight:600;color:var(--gray-700)">Overall completion</span>
              <span class="pct" style="font-size:15px">${pct}%</span>
            </div>
            <div class="progress-track thick">
              <div class="progress-fill" style="width:${pct}%;background:${
                pct>=75?'var(--green-500)':pct>=40?'var(--blue-600)':'var(--color-warning)'
              }"></div>
            </div>
          </div>

          <!-- Quick stats -->
          <div class="grid-5" style="margin-top:20px">
            ${quickStat('Owner',     product.team_lead || '—',        'fa-user')}
            ${quickStat('Target Launch', fmt.date(product.readiness_date), 'fa-calendar')}
            ${quickStat('Last Updated',  fmt.timeAgo(product.updated_at),  'fa-clock')}
            ${quickStat('Pipeline Value',
              product.pipeline_value ? fmt.currency(product.pipeline_value) : '—',
              'fa-dollar-sign', 'green')}
            ${quickStat('Customers',
              product.customer_count ? fmt.number(product.customer_count) : '—',
              'fa-users', 'blue')}
          </div>
        </div>
      </div>

      <!-- Tab nav -->
      <div style="display:flex;gap:4px;margin-bottom:20px;border-bottom:2px solid var(--gray-200);
                  padding-bottom:0">
        ${['overview','gates','partnerships','financials','risks','comments'].map(t => `
          <button id="ptab-${t}"
                  onclick="Pages.Product.switchTab('${t}',${id})"
                  style="padding:10px 18px;font-size:13px;font-weight:600;border:none;
                         background:none;cursor:pointer;border-bottom:2px solid transparent;
                         margin-bottom:-2px;transition:all .2s;color:var(--gray-500)"
                  ${_activeTab===t ?
                    "class='active-tab' style='padding:10px 18px;font-size:13px;font-weight:700;border:none;background:none;cursor:pointer;border-bottom:2px solid var(--green-500);margin-bottom:-2px;transition:all .2s;color:var(--green-600)'"
                    : ''}>
            ${t.charAt(0).toUpperCase()+t.slice(1)}
            ${t==='milestones' ? `<span style="margin-left:5px;font-size:10px;background:var(--gray-200);
              padding:1px 6px;border-radius:10px;color:var(--gray-600)">${milestones.length}</span>` : ''}
            ${t==='risks' ? `<span style="margin-left:5px;font-size:10px;background:${
              risks.filter(r=>r.status==='Open').length?'var(--color-danger-bg)':'var(--gray-200)'};
              padding:1px 6px;border-radius:10px;color:${
              risks.filter(r=>r.status==='Open').length?'var(--color-danger)':'var(--gray-600)'
            }">${risks.length}</span>` : ''}
          </button>`).join('')}
      </div>

      <!-- Tab content -->
      <div id="product-tab-content"></div>
    `;

    // Render active tab
    await renderTab(_activeTab, product, milestones, financials, risks, id);
  }

  // ── TAB SWITCHER ─────────────────────────────────────────
  async function switchTab(tab, id) {
    _activeTab = tab;
    // Update tab styles
    document.querySelectorAll('[id^="ptab-"]').forEach(btn => {
      const isActive = btn.id === `ptab-${tab}`;
      btn.style.color       = isActive ? 'var(--green-600)' : 'var(--gray-500)';
      btn.style.fontWeight  = isActive ? '700' : '600';
      btn.style.borderBottom = isActive ? '2px solid var(--green-500)' : '2px solid transparent';
    });

    const product    = (await API.products.get(id));
    const milestones = await API.milestones.list({ product_id: id });
    const financials = await API.financials.list({ product_id: id });
    const risks      = await API.risks.list({ product_id: id });

    await renderTab(tab, product, milestones, financials, risks, id);
  }

  async function renderTab(tab, product, milestones, financials, risks, productId) {
    const el = document.getElementById('product-tab-content');
    if (!el) return;

    switch (tab) {
      case 'overview':      el.innerHTML = await tabOverview(product, milestones, financials, risks, productId || product.id); break;
      case 'gates':         await renderGatesTab(product.id); break;
      case 'partnerships':  await renderPartnershipsTab(product.id); break;
      case 'milestones':    el.innerHTML = tabMilestones(product, milestones); break;

      case 'financials':
        if (!Auth.isAdmin() && !Auth.currentUser()?.finance_access) {
          el.innerHTML = '<div class="empty-state" style="padding:60px"><i class="fas fa-lock"></i><p>Finance access required. Contact Admin.</p></div>';
        } else {
          el.innerHTML = tabFinancials(product, financials);
        }
        break;
      case 'risks':         el.innerHTML = tabRisks(product, risks); break;
      case 'comments':      await renderComments(product.id); break;
    }
  }

  // ── TAB: OVERVIEW ────────────────────────────────────────
  async function tabOverview(p, milestones, financials, risks, productId) {
    let productClients = [];
    try { productClients = await API.clients.forProduct(productId); } catch(_) {}
    let allClients = [];
    try { allClients = await API.clients.list(); } catch(_) {}
    const fin       = financials[0] || null;
    const openRisks = risks.filter(r => r.status === 'Open').length;
    const overduems = milestones.filter(m => m.status === 'Overdue').length;
    const doneMs    = milestones.filter(m => m.status === 'Done').length;

    return `
      <div class="grid-3 mb-20">
        ${miniKpi('Milestones Done', `${doneMs}/${milestones.length}`, 'fa-flag-checkered', 'green')}
        ${miniKpi('Overdue', overduems, 'fa-calendar-times', overduems>0?'red':'green')}
        ${miniKpi('Open Risks', openRisks, 'fa-shield-alt', openRisks>0?'amber':'green')}
      </div>

      <!-- Client tags -->
      <div class="card mb-20">
        <div class="card-header">
          <div class="card-title"><i class="fas fa-building"></i> Clients</div>
          ${Auth.isManagerOrAbove() ? `
          <button class="btn btn-secondary btn-sm" onclick="openClientManager(${productId||p.id})">
            <i class="fas fa-edit"></i> Manage
          </button>` : ''}
        </div>
        <div class="card-body">
          ${productClients.length
            ? `<div style="display:flex;flex-wrap:wrap;gap:8px">
                ${productClients.map(c => `
                  <span style="padding:5px 14px;background:var(--color-info-bg);
                               color:var(--blue-700);border-radius:20px;font-size:13px;
                               font-weight:600;border:1px solid var(--blue-200)">
                    <i class="fas fa-building" style="font-size:10px;margin-right:4px"></i>
                    ${c.name}
                  </span>`).join('')}
               </div>`
            : `<p style="font-size:13px;color:var(--gray-400)">No clients linked yet.
                ${Auth.isManagerOrAbove() ? `<button class="btn-link" onclick="openClientManager(${productId||p.id})">Add a client</button>` : ''}</p>`}
        </div>
      </div>

      <div class="grid-2">
        <div class="card">
          <div class="card-header"><div class="card-title"><i class="fas fa-info-circle"></i> Product info</div></div>
          <div class="card-body">
            ${infoRow('Product Code',    p.product_code)}
            ${infoRow('Current Stage',   badge.stage(p.status))}
            ${infoRow('Priority',        badge.priority(p.priority))}
            ${infoRow('Action Required', badge.action(p.action_required))}
            ${infoRow('Owner',       p.team_lead || '—')}
            ${infoRow('Target Launch',   fmt.date(p.readiness_date))}
            ${infoRow('Pipeline Value',  p.pipeline_value ? fmt.currency(p.pipeline_value) : '—')}
            ${infoRow('Customer Count',  p.customer_count ? fmt.number(p.customer_count)   : '—')}
            ${p.notes ? infoRow('Notes', p.notes) : ''}
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:16px">
          ${fin ? `
          <div class="card">
            <div class="card-header"><div class="card-title"><i class="fas fa-dollar-sign"></i> Budget snapshot</div></div>
            <div class="card-body">
              ${infoRow('Approved Budget', fmt.currency(fin.approved_budget))}
              ${infoRow('Actual Spend',    fmt.currency(fin.actual_spend))}
              ${infoRow('Forecast',        fmt.currency(fin.forecast))}
              ${infoRow('Utilization',     Math.round(fin.utilization_pct||0) + '%')}
              ${infoRow('Variance',
                `<span style="color:${Number(fin.variance)<0?'var(--color-danger)':'var(--green-600)'};font-weight:600">
                  ${Number(fin.variance)>=0?'+':''}${fmt.currency(fin.variance)}
                </span>`)}
            </div>
          </div>` : ''}

          <div class="card">
            <div class="card-header"><div class="card-title"><i class="fas fa-tasks"></i> Recent milestones</div></div>
            <div class="card-body-flush">
              ${milestones.slice(0,4).map(m => `
                <div style="display:flex;align-items:center;justify-content:space-between;
                            padding:10px 16px;border-bottom:1px solid var(--gray-100)">
                  <div>
                    <div style="font-size:13px;font-weight:600;color:var(--gray-900)">${m.name}</div>
                    <div style="font-size:11px;color:var(--gray-500)">${fmt.date(m.due_date)}</div>
                  </div>
                  ${badge.msStatus(m.status)}
                </div>`).join('') || '<div class="empty-state" style="padding:24px"><p>No milestones</p></div>'}
            </div>
          </div>
        </div>
      </div>`;
  }

  // ── TAB: MILESTONES ──────────────────────────────────────
  function tabMilestones(product, milestones) {
    const canEdit = Auth.isManagerOrAbove() ||
      Auth.currentUser()?.id === product.team_lead_user_id;

    return `
      <div class="card">
        <div class="card-header">
          <div class="card-title"><i class="fas fa-flag"></i> Milestones (${milestones.length})</div>
          ${canEdit ? `
          <button class="btn btn-primary btn-sm"
                  onclick="Pages.Product.openAddMilestone(${product.id})">
            <i class="fas fa-plus"></i> Add Milestone
          </button>` : ''}
        </div>
        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Milestone</th>
                <th>Due Date</th>
                <th>Status</th>
                <th>Notes</th>
                ${canEdit ? '<th></th>' : ''}
              </tr>
            </thead>
            <tbody>
              ${milestones.length ? milestones.map(m => `
                <tr>
                  <td class="primary">${m.name}</td>
                  <td style="white-space:nowrap;color:${
                    m.status==='Overdue'?'var(--color-danger)':'var(--gray-700)'
                  }">${fmt.date(m.due_date)}</td>
                  <td>${badge.msStatus(m.status)}</td>
                  <td style="font-size:12px;color:var(--gray-500);max-width:200px">${m.notes||'—'}</td>
                  ${canEdit ? `
                  <td>
                    <div style="display:flex;gap:6px">
                      <button class="btn-icon" title="Edit"
                              onclick="Pages.Product.openEditMilestone(${m.id},${product.id})">
                        <i class="fas fa-edit"></i>
                      </button>
                      <button class="btn-icon danger" title="Delete"
                              onclick="Pages.Product.confirmDeleteMilestone(${m.id})">
                        <i class="fas fa-trash"></i>
                      </button>
                    </div>
                  </td>` : ''}
                </tr>`).join('')
              : `<tr><td colspan="5" style="text-align:center;padding:40px;color:var(--gray-400)">
                   No milestones yet
                 </td></tr>`}
            </tbody>
          </table>
        </div>
      </div>`;
  }

  // ── TAB: PARTNERSHIPS ────────────────────────────────────
  function tabPartnerships(product) {
    // Partnerships stored in notes as JSON or shown as placeholder
    // In a full build these would be a separate API endpoint
    const types = [
      { key:'hardware', label:'Hardware Partnerships', icon:'fa-microchip',    color:'blue' },
      { key:'software', label:'Software Partnerships', icon:'fa-code',         color:'green' },
      { key:'other',    label:'Other Partnerships',    icon:'fa-handshake',    color:'amber' },
    ];

    return `
      <div class="grid-3 mb-20">
        ${types.map(t => `
          <div class="card">
            <div class="card-header">
              <div class="card-title" style="color:var(--${t.color==='blue'?'blue-700':t.color==='green'?'green-700':'color-warning'})">
                <i class="fas ${t.icon}"></i> ${t.label}
              </div>
              ${Auth.isManagerOrAbove() ? `
              <button class="btn btn-secondary btn-sm"
                      onclick="Pages.Product.openAddPartnership('${t.key}',${product.id})">
                <i class="fas fa-plus"></i>
              </button>` : ''}
            </div>
            <div class="card-body" id="partners-${t.key}">
              <div class="empty-state" style="padding:32px 16px">
                <i class="fas ${t.icon}" style="font-size:24px"></i>
                <p>No ${t.label.toLowerCase()} recorded</p>
                ${Auth.isManagerOrAbove() ? `
                <button class="btn btn-secondary btn-sm" style="margin-top:10px"
                        onclick="Pages.Product.openAddPartnership('${t.key}',${product.id})">
                  <i class="fas fa-plus"></i> Add
                </button>` : ''}
              </div>
            </div>
          </div>`).join('')}
      </div>

      <!-- Partnership progress legend -->
      <div class="card">
        <div class="card-header">
          <div class="card-title"><i class="fas fa-chart-bar"></i> Partnership progress by type</div>
        </div>
        <div class="card-body">
          <div style="margin-bottom:12px">
            <div class="progress-label">
              <span style="display:flex;align-items:center;gap:6px">
                <span style="width:10px;height:10px;border-radius:2px;
                             background:var(--blue-600);display:inline-block"></span>
                Hardware
              </span>
              <span class="pct">—</span>
            </div>
            <div class="progress-track"><div class="progress-fill blue" style="width:0%"></div></div>
          </div>
          <div style="margin-bottom:12px">
            <div class="progress-label">
              <span style="display:flex;align-items:center;gap:6px">
                <span style="width:10px;height:10px;border-radius:2px;
                             background:var(--green-500);display:inline-block"></span>
                Software
              </span>
              <span class="pct">—</span>
            </div>
            <div class="progress-track"><div class="progress-fill" style="width:0%"></div></div>
          </div>
          <div>
            <div class="progress-label">
              <span style="display:flex;align-items:center;gap:6px">
                <span style="width:10px;height:10px;border-radius:2px;
                             background:var(--color-warning);display:inline-block"></span>
                Other
              </span>
              <span class="pct">—</span>
            </div>
            <div class="progress-track"><div class="progress-fill amber" style="width:0%"></div></div>
          </div>
          <p style="font-size:12px;color:var(--gray-400);margin-top:14px;text-align:center">
            Progress will populate as partnerships are added and their status is updated.
          </p>
        </div>
      </div>`;
  }

  // ── TAB: FINANCIALS ──────────────────────────────────────
  function tabFinancials(product, financials) {
    const fin = financials[0] || null;

    return `
      <div class="grid-2 mb-20">

        <!-- Budget detail -->
        <div class="card">
          <div class="card-header">
            <div class="card-title"><i class="fas fa-wallet"></i> Budget & spend</div>
            ${Auth.isManagerOrAbove() ? `
            <button class="btn btn-${fin?'secondary':'primary'} btn-sm"
                    onclick="Pages.Product.openEditFinancials(${product.id},${fin?fin.id:'null'})">
              <i class="fas fa-${fin?'edit':'plus'}"></i> ${fin?'Edit':'Add'}
            </button>` : ''}
          </div>
          <div class="card-body">
            ${fin ? `
              ${finRow('Approved Budget', fmt.currency(fin.approved_budget), 'blue')}
              ${finRow('Actual Spend',    fmt.currency(fin.actual_spend),
                Number(fin.actual_spend) > Number(fin.approved_budget) ? 'red' : 'green')}
              ${finRow('Forecast',        fmt.currency(fin.forecast), 'blue')}
              ${finRow('Quarter',         fin.quarter || '—')}
              <div style="margin-top:14px">
                <div class="progress-label">
                  <span>Budget utilization</span>
                  <span class="pct" style="color:${
                    (fin.utilization_pct||0)>90?'var(--color-danger)':
                    (fin.utilization_pct||0)>70?'var(--color-warning)':'var(--green-600)'
                  }">${Math.round(fin.utilization_pct||0)}%</span>
                </div>
                <div class="progress-track thick">
                  <div class="progress-fill ${
                    (fin.utilization_pct||0)>90?'red':
                    (fin.utilization_pct||0)>70?'amber':''
                  }" style="width:${Math.min(100,fin.utilization_pct||0)}%"></div>
                </div>
              </div>
              ${fin.notes ? `<p style="margin-top:12px;font-size:12px;color:var(--gray-500)">${fin.notes}</p>` : ''}
            ` : `
              <div class="empty-state">
                <i class="fas fa-dollar-sign"></i>
                <p>No financial data recorded yet.</p>
              </div>`}
          </div>
        </div>

        <!-- ROI section -->
        <div class="card">
          <div class="card-header">
            <div class="card-title"><i class="fas fa-chart-line"></i> ROI & value metrics</div>
          </div>
          <div class="card-body">
            ${product.pipeline_value || product.customer_count ? `
              <div style="display:flex;flex-direction:column;gap:12px;margin-bottom:16px">
                ${product.pipeline_value ? `
                <div class="value-metric">
                  <div class="value-metric-icon green"><i class="fas fa-dollar-sign"></i></div>
                  <div>
                    <div class="value-metric-label">Pipeline Value</div>
                    <div class="value-metric-value">${fmt.currency(product.pipeline_value)}</div>
                  </div>
                </div>` : ''}
                ${product.customer_count ? `
                <div class="value-metric">
                  <div class="value-metric-icon blue"><i class="fas fa-users"></i></div>
                  <div>
                    <div class="value-metric-label">Active Customers</div>
                    <div class="value-metric-value">${fmt.number(product.customer_count)}</div>
                  </div>
                </div>` : ''}
              </div>` : ''}

            <div class="roi-placeholder">
              <i class="fas fa-chart-pie"></i>
              <p>
                <strong>ROI metrics coming soon.</strong><br>
                Full cost visibility (hardware, software, operations) is required
                before ROI can be calculated. This section will populate once
                cost data is available.
              </p>
            </div>
          </div>
        </div>

      </div>`;
  }

  // ── TAB: RISKS ───────────────────────────────────────────
  function tabRisks(product, risks) {
    const canEdit = Auth.isManagerOrAbove();
    const sorted  = [...risks].sort((a,b) => (b.risk_score||0) - (a.risk_score||0));

    return `
      <div class="card">
        <div class="card-header">
          <div class="card-title"><i class="fas fa-shield-alt"></i> Risk register (${risks.length})</div>
          ${canEdit ? `
          <button class="btn btn-primary btn-sm"
                  onclick="Pages.Product.openAddRisk(${product.id})">
            <i class="fas fa-plus"></i> Add Risk
          </button>` : ''}
        </div>
        <div class="table-wrap">
          <table class="data-table">
            <thead>
              <tr>
                <th>Risk Title</th>
                <th>Category</th>
                <th>Likelihood</th>
                <th>Impact</th>
                <th>Score</th>
                <th>Status</th>
                <th>Owner</th>
                ${canEdit ? '<th></th>' : ''}
              </tr>
            </thead>
            <tbody>
              ${sorted.length ? sorted.map(r => {
                const scoreColor = (r.risk_score||0)>=9 ? '#7C2D2D'
                  : (r.risk_score||0)>=6 ? 'var(--color-danger)'
                  : (r.risk_score||0)>=4 ? 'var(--color-warning)'
                  : 'var(--green-600)';
                return `
                <tr>
                  <td class="primary">${r.title}</td>
                  <td><span class="badge" style="background:var(--gray-100);color:var(--gray-700)">${r.category||'—'}</span></td>
                  <td>${badge.priority(r.likelihood)}</td>
                  <td>${badge.priority(r.impact)}</td>
                  <td><strong style="color:${scoreColor};font-size:15px">${r.risk_score||'—'}</strong></td>
                  <td>${badge.riskStatus(r.status)}</td>
                  <td style="font-size:12px">${r.owner||'—'}</td>
                  ${canEdit ? `
                  <td>
                    <button class="btn-icon" title="Edit"
                            onclick="Pages.Product.openEditRisk(${r.id},${product.id})">
                      <i class="fas fa-edit"></i>
                    </button>
                  </td>` : ''}
                </tr>`;
              }).join('')
              : `<tr><td colspan="8" style="text-align:center;padding:40px;color:var(--gray-400)">
                   No risks recorded
                 </td></tr>`}
            </tbody>
          </table>
        </div>
      </div>`;
  }

  // ── TAB: COMMENTS ────────────────────────────────────────
  async function renderComments(productId) {
    const el = document.getElementById('product-tab-content');
    if (!el) return;

    try {
      _comments = await API.comments.list(productId) || [];
    } catch (_) { _comments = []; }

    const members = Router.state.products.map(p => p.team_lead).filter(Boolean);

    el.innerHTML = `
      <div class="card">
        <div class="card-header">
          <div class="card-title">
            <i class="fas fa-comments"></i>
            Team Comments (${_comments.length})
          </div>
        </div>
        <div class="card-body">

          <!-- Input area -->
          <div class="comment-input-area mb-16" style="position:relative">
            <div style="flex:1;position:relative">
              <textarea class="comment-textarea" id="comment-input"
                        placeholder="Add a comment… use @name to mention someone"
                        oninput="handleMentionInput(event, ${productId})"
                        onkeydown="handleMentionKeydown(event)"></textarea>
              <div id="mention-dropdown" style="display:none;position:absolute;bottom:100%;left:0;
                          margin-bottom:4px;background:var(--overlay-bg);backdrop-filter:blur(16px);border:1px solid var(--line);
                          border-radius:var(--radius-md);box-shadow:var(--shadow-lg);
                          max-height:180px;overflow-y:auto;min-width:200px;z-index:50"></div>
              <div class="comment-hint">
                <i class="fas fa-at"></i> Mention team members to notify them
              </div>
            </div>
            <button class="btn btn-primary" onclick="Pages.Product.postComment(${productId})">
              <i class="fas fa-paper-plane"></i> Post
            </button>
          </div>

          <div class="section-divider"></div>

          <!-- Comments list -->
          <div class="comment-list" id="comment-list">
            ${_comments.length ? _comments.map(c => commentItem(c)).join('')
              : `<div class="empty-state" style="padding:40px">
                   <i class="fas fa-comment-slash"></i>
                   <p>No comments yet. Start the discussion.</p>
                 </div>`}
          </div>
        </div>
      </div>`;
  }

  function commentItem(c) {
    const initials = fmt.initials(c.author_name || 'User');
    const body = (c.body || '').replace(
      /@(\w[\w.]*)/g,
      '<span class="comment-mention">@$1</span>'
    );
    return `
      <div class="comment-item">
        <div class="comment-avatar">${initials}</div>
        <div class="comment-body">
          <div class="comment-header">
            <span class="comment-author">${c.author_name || 'Unknown'}</span>
            <span class="comment-time">${fmt.timeAgo(c.created_at)}</span>
          </div>
          <div class="comment-text">${body}</div>
        </div>
      </div>`;
  }

  // ── Editable stage pipeline ───────────────────────────────
  function renderEditableStagePipeline(currentStage, productId) {
    const stages = ['Concept', 'Development', 'Validation', 'Pilot', 'Scale-up', 'Commercial'];
    const curIdx = stages.indexOf(currentStage);
    return `
      <div class="stage-pipeline" id="editable-stage-pipeline">
        ${stages.map((s, i) => {
          let cls = 'stage-step';
          if (i < curIdx)  cls += ' done';
          if (i === curIdx) cls += ' current';
          if (i > curIdx)  cls += ' future';
          return `<div class="${cls}" style="cursor:pointer"
                       onclick="selectStageForChange('${s}','${currentStage}',${productId})"
                       title="Click to set stage to ${s}">${s}</div>`;
        }).join('')}
      </div>
      <div id="stage-confirm-bar" style="display:none;margin-top:10px;padding:10px 14px;
                  background:var(--color-info-bg);border:1px solid var(--blue-200);
                  border-radius:var(--radius-md);align-items:center;justify-content:space-between;
                  gap:12px">
        <span style="font-size:13px;color:var(--blue-700)">
          <i class="fas fa-info-circle"></i>
          Change stage to <strong id="stage-confirm-target"></strong>?
        </span>
        <div style="display:flex;gap:8px;flex-shrink:0">
          <button class="btn btn-secondary btn-sm" onclick="cancelStageChange()">Cancel</button>
          <button class="btn btn-primary btn-sm" onclick="confirmStageChange()">
            <i class="fas fa-check"></i> Confirm
          </button>
        </div>
      </div>`;
  }

  var _pendingStage = null;
  var _pendingStageProductId = null;

  function selectStageForChange(newStage, currentStage, productId) {
    if (newStage === currentStage) return;
    _pendingStage = newStage;
    _pendingStageProductId = productId;
    const bar = document.getElementById('stage-confirm-bar');
    const target = document.getElementById('stage-confirm-target');
    if (target) target.textContent = newStage;
    if (bar) bar.style.display = 'flex';
  }

  function cancelStageChange() {
    _pendingStage = null;
    _pendingStageProductId = null;
    const bar = document.getElementById('stage-confirm-bar');
    if (bar) bar.style.display = 'none';
  }

  async function confirmStageChange() {
    if (!_pendingStage || !_pendingStageProductId) return;
    try {
      await API.products.update(_pendingStageProductId, { status: _pendingStage });
      Toast.show('Stage updated to ' + _pendingStage + '.', 'success');
      await Router.refresh();
      await render({ id: _pendingStageProductId });
    } catch (err) {
      Toast.show(err.message, 'error');
    } finally {
      _pendingStage = null;
      _pendingStageProductId = null;
    }
  }

  // ── @mention autocomplete ─────────────────────────────────
  var _mentionTeam = [];
  var _mentionActiveIndex = -1;

  async function handleMentionInput(e, productId) {
    var ta = e.target;
    var val = ta.value;
    var cursorPos = ta.selectionStart;
    var textBeforeCursor = val.slice(0, cursorPos);
    var match = textBeforeCursor.match(/@([\w.]*)$/);

    var dropdown = document.getElementById('mention-dropdown');
    if (!dropdown) return;

    if (!match) {
      dropdown.style.display = 'none';
      _mentionActiveIndex = -1;
      return;
    }

    var query = match[1].toLowerCase();

    if (!_mentionTeam.length) {
      try { _mentionTeam = await API.gates.teamMembers(); } catch(err) { _mentionTeam = []; }
    }

    var filtered = _mentionTeam.filter(function(m) {
      return m.name.toLowerCase().indexOf(query) !== -1;
    });

    if (!filtered.length) {
      dropdown.style.display = 'none';
      _mentionActiveIndex = -1;
      return;
    }

    _mentionActiveIndex = 0;
    dropdown.innerHTML = filtered.map(function(m, i) {
      return '<div class="mention-option" data-name="' + m.name + '" data-index="' + i + '"'
        + ' onclick="selectMention(\'' + m.name + '\')"'
        + ' style="display:flex;align-items:center;gap:8px;padding:8px 12px;cursor:pointer;'
        + 'font-size:13px;' + (i===0 ? 'background:var(--gray-50);' : '') + '"'
        + ' onmouseover="this.style.background=\'var(--gray-50)\'"'
        + ' onmouseout="this.style.background=\'' + (i===0?'var(--gray-50)':'transparent') + '\'">'
        + '<div style="width:24px;height:24px;border-radius:50%;background:linear-gradient(135deg,var(--green-500),var(--blue-600));'
        + 'color:#fff;font-size:10px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0">'
        + fmt.initials(m.name) + '</div>'
        + '<span style="font-weight:600;color:var(--gray-800)">' + m.name + '</span>'
        + '<span style="font-size:11px;color:var(--gray-400);margin-left:auto">' + (m.role||'') + '</span>'
        + '</div>';
    }).join('');
    dropdown.style.display = 'block';
  }

  function handleMentionKeydown(e) {
    var dropdown = document.getElementById('mention-dropdown');
    if (!dropdown || dropdown.style.display === 'none') return;

    var options = dropdown.querySelectorAll('.mention-option');
    if (!options.length) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      _mentionActiveIndex = Math.min(_mentionActiveIndex + 1, options.length - 1);
      highlightMentionOption(options);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      _mentionActiveIndex = Math.max(_mentionActiveIndex - 1, 0);
      highlightMentionOption(options);
    } else if (e.key === 'Enter' || e.key === 'Tab') {
      e.preventDefault();
      var active = options[_mentionActiveIndex] || options[0];
      if (active) selectMention(active.dataset.name);
    } else if (e.key === 'Escape') {
      dropdown.style.display = 'none';
      _mentionActiveIndex = -1;
    }
  }

  function highlightMentionOption(options) {
    options.forEach(function(opt, i) {
      opt.style.background = (i === _mentionActiveIndex) ? 'var(--gray-50)' : 'transparent';
    });
  }

  function selectMention(name) {
    var ta = document.getElementById('comment-input');
    if (!ta) return;
    var val = ta.value;
    var cursorPos = ta.selectionStart;
    var textBeforeCursor = val.slice(0, cursorPos);
    var textAfterCursor  = val.slice(cursorPos);
    var newBefore = textBeforeCursor.replace(/@([\w.]*)$/, '@' + name.replace(/\s+/g,'') + ' ');
    ta.value = newBefore + textAfterCursor;
    var newPos = newBefore.length;
    ta.focus();
    ta.setSelectionRange(newPos, newPos);

    var dropdown = document.getElementById('mention-dropdown');
    if (dropdown) dropdown.style.display = 'none';
    _mentionActiveIndex = -1;
  }

  async function postComment(productId) {
    const input = document.getElementById('comment-input');
    const text  = (input?.value || '').trim();
    if (!text) { Toast.show('Please enter a comment.', 'warning'); return; }

    const mentions = (text.match(/@(\w[\w.]*)/g) || []).map(m => m.slice(1));
    try {
      await API.comments.add(productId, text, mentions);
      input.value = '';
      Toast.show('Comment posted.', 'success');
      Notifications.push('new_comment', 'Comment posted', text.slice(0, 60));
      await renderComments(productId);
    } catch (err) {
      Toast.show(err.message, 'error');
    }
  }

  // ── MILESTONE MODALS ──────────────────────────────────────
  function openAddMilestone(productId) {
    Modals.form({
      title: 'Add Milestone',
      fields: [
        { key:'name',     label:'Milestone Name', required:true, placeholder:'e.g. HSE Approval' },
        { key:'due_date', label:'Due Date', type:'date', required:true },
        { key:'status',   label:'Status', type:'select',
          options:['Not Started','Upcoming','On Track','At Risk','Overdue','Done'],
          value:'Not Started' },
        { key:'notes', label:'Notes', type:'textarea', placeholder:'Additional context…' },
      ],
      submitText: 'Add Milestone',
      onSubmit: async (data) => {
        try {
          data.product_id = productId;
          await API.milestones.create(data);
          Modals.close();
          Toast.show('Milestone added.', 'success');
          await switchTab('milestones', productId);
        } catch (err) { Toast.show(err.message, 'error'); }
      },
    });
  }

  function openEditMilestone(msId, productId) {
    const ms = Router.state.milestones.find(m => m.id === msId);
    if (!ms) return;
    Modals.form({
      title: 'Edit Milestone',
      fields: [
        { key:'name',     label:'Name',     required:true, value:ms.name },
        { key:'due_date', label:'Due Date', type:'date',   value:ms.due_date, required:true },
        { key:'status',   label:'Status',   type:'select',
          options:['Not Started','Upcoming','On Track','At Risk','Overdue','Done'],
          value:ms.status },
        { key:'notes', label:'Notes', type:'textarea', value:ms.notes||'' },
      ],
      submitText: 'Save',
      onSubmit: async (data) => {
        try {
          await API.milestones.update(msId, data);
          Modals.close();
          Toast.show('Milestone updated.', 'success');
          Router.state.loaded = false;
          await Router.loadAll ? Router.refresh() : null;
          await switchTab('milestones', productId);
        } catch (err) { Toast.show(err.message, 'error'); }
      },
    });
  }

  function confirmDeleteMilestone(msId) {
    Modals.confirm({
      title: 'Delete Milestone',
      message: 'Are you sure you want to delete this milestone?',
      confirmText: 'Delete', danger: true,
      onConfirm: async () => {
        try {
          await API.milestones.delete(msId);
          Toast.show('Milestone deleted.', 'success');
          await Router.refresh();
        } catch (err) { Toast.show(err.message, 'error'); }
      },
    });
  }

  // ── RISK MODALS ───────────────────────────────────────────
  async function openAddRisk(productId) {
    // Auto-generate next risk code from existing risks across the portfolio
    var existing = Router.state.risks || [];
    var maxNum = 0;
    existing.forEach(function(r) {
      var m = (r.risk_code||'').match(/R0*(\d+)/i);
      if (m) { var n = parseInt(m[1]); if (n > maxNum) maxNum = n; }
    });
    var nextCode = 'R' + String(maxNum + 1).padStart(3, '0');

    var ownerOptions = ['—'];
    try {
      var members = await API.gates.teamMembers();
      ownerOptions = members.map(function(m){ return m.name; });
    } catch(e) {}

    Modals.form({
      title: 'Add Risk',
      fields: [
        { key:'risk_code', label:'Risk ID', value:nextCode, hint:'Auto-generated — editable' },
        { key:'title',     label:'Risk Title', required:true },
        { key:'category',  label:'Category',   type:'select',
          options:['Technical','Operational','Compliance','Financial','Strategic','Resource'] },
        { key:'likelihood', label:'Likelihood', type:'select',
          options:['Low','Medium','High'] },
        { key:'impact', label:'Impact', type:'select',
          options:['Low','Medium','High','Critical'] },
        { key:'mitigation', label:'Mitigation Plan', type:'textarea' },
        { key:'owner',  label:'Risk Owner', type:'select', options:ownerOptions },
        { key:'status', label:'Status', type:'select',
          options:['Open','Monitoring','Mitigated','Closed'], value:'Open' },
      ],
      submitText: 'Add Risk',
      onSubmit: async (data) => {
        try {
          data.product_id = productId;
          await API.risks.create(data);
          Modals.close();
          Toast.show('Risk added.', 'success');
          await switchTab('risks', productId);
        } catch (err) { Toast.show(err.message, 'error'); }
      },
    });
  }

  async function openEditRisk(riskId, productId) {
    const r = Router.state.risks.find(x => x.id === riskId);
    if (!r) return;

    var ownerOptions = ['—'];
    try {
      var members = await API.gates.teamMembers();
      ownerOptions = members.map(function(m){ return m.name; });
    } catch(e) {}
    if (r.owner && ownerOptions.indexOf(r.owner) === -1) ownerOptions.push(r.owner);

    Modals.form({
      title: 'Edit Risk',
      fields: [
        { key:'risk_code',  label:'Risk ID',    value:r.risk_code||'' },
        { key:'title',      label:'Risk Title', required:true, value:r.title },
        { key:'category',   label:'Category',   type:'select', value:r.category,
          options:['Technical','Operational','Compliance','Financial','Strategic','Resource'] },
        { key:'likelihood', label:'Likelihood', type:'select', value:r.likelihood,
          options:['Low','Medium','High'] },
        { key:'impact',     label:'Impact',     type:'select', value:r.impact,
          options:['Low','Medium','High','Critical'] },
        { key:'mitigation', label:'Mitigation', type:'textarea', value:r.mitigation||'' },
        { key:'owner',      label:'Owner', type:'select', value:r.owner||'', options:ownerOptions },
        { key:'status',     label:'Status',     type:'select', value:r.status,
          options:['Open','Monitoring','Mitigated','Closed'] },
      ],
      submitText: 'Save',
      onSubmit: async (data) => {
        try {
          await API.risks.update(riskId, data);
          Modals.close();
          Toast.show('Risk updated.', 'success');
          await switchTab('risks', productId);
        } catch (err) { Toast.show(err.message, 'error'); }
      },
    });
  }

  // ── FINANCIALS MODAL ──────────────────────────────────────
  function openEditFinancials(productId, finId) {
    const fin = finId ? Router.getFinancials(productId)[0] : null;
    Modals.form({
      title: finId ? 'Edit Financial Data' : 'Add Financial Data',
      fields: [
        { key:'approved_budget', label:'Approved Budget (USD)', type:'number',
          value:fin ? String(fin.approved_budget) : '', required:true },
        { key:'actual_spend', label:'Actual Spend (USD)', type:'number',
          value:fin ? String(fin.actual_spend) : '' },
        { key:'forecast', label:'Forecast (USD)', type:'number',
          value:fin ? String(fin.forecast) : '' },
        { key:'quarter', label:'Quarter', placeholder:'e.g. Q1-2025',
          value:fin?.quarter || '' },
        { key:'notes', label:'Notes', type:'textarea', value:fin?.notes || '' },
      ],
      submitText: 'Save',
      onSubmit: async (data) => {
        try {
          data.approved_budget = data.approved_budget || 0;
          data.actual_spend    = data.actual_spend || 0;
          data.forecast        = data.forecast || 0;
          if (finId) {
            await API.financials.update(finId, data);
          } else {
            data.product_id = productId;
            await API.financials.create(data);
          }
          Modals.close();
          Toast.show('Financial data saved.', 'success');
          await switchTab('financials', productId);
        } catch (err) { Toast.show(err.message, 'error'); }
      },
    });
  }

  // ── PARTNERSHIP MODAL ─────────────────────────────────────
  function openAddPartnership(type, productId) {
    Modals.form({
      title: `Add ${type.charAt(0).toUpperCase()+type.slice(1)} Partnership`,
      fields: [
        { key:'partner_name', label:'Partner Name', required:true,
          placeholder:'e.g. Siemens AG' },
        { key:'status', label:'Partnership Status', type:'select',
          options:['Partner Identified','Agreement Development','Agreement Signed','On Hold'] },
        { key:'description', label:'Description', type:'textarea',
          placeholder:'What is this partnership for?' },
        { key:'contact', label:'Contact Person', placeholder:'Name / email' },
      ],
      submitText: 'Add Partnership',
      onSubmit: async (data) => {
        // In a full build, this would POST to /api/partnerships
        // For now, show success and note it's stored in notes
        Toast.show(`Partnership added (feature in progress).`, 'info');
        Modals.close();
      },
    });
  }

  // ── Helper renderers ──────────────────────────────────────
  function quickStat(label, value, icon, color = '') {
    const colors = { green:'var(--green-600)', blue:'var(--blue-600)',
                     amber:'var(--color-warning)', red:'var(--color-danger)' };
    return `
      <div style="text-align:center;padding:14px 10px">
        <i class="fas ${icon}" style="font-size:16px;color:${colors[color]||'var(--gray-400)'};margin-bottom:6px"></i>
        <div style="font-size:14px;font-weight:700;color:var(--gray-900)">${value}</div>
        <div style="font-size:11px;color:var(--gray-500);margin-top:2px">${label}</div>
      </div>`;
  }

  function miniKpi(label, value, icon, color) {
    const colors = { green:'var(--green-600)', red:'var(--color-danger)',
                     amber:'var(--color-warning)', blue:'var(--blue-600)' };
    const bgs    = { green:'var(--color-success-bg)', red:'var(--color-danger-bg)',
                     amber:'var(--color-warning-bg)', blue:'var(--color-info-bg)' };
    return `
      <div style="background:${bgs[color]||'var(--gray-50)'};border-radius:var(--radius-md);
                  padding:16px;display:flex;align-items:center;gap:12px">
        <div style="width:40px;height:40px;border-radius:var(--radius-sm);background:rgba(255,255,255,0.12);
                    display:flex;align-items:center;justify-content:center;
                    color:${colors[color]||'var(--gray-500)'};font-size:18px;flex-shrink:0">
          <i class="fas ${icon}"></i>
        </div>
        <div>
          <div style="font-size:20px;font-weight:700;color:var(--gray-900)">${value}</div>
          <div style="font-size:12px;color:var(--gray-600)">${label}</div>
        </div>
      </div>`;
  }

  function infoRow(label, value) {
    return `
      <div style="display:flex;gap:12px;padding:9px 0;border-bottom:1px solid var(--gray-100)">
        <span style="font-size:12px;font-weight:600;color:var(--gray-500);
                     min-width:130px;flex-shrink:0">${label}</span>
        <span style="font-size:13px;color:var(--gray-800)">${value}</span>
      </div>`;
  }

  function finRow(label, value, color = '') {
    const colors = { blue:'var(--blue-600)', green:'var(--green-600)',
                     red:'var(--color-danger)', amber:'var(--color-warning)' };
    return `
      <div style="display:flex;justify-content:space-between;align-items:center;
                  padding:9px 0;border-bottom:1px solid var(--gray-100)">
        <span style="font-size:13px;color:var(--gray-600)">${label}</span>
        <span style="font-size:14px;font-weight:700;color:${colors[color]||'var(--gray-900)'}">
          ${value}
        </span>
      </div>`;
  }

  // ── Client Manager ────────────────────────────────────
  async function openClientManager(productId) {
    let allClients = [], linked = [];
    try {
      [allClients, linked] = await Promise.all([
        API.clients.list(),
        API.clients.forProduct(productId),
      ]);
    } catch(_) {}

    const linkedIds = linked.map(c => c.id);

    Modals.open({
      title: 'Manage Clients',
      size:  'sm',
      body: `
        <div style="margin-bottom:14px">
          <div style="font-size:12px;font-weight:600;color:var(--gray-700);margin-bottom:8px">
            Linked clients
          </div>
          <div id="linked-clients-list" style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px">
            ${linked.length ? linked.map(c => `
              <span style="display:flex;align-items:center;gap:6px;padding:4px 10px;
                           background:var(--color-info-bg);color:var(--blue-700);
                           border-radius:20px;font-size:12px;font-weight:600;
                           border:1px solid var(--blue-200)">
                ${c.name}
                <button onclick="unlinkClientNow(${productId},${c.id},this)"
                        style="color:var(--blue-400);font-size:10px;padding:0 2px">
                  <i class="fas fa-times"></i>
                </button>
              </span>`).join('')
              : '<span style="font-size:12px;color:var(--gray-400)">None linked</span>'}
          </div>
          <div style="font-size:12px;font-weight:600;color:var(--gray-700);margin-bottom:8px">
            Add client
          </div>
          <div style="display:flex;gap:8px">
            <select id="client-select" class="form-select" style="flex:1">
              <option value="">— Select client —</option>
              ${allClients.filter(c => !linkedIds.includes(c.id)).map(c =>
                `<option value="${c.id}">${c.name}</option>`
              ).join('')}
            </select>
            <button class="btn btn-primary btn-sm" onclick="linkClientNow(${productId})">
              <i class="fas fa-plus"></i> Link
            </button>
          </div>
          <div style="margin-top:14px;padding-top:12px;border-top:1px solid var(--gray-100)">
            <div style="font-size:12px;font-weight:600;color:var(--gray-700);margin-bottom:8px">
              Create new client
            </div>
            <div style="display:flex;gap:8px">
              <input type="text" id="new-client-name" class="form-input"
                     placeholder="Client name…" style="flex:1">
              <button class="btn btn-secondary btn-sm" onclick="createClientNow(${productId})">
                <i class="fas fa-building"></i> Create
              </button>
            </div>
          </div>
        </div>`,
      footer: `<button class="btn btn-primary" onclick="Modals.close()">Done</button>`,
    });
  }

  async function linkClientNow(productId) {
    const sel = document.getElementById('client-select');
    const clientId = parseInt(sel?.value);
    if (!clientId) { Toast.show('Select a client first.', 'warning'); return; }
    try {
      await API.clients.link(productId, clientId);
      Toast.show('Client linked.', 'success');
      await openClientManager(productId);
    } catch(err) { Toast.show(err.message, 'error'); }
  }

  async function unlinkClientNow(productId, clientId, btn) {
    try {
      await API.clients.unlink(productId, clientId);
      btn.closest('span').remove();
      Toast.show('Client removed.', 'success');
    } catch(err) { Toast.show(err.message, 'error'); }
  }

  async function createClientNow(productId) {
    const inp = document.getElementById('new-client-name');
    const name = inp?.value.trim();
    if (!name) { Toast.show('Enter a client name.', 'warning'); return; }
    try {
      const client = await API.clients.create({ name });
      await API.clients.link(productId, client.id);
      Toast.show(`${name} created and linked.`, 'success');
      inp.value = '';
      await openClientManager(productId);
    } catch(err) { Toast.show(err.message, 'error'); }
  }

  // Expose handlers globally (called via inline event attributes) —
  // must run before `return`, since code after a return in this IIFE
  // is unreachable.
  window.handleMentionInput   = handleMentionInput;
  window.handleMentionKeydown = handleMentionKeydown;
  window.selectMention        = selectMention;
  window.selectStageForChange = selectStageForChange;
  window.cancelStageChange    = cancelStageChange;
  window.confirmStageChange   = confirmStageChange;
  window.openClientManager    = openClientManager;
  window.linkClientNow        = linkClientNow;
  window.unlinkClientNow      = unlinkClientNow;
  window.createClientNow      = createClientNow;

  return {
    render,
    switchTab,
    openAddMilestone,
    openEditMilestone,
    confirmDeleteMilestone,
    openAddRisk,
    openEditRisk,
    openEditFinancials,
    openAddPartnership,
    postComment,
    openClientManager,
    linkClientNow,
    unlinkClientNow,
    createClientNow,
  };

})();
