/* ═══════════════════════════════════════════════════════════
   PD Dashboard — Aramco Digital
   theme.js  —  brand mark + shared particle background
═══════════════════════════════════════════════════════════ */

const PdLogo = (() => {
  let _instance = 0;

  function svg(size = 34) {
    const id = 'pd-logo-grad-' + (_instance++);
    return `
      <svg width="${size}" height="${size}" viewBox="0 0 100 100" role="img" aria-label="PD Dashboard">
        <defs>
          <linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#7C4DE0"/><stop offset="1" stop-color="#A783FF"/>
          </linearGradient>
        </defs>
        <path d="M0,0 L87.5,0 A12.5,12.5 0 0 1 100,12.5 L100,100 L12.5,100 A12.5,12.5 0 0 1 0,87.5 Z" fill="url(#${id})"/>
        <rect x="27" y="27" width="19" height="19" rx="4" fill="#fff"/>
        <rect x="54" y="27" width="19" height="19" rx="4" fill="#fff" opacity="0.7"/>
        <rect x="27" y="54" width="19" height="19" rx="4" fill="#fff" opacity="0.7"/>
        <rect x="54" y="54" width="19" height="19" rx="4" fill="#fff"/>
      </svg>`;
  }

  function mount(elementId, size = 34) {
    const el = document.getElementById(elementId);
    if (el) el.innerHTML = svg(size);
  }

  return { svg, mount };
})();

const ParticleBackground = (() => {
  // Dark-purple + slate tints read correctly against the white gradient.
  const PALETTE = ['rgba(124,77,224,', 'rgba(90,98,112,', 'rgba(124,77,224,'];
  const OP_MIN = 0.05, OP_MAX = 0.10;

  function mount(containerId = 'bg-particles') {
    const el = document.getElementById(containerId);
    if (!el || el.dataset.mounted) return;
    el.dataset.mounted = 'true';

    const N = 14;
    for (let i = 0; i < N; i++) {
      const size = 26 + Math.round(Math.random() * 32);
      const r = Math.round(size / 8);
      const op = (OP_MIN + Math.random() * (OP_MAX - OP_MIN)).toFixed(3);
      const d = document.createElement('div');
      d.className = 'particle';
      d.style.width = size + 'px';
      d.style.height = size + 'px';
      d.style.left = (Math.random() * 96) + '%';
      d.style.top = (Math.random() * 94) + '%';
      d.style.background = PALETTE[i % 3] + op + ')';
      d.style.borderRadius = `0 ${r}px 0 ${r}px`;
      d.style.animationDuration = (7 + Math.random() * 4) + 's';
      d.style.animationDelay = (-Math.random() * 5) + 's';
      el.appendChild(d);
    }
  }

  return { mount };
})();

document.addEventListener('DOMContentLoaded', () => {
  ParticleBackground.mount('bg-particles');
});
