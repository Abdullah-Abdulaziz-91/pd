/* ═══════════════════════════════════════════════════════════
   PD Dashboard — Aramco Digital
   router.js  —  page switching, state, data loading
═══════════════════════════════════════════════════════════ */

const Router = (() => {

  // ── App state (shared across all pages) ────────────────
  const state = {
    products:      [],
    milestones:    [],
    financials:    [],
    risks:         [],
    summary:       null,
    currentPage:   'overview',
    currentProduct: null,
    loaded:        false,
  };

  // ── Page registry ──────────────────────────────────────
  // Each page module must expose a render(params) function
  const pages = {
    overview:   { title: 'Executive Overview',  icon: 'fa-th-large',          render: () => Pages.Overview.render() },
    portfolio:  { title: 'Product Portfolio',   icon: 'fa-cubes',             render: (p) => Pages.Portfolio.render(p) },
    product:    { title: 'Product Detail',      icon: 'fa-cube',              render: (p) => Pages.Product.render(p) },
    financials: { title: 'Financials & ROI',    icon: 'fa-dollar-sign',       render: () => Pages.Financials.render() },
    decisions:  { title: 'Decisions & Risks',   icon: 'fa-exclamation-triangle', render: () => Pages.Decisions.render() },
    team:       { title: 'Team',                icon: 'fa-users',             render: () => Pages.Team.render() },
    logs:       { title: 'Audit Logs',          icon: 'fa-history',           render: () => Pages.Logs.render() },
    settings:   { title: 'Account Settings',    icon: 'fa-user-cog',          render: () => Pages.Settings.render() },
  };

  // ── Navigate to a page ─────────────────────────────────
  async function go(pageName, params = {}) {
    if (!pages[pageName]) return;

    // Hide all pages
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    // Deactivate all nav items
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));

    // Show target page
    const pageEl = document.getElementById(`page-${pageName}`);
    if (pageEl) pageEl.classList.add('active');

    // Activate nav button
    const navBtn = document.querySelector(`[data-page="${pageName}"]`);
    if (navBtn) navBtn.classList.add('active');

    // Update topbar title
    const titleEl = document.getElementById('topbar-title');
    if (titleEl) titleEl.textContent = pages[pageName].title;

    state.currentPage = pageName;

    // Show loading in page
    if (pageEl) {
      pageEl.innerHTML = `
        <div class="loading">
          <i class="fas fa-spinner fa-spin"></i>
          Loading…
        </div>`;
    }

    // Ensure data is loaded before rendering
    if (!state.loaded) await loadAll();

    // Render the page
    try {
      await pages[pageName].render(params);
    } catch (err) {
      console.error(`Error rendering ${pageName}:`, err);
      if (pageEl) {
        pageEl.innerHTML = `
          <div class="empty-state">
            <i class="fas fa-exclamation-circle"></i>
            <p>Failed to load page: ${err.message}</p>
          </div>`;
      }
    }
  }

  // ── Load all data from API ──────────────────────────────
  // Uses allSettled (not all) so that one restricted endpoint failing for
  // the current user (e.g. /financials/ for a non-finance-access account,
  // which correctly 403s) doesn't take down every other page's data too.
  async function loadAll() {
    const [products, milestones, financials, risks, summary] = await Promise.allSettled([
      API.products.list(),
      API.milestones.list(),
      API.financials.list(),
      API.risks.list(),
      API.products.summary(),
    ]);

    state.products   = products.status   === 'fulfilled' ? (products.value   || []) : [];
    state.milestones = milestones.status === 'fulfilled' ? (milestones.value || []) : [];
    state.financials = financials.status === 'fulfilled' ? (financials.value || []) : [];
    state.risks      = risks.status      === 'fulfilled' ? (risks.value      || []) : [];
    state.summary     = summary.status    === 'fulfilled' ? (summary.value    || {}) : {};
    state.loaded      = true;

    const failed = [products, milestones, financials, risks, summary].filter(r => r.status === 'rejected');
    if (failed.length) {
      console.error('loadAll: some data failed to load:', failed.map(f => f.reason?.message));
    }

    // Update sidebar badges
    updateBadges();
  }

  // ── Refresh data (called after create/update/delete) ───
  async function refresh() {
    state.loaded = false;
    await loadAll();
    await go(state.currentPage);
  }

  // ── Refresh only one entity type ───────────────────────
  async function refreshProducts() {
    try {
      state.products = await API.products.list() || [];
      state.summary  = await API.products.summary() || {};
      updateBadges();
    } catch (err) {
      Toast.show('Failed to refresh: ' + err.message, 'error');
    }
  }

  // ── Update sidebar badges ──────────────────────────────
  function updateBadges() {
    // Portfolio: total product count
    const portBadge = document.getElementById('nav-badge-portfolio');
    if (portBadge) portBadge.textContent = state.products.length || '';

    // Decisions: count of at-risk products
    const atRisk = state.products.filter(p =>
      p.action_required && p.action_required !== 'On Track'
    ).length;
    const decBadge = document.getElementById('nav-badge-decisions');
    if (decBadge) decBadge.textContent = atRisk || '';
  }

  // ── Init (called after login or session restore) ────────
  async function init() {
    await loadAll();
    // Load notifications in background
    Notifications.load();
    // Go to overview
    await go('overview');
  }

  // ── Reset (called on logout) ───────────────────────────
  function reset() {
    state.products      = [];
    state.milestones    = [];
    state.financials    = [];
    state.risks         = [];
    state.summary       = null;
    state.currentPage   = 'overview';
    state.currentProduct = null;
    state.loaded        = false;

    // Clear all page content
    document.querySelectorAll('.page').forEach(p => p.innerHTML = '');
  }

  // ── Helper: get product by id ──────────────────────────
  function getProduct(id) {
    return state.products.find(p => String(p.id) === String(id)) || null;
  }

  // ── Helper: get milestones for a product ───────────────
  function getMilestones(productId) {
    return state.milestones.filter(m => String(m.product_id) === String(productId));
  }

  // ── Helper: get financials for a product ───────────────
  function getFinancials(productId) {
    return state.financials.filter(f => String(f.product_id) === String(productId));
  }

  // ── Helper: get risks for a product ────────────────────
  function getRisks(productId) {
    return state.risks.filter(r => String(r.product_id) === String(productId));
  }

  // ── Format helpers used across all pages ───────────────
  const fmt = {
    // Currency: 1500000 → $1.5M
    currency(n) {
      n = Number(n) || 0;
      if (n >= 1_000_000) return '$' + (n / 1_000_000).toFixed(1) + 'M';
      if (n >= 1_000)     return '$' + (n / 1_000).toFixed(0) + 'K';
      return '$' + n.toLocaleString();
    },

    // Number with commas
    number(n) {
      return Number(n || 0).toLocaleString();
    },

    // Percentage
    pct(n) {
      return (Number(n) || 0).toFixed(1) + '%';
    },

    // Date: 2025-06-30 → Jun 30, 2025
    date(d) {
      if (!d) return '—';
      try {
        return new Date(d + 'T00:00:00').toLocaleDateString('en-GB', {
          day: '2-digit', month: 'short', year: 'numeric'
        });
      } catch { return d; }
    },

    // Time ago: 2025-06-25T10:00:00 → 2h ago
    timeAgo(iso) {
      if (!iso) return '';
      const diff = Date.now() - new Date(iso).getTime();
      const mins = Math.floor(diff / 60000);
      if (mins < 1)   return 'Just now';
      if (mins < 60)  return `${mins}m ago`;
      const hrs = Math.floor(mins / 60);
      if (hrs < 24)   return `${hrs}h ago`;
      const days = Math.floor(hrs / 24);
      if (days < 30)  return `${days}d ago`;
      return fmt.date(iso.slice(0, 10));
    },

    // Initials from name
    initials(name) {
      if (!name) return '?';
      return name.split(' ').slice(0, 2).map(w => w[0] || '').join('').toUpperCase();
    },
  };

  // ── Badge HTML helpers ─────────────────────────────────
  const badge = {
    stage(status) {
      const map = {
        'Concept':     'badge-concept',
        'Development': 'badge-development',
        'Validation':  'badge-validation',
        'Pilot':       'badge-pilot',
        'Scale-up':    'badge-scale-up',
        'Commercial':  'badge-commercial',
      };
      const cls = map[status] || 'badge-unknown';
      return `<span class="badge ${cls}">${status || 'Unknown'}</span>`;
    },

    priority(p) {
      const map = {
        'Critical': 'badge-critical',
        'High':     'badge-high',
        'Medium':   'badge-medium',
        'Low':      'badge-low',
      };
      const cls = map[p] || 'badge-medium';
      return `<span class="badge ${cls}">${p || '—'}</span>`;
    },

    msStatus(s) {
      const map = {
        'Done':        'badge-done',
        'On Track':    'badge-on-track',
        'At Risk':     'badge-at-risk',
        'Overdue':     'badge-overdue',
        'Not Started': 'badge-not-started',
        'Upcoming':    'badge-upcoming',
      };
      const cls = map[s] || 'badge-not-started';
      return `<span class="badge ${cls}">${s || '—'}</span>`;
    },

    riskStatus(s) {
      const map = {
        'Open':       'badge-open',
        'Monitoring': 'badge-monitoring',
        'Mitigated':  'badge-mitigated',
        'Closed':     'badge-closed',
      };
      const cls = map[s] || 'badge-open';
      return `<span class="badge ${cls}">${s || '—'}</span>`;
    },

    action(a) {
      if (!a || a === 'On Track') return `<span class="badge badge-on-track">On Track</span>`;
      if (a.toLowerCase().includes('critical')) return `<span class="badge badge-critical">${a}</span>`;
      if (a.toLowerCase().includes('overdue'))  return `<span class="badge badge-overdue">${a}</span>`;
      return `<span class="badge badge-at-risk">${a}</span>`;
    },
  };

  // ── Stage pipeline HTML ────────────────────────────────
  function stagePipeline(currentStage) {
    const stages = ['Concept', 'Development', 'Validation', 'Pilot', 'Scale-up', 'Commercial'];
    const curIdx = stages.indexOf(currentStage);
    return `
      <div class="stage-pipeline">
        ${stages.map((s, i) => {
          let cls = 'stage-step';
          if (i < curIdx)  cls += ' done';
          if (i === curIdx) cls += ' current';
          if (i > curIdx)  cls += ' future';
          return `<div class="${cls}">${s}</div>`;
        }).join('')}
      </div>`;
  }

  // ── Progress bar HTML ──────────────────────────────────
  function progressBar(pct, color = '') {
    const p = Math.min(100, Math.max(0, Number(pct) || 0));
    return `
      <div class="progress-label">
        <span>Completion</span>
        <span class="pct">${p}%</span>
      </div>
      <div class="progress-track">
        <div class="progress-fill ${color}" style="width:${p}%"></div>
      </div>`;
  }

  return {
    state,
    go,
    init,
    reset,
    refresh,
    refreshProducts,
    getProduct,
    getMilestones,
    getFinancials,
    getRisks,
    fmt,
    badge,
    stagePipeline,
    progressBar,
  };

})();

// ── Shorthand aliases used in page files ───────────────────
const State  = () => Router.state;
const fmt    = Router.fmt;
const badge  = Router.badge;
