/* ═══════════════════════════════════════════════════════════
   PD Dashboard — Aramco Digital
   notifications.js  —  bell, dropdown, polling
═══════════════════════════════════════════════════════════ */

const Notifications = (() => {

  let _items   = [];
  let _polling = null;

  // ── Icon + color per notification type ─────────────────
  const typeMap = {
    milestone_overdue:  { icon: 'fa-exclamation-circle', cls: 'red',   label: 'Milestone overdue' },
    milestone_due_soon: { icon: 'fa-clock',              cls: 'amber', label: 'Due soon' },
    milestone_assigned: { icon: 'fa-flag',               cls: 'blue',  label: 'Assigned to you' },
    new_comment:        { icon: 'fa-comment',            cls: 'green', label: 'New comment' },
    mention:            { icon: 'fa-at',                 cls: 'blue',  label: 'You were mentioned' },
    decision_assigned:  { icon: 'fa-gavel',              cls: 'red',   label: 'Decision assigned' },
  };

  function meta(type) {
    return typeMap[type] || { icon: 'fa-bell', cls: 'blue', label: 'Notification' };
  }

  // ── Load from API ───────────────────────────────────────
  async function load() {
    try {
      _items = await API.notifications.list() || [];
      render();
      updateBadge();
    } catch (_) {
      // Silently fail — notifications are non-critical
    }
  }

  // ── Render dropdown list ────────────────────────────────
  function render() {
    const list = document.getElementById('notif-list');
    if (!list) return;

    if (!_items.length) {
      list.innerHTML = `
        <div class="empty-state" style="padding:32px 20px">
          <i class="fas fa-check-circle" style="color:var(--green-400);font-size:28px;margin-bottom:10px"></i>
          <p>You're all caught up!</p>
        </div>`;
      return;
    }

    list.innerHTML = _items.slice(0, 12).map(n => {
      const m = meta(n.type);
      return `
        <div class="notif-item ${n.is_read ? '' : 'unread'}"
             onclick="Notifications.markRead(${n.id})">
          <div class="notif-icon ${m.cls}">
            <i class="fas ${m.icon}"></i>
          </div>
          <div class="notif-content">
            <div class="notif-title">${n.title}</div>
            ${n.body ? `<div class="notif-body">${n.body}</div>` : ''}
            <div class="notif-time">
              <i class="fas fa-clock"></i>
              ${fmt.timeAgo(n.created_at)}
            </div>
          </div>
          ${!n.is_read ? '<div class="notif-dot"></div>' : ''}
        </div>`;
    }).join('');
  }

  // ── Update badge count ──────────────────────────────────
  function updateBadge() {
    const unread = _items.filter(n => !n.is_read).length;
    const badge  = document.getElementById('notif-badge');
    if (!badge) return;
    if (unread > 0) {
      badge.textContent    = unread > 9 ? '9+' : unread;
      badge.style.display  = 'flex';
    } else {
      badge.style.display  = 'none';
    }
  }

  // ── Toggle dropdown ─────────────────────────────────────
  function toggle() {
    const dd = document.getElementById('notif-dropdown');
    if (!dd) return;
    const isOpen = dd.classList.contains('open');
    dd.classList.toggle('open', !isOpen);
    if (!isOpen) render(); // Re-render on open
  }

  function close() {
    const dd = document.getElementById('notif-dropdown');
    if (dd) dd.classList.remove('open');
  }

  // ── Mark single read ────────────────────────────────────
  async function markRead(id) {
    const item = _items.find(n => n.id === id);
    if (!item || item.is_read) return;
    item.is_read = true;
    render();
    updateBadge();
    try { await API.notifications.markRead(id); } catch (_) {}
  }

  // ── Mark all read ───────────────────────────────────────
  async function markAllRead() {
    _items.forEach(n => n.is_read = true);
    render();
    updateBadge();
    try { await API.notifications.markAllRead(); } catch (_) {}
  }

  // ── Start polling (every 60 seconds) ────────────────────
  function startPolling() {
    stopPolling();
    _polling = setInterval(() => load(), 60_000);
  }

  function stopPolling() {
    if (_polling) { clearInterval(_polling); _polling = null; }
  }

  // ── Push a local notification (instant, no API) ─────────
  // Used when user posts a comment, changes a status, etc.
  function push(type, title, body = null) {
    const fake = {
      id:         Date.now(),
      type,
      title,
      body,
      is_read:    false,
      created_at: new Date().toISOString(),
    };
    _items.unshift(fake);
    render();
    updateBadge();
  }

  return {
    load,
    render,
    toggle,
    close,
    markRead,
    markAllRead,
    startPolling,
    stopPolling,
    push,
  };

})();
