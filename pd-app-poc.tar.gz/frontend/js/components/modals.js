/* ═══════════════════════════════════════════════════════════
   PD Dashboard — Aramco Digital
   modals.js  —  shared modal system
═══════════════════════════════════════════════════════════ */

const Modals = (() => {

  function open({ title, body, footer = '', size = '' }) {
    const overlay = document.getElementById('modal-overlay');
    const box     = document.getElementById('modal-box');
    const hdr     = document.getElementById('modal-header');
    const bdy     = document.getElementById('modal-body');
    const ftr     = document.getElementById('modal-footer');

    // Size
    box.className = 'modal-box' + (size ? ` modal-${size}` : '');

    // Header
    hdr.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between">
        <h3 style="font-size:17px;font-weight:700;color:var(--gray-900)">${title}</h3>
        <button onclick="Modals.close()"
                style="width:30px;height:30px;border-radius:var(--radius-sm);
                       background:var(--gray-100);color:var(--gray-500);
                       font-size:14px;display:flex;align-items:center;justify-content:center;
                       transition:var(--transition)"
                onmouseover="this.style.background='var(--gray-200)'"
                onmouseout="this.style.background='var(--gray-100)'">
          <i class="fas fa-times"></i>
        </button>
      </div>`;

    bdy.innerHTML = body;
    ftr.innerHTML = footer;
    overlay.classList.add('open');

    // Trap focus
    setTimeout(() => {
      const first = bdy.querySelector('input, select, textarea, button');
      if (first) first.focus();
    }, 100);
  }

  function close() {
    document.getElementById('modal-overlay').classList.remove('open');
  }

  function closeOnOverlay(e) {
    if (e.target === document.getElementById('modal-overlay')) close();
  }

  // ── Confirm dialog ──────────────────────────────────────
  function confirm({ title, message, confirmText = 'Confirm', danger = false, onConfirm }) {
    open({
      title,
      size: 'sm',
      body: `<p style="font-size:14px;color:var(--gray-700);line-height:1.6">${message}</p>`,
      footer: `
        <button class="btn btn-secondary" onclick="Modals.close()">Cancel</button>
        <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}"
                onclick="Modals._confirmNow()">
          ${confirmText}
        </button>`,
    });
    // Store the callback directly (with its closure intact) instead of
    // serializing it into the onclick attribute, which would run in global
    // scope and lose access to any variables the callback closes over.
    Modals._onConfirm = onConfirm;
  }

  function _confirmNow() {
    close();
    if (Modals._onConfirm) Modals._onConfirm();
  }

  // ── Form modal helper ───────────────────────────────────
  function form({ title, fields, submitText = 'Save', onSubmit }) {
    const fieldsHtml = fields.map(f => {
      if (f.type === 'divider') {
        return `<div class="divider-label" style="margin:16px 0 10px">${f.label}</div>`;
      }
      const required = f.required ? '<span class="required">*</span>' : '';
      let input = '';

      if (f.type === 'select') {
        input = `
          <select id="mf-${f.key}" class="form-select" ${f.required ? 'required' : ''}>
            ${(f.options || []).map(o =>
              typeof o === 'string'
                ? `<option value="${o}" ${f.value === o ? 'selected' : ''}>${o}</option>`
                : `<option value="${o.value}" ${f.value === o.value ? 'selected' : ''}>${o.label}</option>`
            ).join('')}
          </select>`;
      } else if (f.type === 'textarea') {
        input = `<textarea id="mf-${f.key}" class="form-textarea"
                           placeholder="${f.placeholder || ''}"
                           rows="${f.rows || 3}">${f.value || ''}</textarea>`;
      } else {
        input = `<input id="mf-${f.key}" type="${f.type || 'text'}"
                        class="form-input"
                        placeholder="${f.placeholder || ''}"
                        value="${f.value || ''}"
                        ${f.required ? 'required' : ''}>`;
      }

      return `
        <div class="form-group">
          <label class="form-label">${f.label}${required}</label>
          ${input}
          ${f.hint ? `<div class="form-hint">${f.hint}</div>` : ''}
        </div>`;
    }).join('');

    open({
      title,
      body: `<form id="modal-form" onsubmit="return false">${fieldsHtml}</form>`,
      footer: `
        <button class="btn btn-secondary" onclick="Modals.close()">Cancel</button>
        <button class="btn btn-primary" onclick="Modals._submitForm()">
          <i class="fas fa-save"></i> ${submitText}
        </button>`,
    });

    // Store submit handler
    Modals._onSubmit = onSubmit;
  }

  // Internal: collect form values and call onSubmit
  function _submitForm() {
    const form = document.getElementById('modal-form');
    if (!form) return;

    // Basic validation
    const required = form.querySelectorAll('[required]');
    for (const el of required) {
      if (!el.value.trim()) {
        el.style.borderColor = 'var(--color-danger)';
        el.focus();
        Toast.show('Please fill in all required fields.', 'error');
        return;
      }
    }

    // Collect values
    const data = {};
    form.querySelectorAll('[id^="mf-"]').forEach(el => {
      const key = el.id.replace('mf-', '');
      data[key] = el.value.trim();
    });

    if (Modals._onSubmit) Modals._onSubmit(data);
  }

  return {
    open,
    close,
    closeOnOverlay,
    confirm,
    form,
    _submitForm,
    _confirmNow,
    _onSubmit: null,
    _onConfirm: null,
  };

})();
