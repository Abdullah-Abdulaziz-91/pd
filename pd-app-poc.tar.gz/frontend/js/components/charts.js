/* ═══════════════════════════════════════════════════════════
   PD Dashboard — Aramco Digital
   charts.js  —  Chart.js wrappers with Aramco Digital colors
═══════════════════════════════════════════════════════════ */

const Charts = (() => {

  // Active chart instances (for destroy on re-render)
  const _instances = {};

  // Chart.js draws on <canvas>, so it can't resolve var(--x) itself —
  // read the live computed CSS custom property instead.
  function cv(name, fallback) {
    const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return v || fallback;
  }

  // ── Brand palette (read live so it follows the active mode) ─────
  // purple = signature/primary series; green/amber/red reserved for status.
  const COLORS = {
    get green()  { return [cv('--green','#34C77E'), cv('--green-text','#2CA968'), '#249053', '#5CD497', '#84DFAF', '#B8EDD1']; },
    get blue()   { return [cv('--info','#5B9BFF'), '#4A85E0', '#78ADFF', '#9DC0EE', '#B7D2F5', '#D6E5FF']; },
    get mixed()  { return [cv('--purple-strong','#8B5CF6'), cv('--info','#5B9BFF'), cv('--purple','#A783FF'), cv('--green','#34C77E'), cv('--amber','#EDB256'), cv('--red','#E06C6B')]; },
    get status() {
      return {
        'Concept':     cv('--ink3','#9AA0A7'),
        'Development': cv('--purple-strong','#8B5CF6'),
        'Validation':  cv('--info','#5B9BFF'),
        'Pilot':       cv('--amber','#EDB256'),
        'Scale-up':    cv('--green','#34C77E'),
        'Commercial':  cv('--green-text','#2CA968'),
        'Unknown':     cv('--ink3','#85898F'),
      };
    },
    get priority() {
      return {
        'Critical': '#7C2D2D',
        'High':     cv('--red','#E06C6B'),
        'Medium':   cv('--amber','#EDB256'),
        'Low':      cv('--green','#34C77E'),
      };
    },
    get ms() {
      return {
        'Done':        cv('--green','#34C77E'),
        'On Track':    cv('--green','#34C77E'),
        'At Risk':     cv('--amber','#EDB256'),
        'Overdue':     cv('--red','#E06C6B'),
        'Not Started': cv('--ink3','#9AA0A7'),
        'Upcoming':    cv('--purple-strong','#8B5CF6'),
      };
    },
  };

  // ── Default Chart.js options ────────────────────────────
  // Defensive: Chart.js (CDN) may not be loaded yet or may fail to load.
  // Without this guard, a missing/incomplete Chart object throws here and
  // silently kills every script that loads after charts.js (overview.js,
  // portfolio.js, product.js, etc.) causing "X is not defined" errors
  // everywhere even though those files are perfectly correct.
  function applyChartDefaults() {
    if (typeof Chart !== 'undefined' && Chart.defaults && Chart.defaults.font) {
      Chart.defaults.font.family = "'Outfit', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
      Chart.defaults.font.size   = 12;
      Chart.defaults.color       = cv('--ink3', '#9AA0A7');
    } else {
      console.warn('Chart.js not fully loaded - chart styling defaults skipped.');
    }
  }
  applyChartDefaults();

  // ── Destroy and recreate ────────────────────────────────
  function destroy(id) {
    if (_instances[id]) {
      _instances[id].destroy();
      delete _instances[id];
    }
  }

  function create(id, config) {
    destroy(id);
    applyChartDefaults(); // re-read tokens each time in case the mode changed
    const canvas = document.getElementById(id);
    if (!canvas) return null;
    _instances[id] = new Chart(canvas, config);
    return _instances[id];
  }

  // ── Donut chart ─────────────────────────────────────────
  function donut(id, { labels, data, colors, title = '' }) {
    return create(id, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [{
          data,
          backgroundColor: colors || COLORS.mixed,
          borderWidth: 2,
          borderColor: cv('--overlay-bg', '#38383d'),
          hoverOffset: 6,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        plugins: {
          legend: {
            position: 'right',
            labels: {
              padding: 14,
              usePointStyle: true,
              pointStyleWidth: 10,
              font: { size: 12 },
              color: cv('--ink2', '#C4C8CE'),
            },
          },
          tooltip: {
            callbacks: {
              label: (ctx) => ` ${ctx.label}: ${ctx.parsed} (${
                Math.round(ctx.parsed / ctx.dataset.data.reduce((a,b) => a+b, 0) * 100)
              }%)`,
            },
          },
        },
      },
    });
  }

  // ── Bar chart ───────────────────────────────────────────
  function bar(id, { labels, datasets, horizontal = false, stacked = false }) {
    const gridColor = cv('--line', 'rgba(255,255,255,0.08)');
    const tickColor = cv('--ink3', '#9AA0A7');
    return create(id, {
      type: 'bar',
      data: { labels, datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: horizontal ? 'y' : 'x',
        plugins: {
          legend: { display: datasets.length > 1, labels: { color: tickColor } },
        },
        scales: {
          x: {
            stacked,
            grid: { color: gridColor },
            ticks: { font: { size: 11 }, color: tickColor },
          },
          y: {
            stacked,
            beginAtZero: true,
            grid: { color: gridColor },
            ticks: { font: { size: 11 }, color: tickColor },
          },
        },
      },
    });
  }

  // ── Line chart ──────────────────────────────────────────
  function line(id, { labels, datasets }) {
    const gridColor = cv('--line', 'rgba(255,255,255,0.08)');
    const tickColor = cv('--ink3', '#9AA0A7');
    return create(id, {
      type: 'line',
      data: { labels, datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: { legend: { display: datasets.length > 1, labels: { color: tickColor } } },
        scales: {
          x: { grid: { color: gridColor }, ticks: { font: { size: 11 }, color: tickColor } },
          y: { beginAtZero: true, grid: { color: gridColor }, ticks: { font: { size: 11 }, color: tickColor } },
        },
        elements: {
          line:  { tension: 0.4 },
          point: { radius: 3, hoverRadius: 6 },
        },
      },
    });
  }

  // ── Stage distribution bar ──────────────────────────────
  function stageBar(id, products) {
    const stages = ['Concept', 'Development', 'Validation', 'Pilot', 'Scale-up', 'Commercial'];
    const counts = stages.map(s => products.filter(p => p.status === s).length);
    return bar(id, {
      labels:   stages,
      datasets: [{
        label: 'Products',
        data:  counts,
        backgroundColor: stages.map(s => COLORS.status[s] || cv('--ink3', '#9AA0A7')),
        borderRadius: 6,
        borderSkipped: false,
      }],
    });
  }

  // ── Priority donut ──────────────────────────────────────
  function priorityDonut(id, products) {
    const priorities = ['Critical', 'High', 'Medium', 'Low'];
    const counts     = priorities.map(p => products.filter(x => x.priority === p).length)
                                 .filter((_, i) => products.some(x => x.priority === priorities[i]));
    const labels     = priorities.filter(p => products.some(x => x.priority === p));
    return donut(id, {
      labels,
      data:   counts,
      colors: labels.map(p => COLORS.priority[p]),
    });
  }

  // ── Milestone status donut ──────────────────────────────
  function msDonut(id, milestones) {
    const statuses = ['Done', 'On Track', 'At Risk', 'Overdue', 'Not Started', 'Upcoming'];
    const counts   = statuses.map(s => milestones.filter(m => m.status === s).length);
    const filtered = statuses.filter((_, i) => counts[i] > 0);
    const filteredCounts = counts.filter(c => c > 0);
    return donut(id, {
      labels: filtered,
      data:   filteredCounts,
      colors: filtered.map(s => COLORS.ms[s]),
    });
  }

  // ── Budget vs spend horizontal bars ─────────────────────
  function budgetBars(id, financials) {
    const labels  = financials.map(f => f.product_name || `Product ${f.product_id}`);
    return bar(id, {
      labels,
      horizontal: true,
      datasets: [
        {
          label: 'Budget',
          data:  financials.map(f => Number(f.approved_budget) || 0),
          backgroundColor: cv('--purple-soft', 'rgba(139,92,246,0.20)'),
          borderColor:     cv('--purple-strong', '#8B5CF6'),
          borderWidth: 1,
          borderRadius: 4,
        },
        {
          label: 'Actual Spend',
          data:  financials.map(f => Number(f.actual_spend) || 0),
          backgroundColor: financials.map(f => {
            const util = Number(f.utilization_pct) || 0;
            if (util > 90) return cv('--red', 'rgba(224,108,107,0.85)');
            if (util > 70) return cv('--amber', 'rgba(237,178,86,0.85)');
            return cv('--green', 'rgba(52,199,126,0.85)');
          }),
          borderRadius: 4,
        },
      ],
    });
  }

  return {
    COLORS,
    destroy,
    create,
    donut,
    bar,
    line,
    stageBar,
    priorityDonut,
    msDonut,
    budgetBars,
  };

})();
