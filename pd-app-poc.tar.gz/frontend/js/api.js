/* ═══════════════════════════════════════════════════════════
   PD Dashboard — Aramco Digital
   api.js  —  all REST calls to the FastAPI backend
═══════════════════════════════════════════════════════════ */

const API = (() => {

  const BASE = 'http://localhost:8000/api';
  window.API_BASE_URL = "https://actual-backend-url/api"

  // ── Token helpers ──────────────────────────────────────
  const token = {
    get:   ()    => localStorage.getItem('pd_token'),
    set:   (t)   => localStorage.setItem('pd_token', t),
    clear: ()    => localStorage.removeItem('pd_token'),
  };

  const user = {
    get:   ()    => JSON.parse(localStorage.getItem('pd_user') || 'null'),
    set:   (u)   => localStorage.setItem('pd_user', JSON.stringify(u)),
    clear: ()    => localStorage.removeItem('pd_user'),
  };

  // ── Base fetch ─────────────────────────────────────────
  async function req(method, path, body = null, isForm = false) {
    const headers = {};
    const t = token.get();
    if (t) headers['Authorization'] = `Bearer ${t}`;
    if (body && !isForm) headers['Content-Type'] = 'application/json';

    const opts = { method, headers };
    if (body) opts.body = isForm ? body : JSON.stringify(body);

    let res;
    try {
      res = await fetch(BASE + path, opts);
    } catch (err) {
      throw new Error('Cannot reach server. Check that the backend is running.');
    }

    // Session expired
    if (res.status === 401) {
      token.clear();
      user.clear();
      if (window.Auth) Auth.showLogin('Session expired. Please sign in again.');
      throw new Error('Unauthorized');
    }

    if (res.status === 204) return null;

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      const msg = data.detail || data.message || `Server error ${res.status}`;
      throw new Error(Array.isArray(msg) ? msg.map(e => e.msg).join(', ') : msg);
    }

    return data;
  }

  const get    = (path)        => req('GET',    path);
  const post   = (path, body)  => req('POST',   path, body);
  const patch  = (path, body)  => req('PATCH',  path, body);
  const put    = (path, body)  => req('PUT',    path, body);
  const del    = (path)        => req('DELETE', path);
  const upload = (path, form)  => req('POST',   path, form, true);

  // ── Build query string ─────────────────────────────────
  function qs(params = {}) {
    const p = Object.entries(params)
      .filter(([, v]) => v !== null && v !== undefined && v !== '')
      .map(([k, v]) => `${k}=${encodeURIComponent(v)}`);
    return p.length ? '?' + p.join('&') : '';
  }

  // ══════════════════════════════════════════════════════
  // AUTH
  // ══════════════════════════════════════════════════════
  const auth = {
    login:          (email, password) => post('/auth/login', { email, password }),
    logout:         ()                => post('/auth/logout'),
    me:             ()                => get('/auth/me'),
    updateMe:       (data)            => put('/auth/me', data),
    changePassword: (current_password, new_password) =>
                      post('/auth/change-password', { current_password, new_password }),
    // SSO is a scaffold today (see SSO_SETUP.md) — ssoStatus() lets the
    // login screen know whether to show the button at all.
    ssoStatus:      ()                => get('/auth/sso/status'),
    ssoLoginUrl:    BASE + '/auth/sso/login',
  };

  // ══════════════════════════════════════════════════════
  // PRODUCTS
  // ══════════════════════════════════════════════════════
  const products = {
    list:    (params = {}) => get('/products/'   + qs(params)),
    get:     (id)          => get(`/products/${id}`),
    summary: ()            => get('/products/summary'),

    create: (data)         => post('/products/', data),
    update: (id, data)     => patch(`/products/${id}`, data),
    delete: (id)           => del(`/products/${id}`),

    setPriority: (id, priority) => put(`/products/${id}/priority`, { priority }),
  };

  // ══════════════════════════════════════════════════════
  // MILESTONES
  // ══════════════════════════════════════════════════════
  const milestones = {
    list:   (params = {}) => get('/milestones/' + qs(params)),
    create: (data)        => post('/milestones/', data),
    update: (id, data)    => patch(`/milestones/${id}`, data),
    delete: (id)          => del(`/milestones/${id}`),
  };

  // ══════════════════════════════════════════════════════
  // FINANCIALS
  // ══════════════════════════════════════════════════════
  const financials = {
    list:   (params = {}) => get('/financials/' + qs(params)),
    create: (data)        => post('/financials/', data),
    update: (id, data)    => patch(`/financials/${id}`, data),
  };

  // ══════════════════════════════════════════════════════
  // RISKS
  // ══════════════════════════════════════════════════════
  const risks = {
    list:   (params = {}) => get('/risks/' + qs(params)),
    create: (data)        => post('/risks/', data),
    update: (id, data)    => patch(`/risks/${id}`, data),
  };

  // ══════════════════════════════════════════════════════
  // COMMENTS
  // ══════════════════════════════════════════════════════
  const comments = {
    list:   (productId)                   => get(`/comments/${productId}`),
    add:    (productId, body, mentions=[]) =>
              post(`/comments/${productId}`, { body, mentions }),
    delete: (id)                          => del(`/comments/${id}`),
  };

  // ══════════════════════════════════════════════════════
  // NOTIFICATIONS
  // ══════════════════════════════════════════════════════
  const notifications = {
    list:        (unreadOnly = false) =>
                   get('/notifications/' + qs({ unread_only: unreadOnly })),
    unreadCount: ()    => get('/notifications/unread-count'),
    markAllRead: ()    => post('/notifications/mark-read'),
    markRead:    (id)  => post(`/notifications/${id}/read`),
  };

  // ══════════════════════════════════════════════════════
  // USERS  (Admin only)
  // ══════════════════════════════════════════════════════
  const users = {
    list:       ()            => get('/users/'),
    create:     (data)        => post('/users/', data),
    changeRole: (id, role)    => patch(`/users/${id}/role`, { role }),
    deactivate: (id)          => del(`/users/${id}`),
    activate:   (id)          => post(`/users/${id}/activate`),
  };

  // ══════════════════════════════════════════════════════
  // AUDIT LOGS  (Admin only)
  // ══════════════════════════════════════════════════════
  const logs = {
    list: (params = {}) => get('/logs/' + qs(params)),
  };

  // ══════════════════════════════════════════════════════
  // EXCEL IMPORT  (Admin only)
  // ══════════════════════════════════════════════════════
  const importExcel = (file) => {
    const form = new FormData();
    form.append('file', file);
    return upload('/import/excel', form);
  };

  // ══════════════════════════════════════════════════════
  // GATES
  // ══════════════════════════════════════════════════════
  const gates = {
    list:           ()           => get('/gates/'),
    progress:       (productId)  => get(`/gates/progress/${productId}`),
    heatmap:        ()           => get('/gates/heatmap'),
    updateTaskStatus: (data)     => put('/gates/task-status', data),
    setDate:        (data)       => put('/gates/date', data),
    reorder:        (data)       => put('/gates/reorder', data),
    teamMembers:    ()           => get('/gates/team-members'),
    updateGate:     (id, data)   => patch(`/gates/${id}`, data),
    addTask:        (gateId, data) => post(`/gates/${gateId}/tasks`, data),
    deleteTask:     (taskId)     => del(`/gates/tasks/${taskId}`),
  };

  const clients = {
    list:          ()                    => get('/clients/'),
    summary:       ()                    => get('/clients/summary'),
    create:        (data)                => post('/clients/', data),
    delete:        (id)                  => del(`/clients/${id}`),
    forProduct:    (productId)           => get(`/clients/product/${productId}`),
    link:          (productId, clientId) => post(`/clients/product/${productId}/${clientId}`, {}),
    unlink:        (productId, clientId) => del(`/clients/product/${productId}/${clientId}`),
  };

  const partnerships = {
    list:   (productId)          => get(`/partnerships/${productId}`),
    create: (productId, data)    => post(`/partnerships/${productId}`, data),
    update: (id, data)           => patch(`/partnerships/${id}`, data),
    delete: (id)                 => del(`/partnerships/${id}`),
  };

  // ══════════════════════════════════════════════════════
  // PUBLIC TOKEN/USER ACCESS (used by auth.js)
  // ══════════════════════════════════════════════════════
  return {
    token,
    user,
    auth,
    gates,
    clients,
    partnerships,
    products,
    milestones,
    financials,
    risks,
    comments,
    notifications,
    users,
    logs,
    importExcel,
  };

})();
