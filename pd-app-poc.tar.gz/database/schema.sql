-- ════════════════════════════════════════════════════════════
--  PD Dashboard — Aramco Digital
--  schema.sql  —  FINAL CONSOLIDATED SCHEMA
--
--  This is the ONLY file needed to set up the database.
--  It replaces and combines: schema.sql + migrate_v2.sql +
--  migrate_v3.sql + fix_gate_view.sql
--
--  Run once on a fresh PostgreSQL 15+ database:
--    psql -U pd_user -d pd_dashboard -f schema.sql
--
--  Default login after setup:
--    Email:    pd.admin@aramcodigital.com
--    Password: admin
--    >>> CHANGE THIS PASSWORD IMMEDIATELY AFTER FIRST LOGIN <<<
-- ════════════════════════════════════════════════════════════

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ════════════════════════════════════════════════════════════
-- TABLES
-- ════════════════════════════════════════════════════════════

-- ── USERS ──────────────────────────────────────────────────
CREATE TABLE users (
    id              SERIAL PRIMARY KEY,
    email           VARCHAR(255) UNIQUE NOT NULL,
    name            VARCHAR(255) NOT NULL,
    password_hash   VARCHAR(255),
        -- NULL for SSO-provisioned accounts (auth_provider != 'local') —
        -- they never have a local password to check.
    role            VARCHAR(50)  NOT NULL DEFAULT 'Team Lead',
        -- Admin | Manager | Team Lead
    department      VARCHAR(255),
    initials        VARCHAR(10),
    finance_access  BOOLEAN NOT NULL DEFAULT FALSE,
        -- Admin always has finance access regardless of this flag
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    auth_provider   VARCHAR(20) NOT NULL DEFAULT 'local',
        -- local | oidc — see SSO_SETUP.md
    sso_subject     VARCHAR(255) UNIQUE,
        -- The IdP's stable unique subject/user id (OIDC 'sub' claim).
        -- NULL for local accounts; multiple NULLs are fine under UNIQUE.
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT users_password_or_sso CHECK (
        (auth_provider = 'local' AND password_hash IS NOT NULL) OR
        (auth_provider != 'local' AND sso_subject IS NOT NULL)
    )
);

-- ── PRODUCTS ───────────────────────────────────────────────
CREATE TABLE products (
    id                SERIAL PRIMARY KEY,
    product_code      VARCHAR(50) UNIQUE NOT NULL,
    name              VARCHAR(255) NOT NULL,
    description       TEXT,
    status            VARCHAR(50)  NOT NULL DEFAULT 'Unknown',
        -- Concept | Development | Validation | Pilot | Scale-up | Commercial
    priority          VARCHAR(20)  NOT NULL DEFAULT 'Medium',
        -- Critical | High | Medium | Low
    completion        INTEGER NOT NULL DEFAULT 0 CHECK (completion BETWEEN 0 AND 100),
    action_required   VARCHAR(255),
    team_lead         VARCHAR(255),
    team_lead_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    start_date        DATE,
        -- Overall product start (used for Overall column RAG calculation)
    readiness_date    DATE,
        -- Target launch date (used for Overall column RAG calculation)
    pipeline_value    NUMERIC(15,2),
    customer_count    INTEGER DEFAULT 0,
    notes             TEXT,
    is_active         BOOLEAN NOT NULL DEFAULT TRUE,
        -- FALSE = archived (soft delete, data preserved)
    created_by        INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── GATES  (10 standard lifecycle gates — Admin editable) ───
CREATE TABLE gates (
    id           SERIAL PRIMARY KEY,
    gate_number  INTEGER NOT NULL UNIQUE,
    name         VARCHAR(255) NOT NULL,
    description  TEXT,
    weight       NUMERIC(5,2) NOT NULL DEFAULT 10.0,
        -- Percentage weight in overall product score; all weights should sum to 100
    is_active    BOOLEAN NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── GATE TASKS  (template checklist items per gate) ─────────
CREATE TABLE gate_tasks (
    id          SERIAL PRIMARY KEY,
    gate_id     INTEGER NOT NULL REFERENCES gates(id) ON DELETE CASCADE,
    task_name   VARCHAR(255) NOT NULL,
    workstream  VARCHAR(100),
    description TEXT,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    is_active   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── PRODUCT GATE TASKS  (per-product task status) ───────────
CREATE TABLE product_gate_tasks (
    id             SERIAL PRIMARY KEY,
    product_id     INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    gate_task_id   INTEGER NOT NULL REFERENCES gate_tasks(id) ON DELETE CASCADE,
    status         VARCHAR(20) NOT NULL DEFAULT 'Not Started',
        -- Complete | In Progress | Not Started | N/A
        -- N/A tasks are excluded from gate score calculation
    owner          VARCHAR(255),
    owner_user_id  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    due_date       DATE,
    completed_date DATE,
    notes          TEXT,
    updated_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (product_id, gate_task_id)
);

-- ── PRODUCT GATE DATES  (per-product, per-gate dates/lead) ──
CREATE TABLE product_gate_dates (
    id                SERIAL PRIMARY KEY,
    product_id        INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    gate_id           INTEGER NOT NULL REFERENCES gates(id)    ON DELETE CASCADE,
    start_date        DATE,
        -- Default = previous gate's due date in the UI, but freely editable
        -- (gates can run in parallel)
    due_date          DATE,
    gate_lead         VARCHAR(255),
    gate_lead_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    updated_by        INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (product_id, gate_id)
);

-- ── MILESTONES  (legacy — superseded by Gates, kept for compat) ──
CREATE TABLE milestones (
    id          SERIAL PRIMARY KEY,
    product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    name        VARCHAR(255) NOT NULL,
    description TEXT,
    due_date    DATE NOT NULL,
    status      VARCHAR(50) NOT NULL DEFAULT 'Not Started',
    assigned_to INTEGER REFERENCES users(id) ON DELETE SET NULL,
    notes       TEXT,
    created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── FINANCIALS  (restricted: Admin + finance_access users) ──
CREATE TABLE financials (
    id              SERIAL PRIMARY KEY,
    product_id      INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    approved_budget NUMERIC(15,2) NOT NULL DEFAULT 0,
    actual_spend    NUMERIC(15,2) NOT NULL DEFAULT 0,
    forecast        NUMERIC(15,2) NOT NULL DEFAULT 0,
    quarter         VARCHAR(20),
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(product_id, quarter)
);

-- ── RISKS ──────────────────────────────────────────────────
CREATE TABLE risks (
    id            SERIAL PRIMARY KEY,
    risk_code     VARCHAR(50),
    product_id    INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    title         VARCHAR(255) NOT NULL,
    description   TEXT,
    category      VARCHAR(100),
        -- Technical | Operational | Compliance | Financial | Strategic | Resource
    likelihood    VARCHAR(20),
        -- Low | Medium | High
    impact        VARCHAR(20),
        -- Low | Medium | High | Critical
    risk_score    INTEGER,
        -- Auto-calculated: likelihood_weight * impact_weight (see trigger below)
    mitigation    TEXT,
    owner         VARCHAR(255),
    owner_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    status        VARCHAR(50) NOT NULL DEFAULT 'Open',
        -- Open | Monitoring | Mitigated | Closed
    created_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── PARTNERSHIPS ───────────────────────────────────────────
CREATE TABLE partnerships (
    id              SERIAL PRIMARY KEY,
    product_id      INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    partner_name    VARCHAR(255) NOT NULL,
    type            VARCHAR(50)  NOT NULL DEFAULT 'Other',
        -- Hardware | Software | Other
    status          VARCHAR(50)  NOT NULL DEFAULT 'Partner Identified',
        -- Partner Identified | Agreement Development | Agreement Signed | On Hold
    contact_name    VARCHAR(255),
    contact_email   VARCHAR(255),
    description     TEXT,
    notes           TEXT,
    created_by      INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── CLIENTS ────────────────────────────────────────────────
CREATE TABLE clients (
    id         SERIAL PRIMARY KEY,
    name       VARCHAR(255) NOT NULL UNIQUE,
    is_active  BOOLEAN NOT NULL DEFAULT TRUE,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── PRODUCT ↔ CLIENT  (many-to-many) ─────────────────────────
CREATE TABLE product_clients (
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    client_id  INTEGER NOT NULL REFERENCES clients(id)  ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (product_id, client_id)
);

-- ── COMMENTS ───────────────────────────────────────────────
CREATE TABLE comments (
    id          SERIAL PRIMARY KEY,
    product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    body        TEXT NOT NULL,
    mentions    TEXT[],
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── NOTIFICATIONS ──────────────────────────────────────────
CREATE TABLE notifications (
    id          SERIAL PRIMARY KEY,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type        VARCHAR(50) NOT NULL,
    title       VARCHAR(255) NOT NULL,
    body        TEXT,
    link        VARCHAR(255),
    is_read     BOOLEAN NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── AUDIT LOGS ─────────────────────────────────────────────
CREATE TABLE audit_logs (
    id          SERIAL PRIMARY KEY,
    user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    user_name   VARCHAR(255),
    action_type VARCHAR(50) NOT NULL,
        -- login | logout | create | update | delete | comment | upload | export
    entity_type VARCHAR(50),
    entity_id   INTEGER,
    entity_name VARCHAR(255),
    field_name  VARCHAR(100),
    old_value   TEXT,
    new_value   TEXT,
    detail      TEXT,
    ip_address  VARCHAR(50),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── DECISION PRIORITIES ────────────────────────────────────
CREATE TABLE decision_priorities (
    product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    set_by      INTEGER REFERENCES users(id) ON DELETE SET NULL,
    priority    VARCHAR(20) NOT NULL DEFAULT 'High',
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (product_id)
);


-- ════════════════════════════════════════════════════════════
-- INDEXES
-- ════════════════════════════════════════════════════════════
CREATE INDEX idx_products_status            ON products(status);
CREATE INDEX idx_products_priority          ON products(priority);
CREATE INDEX idx_milestones_product         ON milestones(product_id);
CREATE INDEX idx_milestones_due_date        ON milestones(due_date);
CREATE INDEX idx_comments_product           ON comments(product_id);
CREATE INDEX idx_notifications_user         ON notifications(user_id, is_read);
CREATE INDEX idx_audit_logs_user            ON audit_logs(user_id);
CREATE INDEX idx_risks_product              ON risks(product_id);
CREATE INDEX idx_gate_tasks_gate            ON gate_tasks(gate_id);
CREATE INDEX idx_product_gate_tasks_product ON product_gate_tasks(product_id);
CREATE INDEX idx_product_gate_tasks_task    ON product_gate_tasks(gate_task_id);
CREATE INDEX idx_product_gate_dates_product ON product_gate_dates(product_id);
CREATE INDEX idx_partnerships_product       ON partnerships(product_id);
CREATE INDEX idx_partnerships_type          ON partnerships(type);
CREATE INDEX idx_product_clients_product    ON product_clients(product_id);
CREATE INDEX idx_product_clients_client     ON product_clients(client_id);


-- ════════════════════════════════════════════════════════════
-- VIEWS
-- ════════════════════════════════════════════════════════════

-- ── Gate progress per product per gate (FINAL CORRECTED VERSION) ──
-- Fixes: counts ALL gate_tasks even if no product_gate_tasks row exists yet
-- (previous version under-counted total_tasks, causing 1/5 = 100% bug)
CREATE VIEW v_gate_progress AS
SELECT
    p.id                    AS product_id,
    p.name                  AS product_name,
    g.id                    AS gate_id,
    g.gate_number,
    g.name                  AS gate_name,
    g.weight                AS gate_weight,
    pgd.due_date            AS gate_due_date,
    pgd.start_date          AS gate_start_date,
    pgd.gate_lead,

    -- Count ALL tasks in the gate template (not just ones with status rows)
    COUNT(DISTINCT gt.id) AS total_tasks,

    COUNT(DISTINCT gt.id) FILTER (
        WHERE COALESCE(pgt.status,'Not Started') = 'Complete')     AS complete_tasks,
    COUNT(DISTINCT gt.id) FILTER (
        WHERE COALESCE(pgt.status,'Not Started') = 'In Progress')  AS in_progress_tasks,
    COUNT(DISTINCT gt.id) FILTER (
        WHERE COALESCE(pgt.status,'Not Started') = 'N/A')          AS na_tasks,
    COUNT(DISTINCT gt.id) FILTER (
        WHERE COALESCE(pgt.status,'Not Started') = 'Not Started')  AS not_started_tasks,

    -- Any individual task overdue?
    BOOL_OR(
        pgt.due_date IS NOT NULL
        AND pgt.due_date < CURRENT_DATE
        AND COALESCE(pgt.status,'Not Started') NOT IN ('Complete','N/A')
    ) AS has_overdue_task,

    -- Gate itself overdue (due date passed, not all tasks complete)?
    (pgd.due_date IS NOT NULL
     AND pgd.due_date < CURRENT_DATE
     AND COUNT(DISTINCT gt.id) FILTER (WHERE COALESCE(pgt.status,'Not Started')='Complete') <
         COUNT(DISTINCT gt.id) FILTER (WHERE COALESCE(pgt.status,'Not Started')!='N/A')
    ) AS gate_overdue,

    -- Gate completion % — N/A tasks excluded from denominator
    CASE
        WHEN COUNT(DISTINCT gt.id) FILTER (
            WHERE COALESCE(pgt.status,'Not Started') != 'N/A') = 0 THEN 0
        ELSE ROUND((
            SUM(CASE COALESCE(pgt.status,'Not Started')
                WHEN 'Complete'    THEN 1.0
                WHEN 'In Progress' THEN 0.5
                ELSE 0 END)
            / NULLIF(COUNT(DISTINCT gt.id) FILTER (
                WHERE COALESCE(pgt.status,'Not Started') != 'N/A'), 0)
            * 100)::numeric, 1)
    END AS gate_pct,

    -- Schedule health: % of gate's own start->due window already elapsed
    CASE
        WHEN pgd.start_date IS NULL OR pgd.due_date IS NULL THEN NULL
        WHEN pgd.due_date <= pgd.start_date THEN NULL
        ELSE ROUND(
            (CURRENT_DATE - pgd.start_date)::numeric /
            NULLIF((pgd.due_date - pgd.start_date)::numeric, 0) * 100
        , 1)
    END AS time_consumed_pct

FROM products p
CROSS JOIN gates g
LEFT JOIN product_gate_dates pgd ON pgd.product_id = p.id AND pgd.gate_id = g.id
LEFT JOIN gate_tasks gt          ON gt.gate_id = g.id AND gt.is_active = TRUE
LEFT JOIN product_gate_tasks pgt ON pgt.gate_task_id = gt.id AND pgt.product_id = p.id
WHERE p.is_active = TRUE AND g.is_active = TRUE
GROUP BY p.id, p.name, g.id, g.gate_number, g.name, g.weight,
         pgd.due_date, pgd.start_date, pgd.gate_lead
ORDER BY p.id, g.gate_number;


-- ── Overall weighted completion per product ─────────────────
CREATE VIEW v_product_gate_completion AS
SELECT
    product_id,
    product_name,
    ROUND(SUM(gate_pct * gate_weight / 100)::numeric, 1) AS overall_pct
FROM v_gate_progress
GROUP BY product_id, product_name;


-- ── Financials with computed columns ─────────────────────────
CREATE VIEW v_financials AS
SELECT
    f.*,
    p.name          AS product_name,
    p.product_code,
    CASE WHEN f.approved_budget > 0
         THEN ROUND((f.actual_spend / f.approved_budget * 100)::numeric, 1)
         ELSE 0 END AS utilization_pct,
    f.actual_spend - f.approved_budget AS variance
FROM financials f
JOIN products p ON p.id = f.product_id;


-- ════════════════════════════════════════════════════════════
-- TRIGGERS
-- ════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at      BEFORE UPDATE ON users              FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_products_updated_at   BEFORE UPDATE ON products           FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_milestones_updated_at BEFORE UPDATE ON milestones         FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_financials_updated_at BEFORE UPDATE ON financials         FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_risks_updated_at      BEFORE UPDATE ON risks              FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_comments_updated_at   BEFORE UPDATE ON comments           FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_gates_updated_at      BEFORE UPDATE ON gates              FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_gate_tasks_updated_at BEFORE UPDATE ON gate_tasks         FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_pgt_updated_at        BEFORE UPDATE ON product_gate_tasks FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_pgd_updated_at        BEFORE UPDATE ON product_gate_dates FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_partnerships_updated_at BEFORE UPDATE ON partnerships     FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_clients_updated_at    BEFORE UPDATE ON clients            FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Auto-calculate risk score from likelihood × impact
CREATE OR REPLACE FUNCTION calc_risk_score()
RETURNS TRIGGER AS $$
BEGIN
    NEW.risk_score :=
        (CASE NEW.likelihood WHEN 'Low' THEN 1 WHEN 'Medium' THEN 2 WHEN 'High' THEN 3 ELSE 2 END) *
        (CASE NEW.impact WHEN 'Low' THEN 1 WHEN 'Medium' THEN 2 WHEN 'High' THEN 3 WHEN 'Critical' THEN 4 ELSE 2 END);
    RETURN NEW;
END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_risks_calc_score
    BEFORE INSERT OR UPDATE OF likelihood, impact ON risks
    FOR EACH ROW EXECUTE FUNCTION calc_risk_score();


-- ════════════════════════════════════════════════════════════
-- SEED DATA
-- ════════════════════════════════════════════════════════════

-- ── Admin account ─────────────────────────────────────────
-- Email:    pd.admin@aramcodigital.com
-- Password: admin   <<< CHANGE IMMEDIATELY AFTER FIRST LOGIN >>>
INSERT INTO users (email, name, password_hash, role, department, initials, finance_access)
VALUES (
    'pd.admin@aramcodigital.com',
    'Admin',
    '$2b$12$P4RZapETqDn5Gj/59S29duZL8FOEU4qfIbAK6xQVb.XN.NXCo9WGe',
    'Admin',
    'Digital Innovation',
    'AD',
    TRUE
);

-- ── 10 standard gates (equal weight, Admin can adjust later) ──
INSERT INTO gates (gate_number, name, weight) VALUES
(1,  'Product Definition',    10),
(2,  'Solution Design',       10),
(3,  'Partnership Readiness', 10),
(4,  'Product Build',         10),
(5,  'Pilot Validation',      10),
(6,  'Commercialization',     10),
(7,  'Operational Readiness', 10),
(8,  'Go-To-Market Ready',    10),
(9,  'Launch',                10),
(10, 'Revenue Generation',    10);

-- ── Gate task checklist (58 tasks across all 10 gates) ──────
INSERT INTO gate_tasks (gate_id, task_name, workstream, sort_order) VALUES
-- Gate 1: Product Definition
(1,'Requirements approved','Product Development',1),
(1,'Product scope approved','Product Development',2),
(1,'Business requirements completed','Product Development',3),
(1,'Technical requirements completed','Product Development',4),
(1,'PRD finalised','Product Development',5),
-- Gate 2: Solution Design
(2,'Architecture completed','Product Development',1),
(2,'Security review completed','Product Development',2),
(2,'Integration design completed','Product Development',3),
(2,'Hosting / deployment model defined','Product Development',4),
(2,'Solution Architecture Document signed off','Product Development',5),
-- Gate 3: Partnership Readiness
(3,'Partnership dependencies identified','Partnerships',1),
(3,'Partners identified','Partnerships',2),
(3,'Technical evaluation completed','Partnerships',3),
(3,'Commercial evaluation completed','Partnerships',4),
(3,'Agreements signed','Partnerships',5),
(3,'Partnership Readiness Report issued','Partnerships',6),
-- Gate 4: Product Build
(4,'Development completed','Product Development',1),
(4,'Internal testing completed','Product Development',2),
(4,'Security testing completed','Product Development',3),
(4,'Integration testing completed','Product Development',4),
(4,'UAT completed','Product Development',5),
(4,'Release Candidate produced','Product Development',6),
-- Gate 5: Pilot Validation
(5,'Pilot environment ready','Product Development',1),
(5,'Pilot deployed','Product Development',2),
(5,'KPI measurements completed','Product Development',3),
(5,'Customer feedback received','Product Development',4),
(5,'Improvements completed','Product Development',5),
(5,'Pilot Assessment Report issued','Product Development',6),
-- Gate 6: Commercialization
(6,'Cost model built (HW/SW/cloud/3rd-party/rev-share/impl/support/CS)','Commercialization',1),
(6,'Margin analysis completed','Commercialization',2),
(6,'Pricing approval obtained','Commercialization',3),
(6,'Pricing tiers defined','Commercialization',4),
(6,'Product packages defined','Commercialization',5),
(6,'Service bundles defined','Commercialization',6),
(6,'SLA levels defined','Commercialization',7),
(6,'Commercialization Package approved','Commercialization',8),
-- Gate 7: Operational Readiness
(7,'Service delivery model defined','Operations',1),
(7,'L1 / L2 / L3 support defined','Operations',2),
(7,'Customer success model defined','Operations',3),
(7,'Escalation process defined','Operations',4),
(7,'SOPs documented','Operations',5),
(7,'Operations Readiness Package signed off','Operations',6),
-- Gate 8: Go-To-Market Ready
(8,'Sales deck created','Go-To-Market',1),
(8,'Demos prepared','Go-To-Market',2),
(8,'Proposal templates ready','Go-To-Market',3),
(8,'Case studies created','Go-To-Market',4),
(8,'Datasheets created','Go-To-Market',5),
(8,'Brochures created','Go-To-Market',6),
(8,'Website content published','Go-To-Market',7),
(8,'Sales Enablement Package complete','Go-To-Market',8),
-- Gate 9: Launch
(9,'Product launched','Go-To-Market',1),
(9,'Available for sale confirmed','Go-To-Market',2),
(9,'Launch Report issued','Go-To-Market',3),
-- Gate 10: Revenue Generation
(10,'First opportunity created','Revenue Realization',1),
(10,'Proposal submitted','Revenue Realization',2),
(10,'Customer acquired','Revenue Realization',3),
(10,'Revenue realized','Revenue Realization',4),
(10,'Revenue Performance Report issued','Revenue Realization',5);


-- ════════════════════════════════════════════════════════════
-- VERIFY  (run automatically — review output after setup)
-- ════════════════════════════════════════════════════════════
SELECT 'users'      AS table_name, COUNT(*) AS row_count FROM users
UNION ALL SELECT 'gates',                COUNT(*) FROM gates
UNION ALL SELECT 'gate_tasks',           COUNT(*) FROM gate_tasks
UNION ALL SELECT 'products',             COUNT(*) FROM products
UNION ALL SELECT 'clients',              COUNT(*) FROM clients
UNION ALL SELECT 'partnerships',         COUNT(*) FROM partnerships
UNION ALL SELECT 'product_gate_dates',   COUNT(*) FROM product_gate_dates
ORDER BY table_name;

SELECT 'v_gate_progress columns' AS check_name, COUNT(*) AS col_count
FROM information_schema.columns WHERE table_name = 'v_gate_progress';
