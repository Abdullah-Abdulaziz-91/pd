# PD Dashboard
## Product Development Portfolio Management Platform
### Aramco Digital — Digital Innovation Division

---

## Project Objective

PD Dashboard is an internal platform built for **Aramco Digital** to manage, track,
and monitor the full lifecycle of digital products from concept to revenue generation.

The platform gives product managers, team leads, and executives a single source of
truth for:

- **Where each product stands** in the development lifecycle
- **Whether it is on schedule** based on gate due dates vs actual progress
- **What risks and partnerships** are associated with each product
- **Who the clients are** and how many products serve each client
- **Financial health** of the portfolio (budget vs actual spend)
- **What actions are needed** across the entire product portfolio

---

## Problem Being Solved

Before this platform, Aramco Digital teams tracked product progress manually
using spreadsheets, emails, and disconnected tools. This led to:

- No single view of all products and their stages
- No standard way to measure progress across different products
- Difficulty identifying which products were at risk or overdue
- No audit trail of who changed what and when
- Executives had no real-time dashboard to assess portfolio health

**PD Dashboard solves all of this in one web application.**

---

## Who Uses It

| Role | What They Do in the System |
|------|---------------------------|
| **Admin** | Full access — manages users, gate weights, views all data including financials |
| **Manager** | Creates and edits products, manages risks, partnerships, and clients |
| **Team Lead** | Updates gate tasks on their assigned products, adds comments |
| **Executive** | Views the Overview dashboard — heatmap, Gantt, KPIs, client portfolio |

---

## Core Features

### 1. Executive Overview Dashboard
A single-page summary for leadership showing:
- **5 KPI cards** — Total Products, Avg Completion, Needs Attention, Overdue Products, Open Risks
- **Products Progress Heatmap** — Products × 10 Gates grid colored by schedule health (Red/Yellow/Green)
- **Product Launch Gantt Chart** — Timeline view showing each product's start → launch date with completion bar
- **Client Portfolio Panel** — How many products belong to each client
- **At-Risk Products List** — Products flagged as needing attention
- **Financial Snapshot** — Budget vs actual spend across the portfolio

### 2. Product Portfolio
- List of all active products with stage, priority, completion, owner
- Filter by stage (Concept / Development / Validation / Pilot / Scale-up / Commercial)
- Sort by Priority, Completion, or Name
- Search by product name, description, or owner
- Add, Edit, Archive, and Delete products

### 3. Product Detail (6 tabs per product)

#### Overview Tab
- Product header: stage badge, priority, action required, pipeline value, customer count
- Clickable stage pipeline (click any stage → confirm bar → updates stage)
- Clients section: add/remove/create clients linked to this product
- Progress bar, owner, target launch date, last updated

#### Gates Tab (G1–G10)
- 10 accordion cards — click any gate to expand its checklist tasks
- Each task has: Status (Complete / In Progress / Not Started / N/A), Owner (team dropdown), Due Date
- Gate-level: Start Date, Due Date, Gate Lead (set via calendar icon; also shown as a badge next to it on the gate row itself)
- Overall weighted score shown at the top
- Admin can drag-and-drop gates to reorder them
- Admin can add/remove tasks from any gate

#### Partnerships Tab
- Hardware, Software, Other categories
- Full CRUD: partner name, status, contact name, contact email, description
- Status options: Partner Identified / Agreement Development / Agreement Signed / On Hold

#### Financials Tab
- Restricted to Admin and users explicitly granted finance access
- Approved budget, actual spend, forecast per quarter
- Budget utilization % and variance

#### Risks Tab
- Auto-generated Risk ID (R001, R002...)
- Category, Likelihood, Impact (auto-calculates risk score)
- Mitigation plan, owner (team dropdown), status

#### Comments Tab
- Team discussion thread per product
- @mention autocomplete — type @ to get a dropdown of team members
- Mentions trigger notifications to tagged users

### 4. Gate Progress Heatmap
- **Rows** = Products, **Columns** = G1 to G10 + Overall
- **Color logic (RAG):**
  - 🔴 Red = overdue (due date passed with incomplete tasks)
  - 🟡 Yellow = at risk (progress is less than 75% of time consumed)
  - 🟢 Green = on track
  - ⬜ Gray = not started (no dates, no progress)
- **Overall column** = weighted average of all gates, colored using product's start_date → readiness_date

### 5. Clients Management
- Clients are a shared entity (not per-product)
- One client can be linked to many products
- Create new clients inline from the product overview tab
- Client portfolio visible in Executive Overview

### 6. Settings (Admin)
- Edit profile and change password
- Manage users: create accounts, assign roles, grant finance access, deactivate/reactivate
- Edit gate weights (must sum to 100%, enforced client-side)
- View audit logs link

Login is currently email + password (JWT-based). The app is SSO-ready but
inactive — see [SSO_SETUP.md](SSO_SETUP.md) for what's already built and
how to connect a real identity provider.

### 7. Audit Logs (Admin)
- Every action logged: login, create, update, delete, comment, export
- Captures: who, what, when, old value, new value, IP address

### 8. Notifications
- In-app notification bell
- Triggered by @mentions in comments

---

## The 10-Gate Lifecycle

Every product follows the same 10-gate lifecycle. Each gate has a standard
checklist of tasks that must be completed before the product moves forward.

| Gate | Name | Workstream |
|------|------|-----------|
| G1 | Product Definition | Product Development |
| G2 | Solution Design | Product Development |
| G3 | Partnership Readiness | Partnerships |
| G4 | Product Build | Product Development |
| G5 | Pilot Validation | Product Development |
| G6 | Commercialization | Commercialization |
| G7 | Operational Readiness | Operations |
| G8 | Go-To-Market Ready | Go-To-Market |
| G9 | Launch | Go-To-Market |
| G10 | Revenue Generation | Revenue Realization |

**58 standard checklist tasks** are seeded across all 10 gates.
Each task can be: Complete / In Progress / Not Started / N/A.
N/A tasks are excluded from the gate score calculation.

### Gate Score Formula
```
Gate Score = (Complete × 1.0 + In Progress × 0.5) / Eligible Tasks × 100%

where Eligible Tasks = Total Tasks − N/A Tasks
```

### Overall Product Score
```
Overall = SUM(Gate Score[i] × Gate Weight[i] / 100)  for i = 1 to 10

Default weight = 10% per gate (Admin can adjust)
```

---

## Schedule Health Logic (RAG)

The heatmap uses **time consumed vs progress** to determine health:

```
Time Consumed % = (Today − Gate Start Date) / (Gate Due Date − Gate Start Date) × 100

At Risk if: Progress % < Time Consumed % × 0.75
Overdue if: Due Date < Today AND not 100% complete
```

For the **Overall column**, the product's `start_date` → `readiness_date` (launch date)
is used instead of individual gate dates.

---

## Technology Stack

| Layer | Technology |
|-------|-----------|
| **Backend language** | Python 3.11 |
| **Backend framework** | FastAPI |
| **Database ORM** | SQLAlchemy 2.0 (async) |
| **Database** | PostgreSQL 15+ |
| **Authentication** | JWT (JSON Web Tokens) + bcrypt |
| **Frontend language** | Vanilla JavaScript (no framework) |
| **Frontend architecture** | Single Page Application (custom router) |
| **Charts** | Chart.js (CDN) |
| **Icons** | Font Awesome 6 (CDN) |
| **Hosting** | Google Cloud Run |
| **Database hosting** | Google Cloud SQL |
| **Containers** | Docker + nginx |
| **CI/CD** | GitLab CI + Jenkins |

---

## Access Control

| Permission | Admin | Manager | Team Lead |
|-----------|-------|---------|-----------|
| View all products | ✅ | ✅ | ✅ |
| Create products | ✅ | ✅ | ❌ |
| Edit any product | ✅ | ✅ | Own only |
| Archive product | ✅ | ✅ | ❌ |
| Delete product | ✅ | ❌ | ❌ |
| View financials | ✅ | If granted | If granted |
| Manage users | ✅ | ❌ | ❌ |
| Edit gate weights | ✅ | ❌ | ❌ |
| Reorder gates | ✅ | ❌ | ❌ |
| View audit logs | ✅ | ❌ | ❌ |

---

## Data Model Summary

```
products ──────────────────── the core entity
    │
    ├── product_gate_tasks    task status per product per gate task
    ├── product_gate_dates    start/due date and lead per gate per product
    ├── product_clients ────── many-to-many link to clients
    ├── partnerships          hardware/software/other vendors
    ├── financials            budget/spend per quarter
    ├── risks                 risk register with auto score
    ├── milestones            legacy (replaced by gates)
    └── comments              team discussion with @mentions

gates ──────────────────────── 10 standard lifecycle gates
    └── gate_tasks            58 standard checklist items

users ──────────────────────── team accounts
    └── notifications         in-app alerts

audit_logs ─────────────────── full action history
clients ────────────────────── external organizations
```

---

## Project Metrics

| Metric | Value |
|--------|-------|
| Backend files | 23 Python files |
| Frontend files | 19 HTML/CSS/JS files (+1 optional local-dev helper script) |
| Database tables | 16 tables |
| Database views | 3 views |
| API endpoints | 40+ endpoints |
| Gate tasks seeded | 58 tasks across 10 gates |
| Lines of code (approx) | ~8,800 lines |

---

## Deployment

The application is designed to run on **Google Cloud Platform**:

```
User Browser
     │
     ▼
Cloud Run (Frontend — nginx serving static files)
     │ API calls over HTTPS
     ▼
Cloud Run (Backend — FastAPI Python app)
     │ Private IP connection
     ▼
Cloud SQL (PostgreSQL 15)
     │
Secret Manager (DATABASE_URL, SECRET_KEY)
```

---

## First Steps After Deployment

1. Login with `pd.admin@aramcodigital.com` / `admin`
2. **Change the admin password immediately**
3. Go to Settings → Manage Users → create team accounts
4. Grant finance access to appropriate users
5. Go to Product Portfolio → Add Product for each product
6. Open each product → Gates tab → set start and due dates per gate
7. Assign team leads and gate leads
8. Begin tracking gate task completion

---

*PD Dashboard — Aramco Digital*
*Built: July 2026*