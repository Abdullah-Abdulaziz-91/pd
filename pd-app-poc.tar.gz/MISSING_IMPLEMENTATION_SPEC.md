# PD Dashboard — Missing Implementation Specification

> **Status: all implemented.** This is a point-in-time record from the start
> of this engagement, when the files below genuinely did not exist anywhere
> in the delivered package. Every one of them has since been written and is
> now in the codebase — see `BUGS_AND_FIXES.md` for what was fixed along the
> way, and the actual files for current behavior. Kept here as the design
> rationale for *why* each piece works the way it does, not as a to-do list.

This document lists every file that `main.py`, `index.html`, and the existing
frontend pages reference but that does not exist anywhere in the delivered
`package/` folder. It was reverse-engineered from:

- `database/schema.sql` (authoritative table/view/trigger definitions)
- `backend/app/models/models.py` and `backend/app/schemas/schemas.py`
- The 3 backend routers that DO exist (`clients.py`, `gates.py`, `partnerships.py`) — used as the style/pattern reference
- `frontend/js/api.js`, `router.js`, and all existing page files, which call
  specific endpoints with specific payload shapes
- `ARCHITECTURE.md` / `DEPLOYMENT_HANDOVER.md`

Anywhere the frontend and the docs disagree, the **frontend wins** — it is
the thing that actually has to work.

---

## Backend — Core

### `backend/requirements.txt`
Referenced by `Dockerfile` and `README.md`, never present.
```
fastapi
uvicorn[standard]
sqlalchemy[asyncio]>=2.0
asyncpg
psycopg2-binary
pydantic[email]
python-jose[cryptography]
passlib[bcrypt]
bcrypt<4.0
python-multipart
python-dotenv
openpyxl
```
Note: `passlib[bcrypt]` requires `bcrypt<4.0` (passlib 1.7.4 breaks on bcrypt 4.x's removed `__about__`).

### `backend/app/core/config.py`
Pydantic `Settings` (BaseSettings) reading `.env` per `.env.example`:
`DATABASE_URL`, `SYNC_DATABASE_URL`, `SECRET_KEY`, `ALGORITHM`,
`ACCESS_TOKEN_EXPIRE_MINUTES`, `APP_ENV`, `FRONTEND_URL`. Exposes singleton
`settings`. `main.py` imports `settings.APP_ENV` and `settings.FRONTEND_URL`.

### `backend/app/core/database.py`
- `Base` — declarative base, imported by `models/models.py` (`from app.core.database import Base`).
- Async SQLAlchemy `engine` built from `settings.DATABASE_URL` (asyncpg driver).
- `async def get_db()` — yields an `AsyncSession`, used as a FastAPI dependency everywhere (`Depends(get_db)`).

### `backend/app/core/security.py`
Referenced by every router as `from app.core.security import get_current_user, require_admin, require_manager_or_above`.
- `hash_password(pw) -> str` / `verify_password(pw, hash) -> bool` (bcrypt via passlib).
- `create_access_token(user_id) -> str` — JWT HS256, `sub=user_id`, `exp = now + ACCESS_TOKEN_EXPIRE_MINUTES`.
- `get_current_user(token: Bearer, db) -> User` — decode JWT, `SELECT * FROM users WHERE id=:id AND is_active=TRUE`, 401 if missing/invalid/inactive.
- `require_manager_or_above(user=Depends(get_current_user)) -> User` — 403 unless role in (Admin, Manager).
- `require_admin(user=Depends(get_current_user)) -> User` — 403 unless role == Admin.
- `require_finance_access(user=Depends(get_current_user)) -> User` — 403 unless Admin or `finance_access=True`. Used by `data.py` financials endpoints.

### `backend/app/models/user.py`
`User` SQLAlchemy model matching the `users` table in `schema.sql`
(id, email, name, password_hash, role, department, initials, finance_access,
is_active, created_at, updated_at). Must be registered against the same
`Base` as `models/models.py` since that file does `relationship("User", ...)`
by string name — both modules need to be imported before any relationship
is resolved (import `User` in `models/__init__.py` or directly in `main.py`
via the routers that import `app.models.user`).
Add back-populated relationships: `comments`, `notifications`, `audit_logs`
(referenced by `models.py` as `back_populates="user"` / `"comments"` etc.)

---

## Backend — Services

### `backend/app/services/audit.py`
`async def log_action(db, user, action_type, entity_type=None, entity_id=None, entity_name=None, field_name=None, old_value=None, new_value=None, detail=None, ip_address=None)`
— inserts one row into `audit_logs`. Called (and already awaited, then
followed by a *second* `db.commit()`) throughout `clients.py`, `gates.py`,
`partnerships.py` — so `log_action` itself must **not** call `commit()`
itself if the callers already commit before calling it... actually inspect
call sites: callers call `db.commit()` BEFORE `log_action`, then
`log_action` inserts, then callers call `db.commit()` AGAIN. So
`log_action` should just `db.add(...)` (or `INSERT`) and let the caller's
second `commit()` flush it. Match this exactly or every audit log call
silently no-ops.

### `backend/app/services/notifications.py`
`async def notify_user(db, user_id, type, title, body=None, link=None)` —
inserts one row into `notifications`.
`async def notify_mentions(db, mentions: list[str], product_id, product_name, author_name)`
— resolves each mention string (first name / full name, case-insensitive)
against `users.name`, and calls `notify_user(type='mention', ...)` for each
match. Called from the comments endpoint in `data.py` after a comment is created.

---

## Backend — API Routers

### `backend/app/api/auth.py`
Prefix `/api/auth`. Contract fixed by `api.js`:
- `POST /login` — body `{email, password}` → `{access_token, token_type:"bearer", user}` (matches `TokenResponse`/`LoginRequest` schema). 401 on bad credentials or inactive user. Logs `action_type="login"` to audit_logs.
- `POST /logout` — no-op (JWT is stateless) but keep the route since `api.js` calls it on every logout; return `{"message":"Logged out"}`.
- `GET /me` — `Depends(get_current_user)` → `UserOut`.
- `PUT /me` — body `{name?, department?}` (`UserUpdate` schema) → updated `UserOut`. `settings.js` calls this.
- `POST /change-password` — body `{current_password, new_password}` (`PasswordChange` schema). Verify current, bcrypt-hash new, `UPDATE users SET password_hash=...`. 400 if current password wrong.

### `backend/app/api/products.py`
Prefix `/api/products`. Contract fixed by `api.js` + `portfolio.js` + `product.js`:
- `GET /` — list active products (`is_active=TRUE`), any authenticated user. Supports optional query params but frontend currently calls it with none (loads all, filters client-side) — keep params optional/ignored-if-absent for forward compat.
- `GET /summary` — `DashboardSummary` shape (total_products, by_status, by_priority, avg_completion, milestone_total/done/overdue, total_budget, total_spend, open_risks, critical_risks). `router.js` calls this on every `loadAll()`.
- `GET /{id}` — single product. `product.js` reads `product.updated_at`, `product.team_lead_user_id` etc. — return full `ProductOut`.
- `POST /` — Manager/Admin only (`require_manager_or_above`). Body = `ProductCreate`. `product_code` must be unique — 400 with clear message on conflict (portfolio.js auto-suggests the next code client-side, but a race is possible). Sets `created_by=current_user.id`.
- `PATCH /{id}` — Manager/Admin only, OR the product's own `team_lead_user_id` (Team Lead can edit their own product per the access-control table in PROJECT_OVERVIEW.md). Body = `ProductUpdate` (partial). **Must support `{is_active:false}`** — this is how `Pages.Portfolio.confirmArchive()` archives a product (soft delete, no separate archive endpoint exists in `api.js`).
- `DELETE /{id}` — **Admin only** (hard delete per access table — Manager cannot delete). Cascades via FK `ON DELETE CASCADE` already defined in schema.sql for milestones/financials/risks/comments/product_gate_tasks/product_gate_dates/product_clients/partnerships; `team_lead_user_id`/`created_by` on other rows are `ON DELETE SET NULL` so this is safe.
- `PUT /{id}/priority` — body `{priority}}`, sets `priority` column. (`API.products.setPriority` exists in api.js but nothing currently calls it — implement anyway since it's part of the public contract and cheap.)

Every create/update/delete must call `log_action(...)`.

### `backend/app/api/data.py`
Four routers combined in one file, exactly matching `main.py`'s import:
`milestones_router, financials_router, risks_router, comments_router`.

**Milestones** — prefix `/api/milestones` (legacy table, still used by `product.js` tabMilestones and `Router.state.milestones`):
- `GET /?product_id=` — filter by product_id if given, else all.
- `POST /` — body `MilestoneCreate` (includes `product_id`).
- `PATCH /{id}` — body `MilestoneUpdate`.
- `DELETE /{id}` — hard delete.
- Manager/Admin or the product's own team lead can write; anyone can read.

**Financials** — prefix `/api/financials`. **Restricted**: only Admin or users with `finance_access=True` may read or write (`require_finance_access`). This must be enforced server-side — `product.js`'s client-side check (`Auth.isAdmin() || Auth.currentUser()?.finance_access`) is UI-only and not a security boundary.
- `GET /?product_id=` — join `v_financials` view for `utilization_pct`/`variance`.
- `POST /` — body `FinancialCreate`. Table has `UNIQUE(product_id, quarter)` — on conflict, either 409 or upsert (recommend upsert via `ON CONFLICT DO UPDATE`, matching the style of `gates.py`, since `product.js openEditFinancials` treats "no financials yet" and "existing financials" as the same form).
- `PATCH /{id}` — body `FinancialUpdate`.

**Risks** — prefix `/api/risks`:
- `GET /?product_id=`
- `POST /` — body `RiskCreate`. Do **not** set `risk_score` manually — the `trg_risks_calc_score` trigger computes it from likelihood × impact on insert/update; just insert the columns the trigger reads.
- `PATCH /{id}` — body `RiskUpdate`.
- Manager/Admin write; anyone read.

**Comments** — prefix `/api/comments`:
- `GET /{product_id}` — list for a product, joined with `users` for `author_name`/`author_initials` (schema `CommentOut` expects these).
- `POST /{product_id}` — body `CommentCreate` (`body`, `mentions: string[]`). Insert with `user_id=current_user.id`. After insert, call `notify_mentions(db, mentions, product_id, product.name, current_user.name)` from `services/notifications.py` — **this is the actual @mention → notification link**; without it, mentions are stored but nobody gets notified.
- `DELETE /{id}` — author or Admin only.
- Any authenticated user can read/post (per PROJECT_OVERVIEW: Team Lead can "add comments").

### `backend/app/api/admin.py`
Four routers combined: `users_router, notif_router, logs_router, excel_router`.

**Users** — prefix `/api/users`, **Admin only** for all of these (`require_admin`):
- `GET /` — list all users (`UserOut[]`, include `is_active` — settings.js user manager needs it).
- `POST /` — body `UserCreate`. Hash password with bcrypt before insert. 400 if email already exists.
- `PATCH /{id}/role` — body `{role}`. (`api.js` calls `PATCH /users/{id}/role`.)
- `DELETE /{id}` — **deactivate, not hard delete** — `settings.js` calls this "Deactivate" and the confirm dialog says "They will no longer be able to sign in." Implement as `UPDATE users SET is_active=FALSE`.

**Notifications** — prefix `/api/notifications`, any authenticated user, scoped to `current_user.id` only:
- `GET /?unread_only=` — list current user's notifications, newest first.
- `GET /unread-count` — `{count: n}`. (`api.js` has this method though nothing currently calls it — implement per contract.)
- `POST /mark-read` — mark ALL of current user's notifications read.
- `POST /{id}/read` — mark one read (must verify it belongs to current_user — do not allow marking others' notifications).

**Logs** — prefix `/api/logs`, **Admin only**:
- `GET /?limit=&entity_type=&user_id=` — paginated `audit_logs`, newest first, `AuditLogOut[]`.

**Excel import** — prefix `/api/import`, **Admin only**:
- `POST /excel` — `api.js`'s `importExcel(file)` posts multipart form-data with field `file` to `/api/import/excel`. No UI currently calls `API.importExcel` (dead code in api.js — no button wires to it in any page file). Implement a minimal working endpoint (accept `.xlsx` via `openpyxl`, return a count of rows found) rather than leaving it entirely absent, since it's part of the declared contract — but flag in the test report that there is no UI entry point to exercise it.

---

## Frontend — Missing Pages

`index.html` loads these via `<script>` tags; none exist. All must expose
`Pages.<Name> = { render, ... }` following the exact style of the existing
`overview.js` / `settings.js` (IIFE returning an object, `Router.state` as
data source, `fmt`/`badge` helpers, `Modals`/`Toast` for interaction).

### `frontend/js/pages/financials.js` → `Pages.Financials`
Full-portfolio financial report (distinct from the per-product Financials
tab already implemented inline in `product.js`). Sidebar nav item exists
(`data-page="financials"`), `router.js` registers the page and calls
`Pages.Financials.render()`. Must gate on `Auth.isAdmin() || Auth.currentUser()?.finance_access`
the same way `product.js`'s financials tab does, since `Router.state.financials`
already contains ALL products' financial rows once loaded (`loadAll()` calls
`API.financials.list()` unfiltered) — i.e. the **backend** must also enforce
this (see `data.py` above) since the frontend gate alone would leak data to
non-finance users via the network tab.
Minimum viable: budget vs spend table across all products + the existing
`Charts.budgetBars` reused, plus totals already computed in `overview.js`
(mirror that logic).

### `frontend/js/pages/decisions.js` → `Pages.Decisions`
Sidebar nav "Decisions & Risks" with a badge showing at-risk product count
(`nav-badge-decisions`, already wired in `router.js updateBadges()`).
Minimum viable: full risk register across all products (`Router.state.risks`,
already loaded) grouped/sorted by `risk_score` desc, reusing `badge.riskStatus`
and `badge.priority` helpers from `router.js`, plus the at-risk products list
(same logic as `overview.js atRiskList`).

### `frontend/js/pages/team.js` → `Pages.Team`
Sidebar nav "Team". Minimum viable: directory of all users (`API.gates.teamMembers()`
already returns `id, name, email, role, initials` — reuse it, no new endpoint
needed) shown as cards, with each product's team_lead cross-referenced from
`Router.state.products` to show a workload count per person.

### `frontend/js/pages/logs.js` → `Pages.Logs`
Sidebar nav "Audit Logs" (`nav-logs`, admin-only, already hidden/shown in
`auth.js applyUser()`). Calls `API.logs.list()`. Minimum viable: paginated
table of `AuditLogOut` rows (who / action_type / entity / old→new / when),
admin-only both by nav visibility AND by the backend route already being
`require_admin`.

---

## Known frontend bugs to fix while wiring this up (found by inspection, not yet by running)

1. `product.js` defines `tabPartnerships(product)` (a static placeholder,
   never called) AND relies on `renderPartnershipsTab(product.id)` from
   `gates.js` (the one actually wired in `renderTab()`'s switch statement).
   `tabPartnerships` is dead code — fine to delete, don't reimplement it.
2. `product.js`'s own `openAddPartnership(type, productId)` (line ~1024) is
   a stub that only shows a toast ("feature in progress") and never calls
   the API — but it's shadowed/unreachable because `gates.js` defines a
   **global** `openAddPartnership(productId, defaultType)` with a different
   argument order, and since `gates.js` loads after `product.js` in
   `index.html`, the global one wins and actually calls `API.partnerships.create`.
   Net effect: it works, but only by accident of script load order and a
   dead duplicate with a swapped signature sits in `product.js`. Worth a
   cleanup note in the final report even though it's not a functional bug today.
