# Bugs Found & Fixed — PD Dashboard

Scope: these are bugs found in the **originally delivered frontend code**
while functionally testing the app locally (not issues introduced by the
backend reconstruction — see `MISSING_IMPLEMENTATION_SPEC.md` for what was
missing entirely). Each entry: symptom → root cause → fix → how it was verified.

---

## Bug 1 — Every confirm dialog in the app was non-functional

**File:** `frontend/js/components/modals.js` — `Modals.confirm()`

**Symptom:** Archive Product, Delete Product, Delete Milestone, Deactivate
User, Remove Gate Task, and Remove Partnership all opened their confirmation
modal correctly, but clicking the confirm button silently did nothing — no
error shown to the user, no toast, nothing in the browser console.

**Root cause:**
```js
// BEFORE
footer: `
  <button class="btn btn-secondary" onclick="Modals.close()">Cancel</button>
  <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}"
          onclick="Modals.close();(${onConfirm.toString()})()">
    ${confirmText}
  </button>`,
```
The `onConfirm` callback was serialized to a string via `.toString()` and
re-injected into an inline `onclick` HTML attribute. Inline event handlers
execute in **global scope**, so any variable the callback closed over (e.g.
`id`, `p` from the enclosing `confirmArchive(id)` function) no longer
resolved — the stringified code threw `ReferenceError`s inside an `async`
function, which become silently-swallowed unhandled promise rejections
(no `window.onerror`, no console output). Confirmed via network log:
repeated `PATCH /api/products/ → 405 Method Not Allowed` (the product id
was missing from the URL because `id` was undefined).

**Fix:**
```js
// AFTER
function confirm({ title, message, confirmText = 'Confirm', danger = false, onConfirm }) {
  open({
    ...
    footer: `
      <button class="btn btn-secondary" onclick="Modals.close()">Cancel</button>
      <button class="btn ${danger ? 'btn-danger' : 'btn-primary'}"
              onclick="Modals._confirmNow()">
        ${confirmText}
      </button>`,
  });
  // Store the callback directly (closure intact) instead of serializing it.
  Modals._onConfirm = onConfirm;
}

function _confirmNow() {
  close();
  if (Modals._onConfirm) Modals._onConfirm();
}
```
`onConfirm` is now stored as a live reference on the `Modals` object and
invoked directly, preserving its closure — same pattern the existing
`Modals.form()` already used for its own submit handler.

**Verified:** Archive Product → `products.is_active` flips to `false` in
the DB. Delete Product → row actually removed. Both confirmed via direct
`psql` query after each action.

---

## Bug 2 — Stage-pipeline click, @mention autocomplete, and client manager were all dead code

**File:** `frontend/js/pages/product.js`

**Symptom:**
- Clicking a stage dot on the Product Overview did nothing.
- Typing `@` in the comment box never showed the mention dropdown.
- Clicking "Manage" or "Add a client" under the Clients section did nothing.

**Root cause:**
```js
// BEFORE
return {
  render, switchTab, openAddMilestone, /* ...etc */
};

// Expose mention handlers globally (called via inline event attributes)
window.handleMentionInput   = handleMentionInput;
window.handleMentionKeydown = handleMentionKeydown;
window.selectMention        = selectMention;
window.selectStageForChange = selectStageForChange;
window.cancelStageChange    = cancelStageChange;
window.confirmStageChange   = confirmStageChange;
```
A `return` statement unconditionally exits a function — every line after it
is unreachable. All six `window.x = ...` assignments (plus the four more I'd
need for the client manager) never ran, even though the HTML's `onclick`
attributes call them as bare globals (`onclick="openClientManager(2)"`, etc).

**Fix:** moved all `window.x = ...` assignments to **before** the `return`
statement, and added the missing client-manager exposures
(`openClientManager`, `linkClientNow`, `unlinkClientNow`, `createClientNow`)
that had the same problem.

**Verified:**
- Stage pipeline: clicking a stage → confirm bar → confirm updates
  `products.status` and bumps `updated_at`.
- Client manager: create-and-link and unlink both persist correctly to
  `clients` / `product_clients`.
- (Mention autocomplete dropdown itself relies on DOM timing that's hard to
  screenshot-test headlessly, but the handler is now reachable — same fix
  as the other two, verified by checking `typeof window.handleMentionInput`
  is `"function"` after the fix, `"undefined"` before.)

---

## Bug 3 — Adding/editing Financial data failed if an optional field was left blank

**File:** `frontend/js/pages/product.js` — `openEditFinancials()`

**Symptom:** "Add Financial Data" modal stayed open with no visible error
after clicking Save, whenever "Forecast" (or "Actual Spend") was left blank.

**Root cause:** `Modals.form`'s generic submit handler collects every field
as a trimmed **string**, sending `""` for any untouched optional numeric
field. `openAddProduct`/`openEditProduct` sanitize their own numeric fields
before calling the API (`parseFloat(...) || null`), but `openEditFinancials`
passed the raw form data straight through. The backend correctly rejects an
empty string against a `Decimal`-typed field (`422 decimal_parsing`) — this
was the backend behaving correctly and the frontend not sanitizing input
before sending it.

**Fix:**
```js
onSubmit: async (data) => {
  data.approved_budget = data.approved_budget || 0;
  data.actual_spend    = data.actual_spend    || 0;
  data.forecast        = data.forecast        || 0;
  ...
```

**Verified:** submitting with Forecast left blank now creates the row with
`forecast = 0.00`.

---

## Bug 4 — Any user without finance access saw a completely broken app (highest severity)

**File:** `frontend/js/router.js` — `Router.loadAll()`

**Symptom:** For any Team Lead, or any Manager not explicitly granted
finance access (the default for most non-Admin accounts), the Executive
Overview showed **0 Total Products, 0% Avg Completion, empty everything** —
while the gate heatmap lower on the *same page* (fetched independently)
correctly showed real data. Every later click re-triggered the same failure.

**Root cause:**
```js
// BEFORE
const [products, milestones, financials, risks, summary] = await Promise.all([
  API.products.list(),
  API.milestones.list(),
  API.financials.list(),   // ← correctly 403s for non-finance users
  API.risks.list(),
  API.products.summary(),
]);
state.products = products || []; // never reached if ANY of the 5 rejected
...
state.loaded = true;              // never reached either
```
`Promise.all` is all-or-nothing: one 403 from the (correctly restricted)
financials endpoint discarded the other four calls' results, even though
they'd already succeeded over the network. `state.loaded` also got stuck
`false` forever, so the whole batch silently retried and failed identically
on every page navigation.

**Fix:**
```js
// AFTER
const [products, milestones, financials, risks, summary] = await Promise.allSettled([...]);
state.products   = products.status   === 'fulfilled' ? (products.value   || []) : [];
state.milestones = milestones.status === 'fulfilled' ? (milestones.value || []) : [];
state.financials = financials.status === 'fulfilled' ? (financials.value || []) : [];
state.risks      = risks.status      === 'fulfilled' ? (risks.value      || []) : [];
state.summary    = summary.status    === 'fulfilled' ? (summary.value    || {}) : {};
state.loaded     = true;
```
Each of the 5 results is now applied independently; a restricted endpoint
failing for the current user no longer takes down the other four.

**Verified:** logged in as a Manager account with `finance_access = false`,
fresh session (cleared localStorage first to rule out stale-state noise).
Before the fix: `Router.state.products.length === 0`, `summary === null`.
After the fix: `products.length === 1`, `summary` fully populated, Overview
KPIs render correctly (1 product, 35% completion, 1 open risk), and the
Financials page still correctly stays locked for that user.

---

## Bug 5 — Setting a gate's start/due date, or a task's due date, always failed ("cannot reach server")

**File:** `backend/app/api/gates.py` — `set_gate_date()` and `update_task_status()`
(both pre-existing endpoints, not written during the initial reconstruction)

**Symptom:** Clicking the calendar icon on a gate (to set Start Date, Due
Date, or Gate Lead) and clicking Save appeared to succeed in the UI with no
error — but nothing was actually written to the database. In the browser
this showed up as the request failing at the network level rather than a
clean error response.

**Root cause:** `asyncpg` (the Postgres driver) requires a native Python
`date` object — not a string — for a `DATE` column. Both endpoints took
`due_date`/`start_date` straight out of the raw JSON payload (plain
strings like `'2026-08-15'`, or `''` when a field was left blank) and
passed them directly into a parameterized raw-SQL `INSERT`. Deep inside the
driver this throws `'str' object has no attribute 'toordinal'` — an
unhandled exception that terminates the connection mid-response, which the
browser reports as a generic network failure (`net::ERR_FAILED`, surfaced
by `api.js` as "Cannot reach server. Check that the backend is running.")
rather than a normal HTTP error. This affected **every** date field in the
Gates tab: the gate-level Start/Due Date modal, and a task's inline Due
Date field.

**Fix:** added a small `_parse_date()` helper that converts an incoming
value to a proper `date` object (via `date.fromisoformat`) or `None` if
blank/invalid, and applied it to both `due_date` and `start_date` in both
endpoints. Also normalized `gate_lead=''` to `None` so clearing/leaving it
blank doesn't overwrite an existing lead with an empty string.

**Bonus fix, same file:** `update_task_status()` also required `status` to
be present on every call — but the UI calls this same endpoint to update
*just* the owner or *just* the due date of a task (`updateGateTaskOwner`/
`updateGateTaskDate` in `gates.js`), with no `status` field at all. Every
such call was silently failing a 400 validation check (swallowed by an
empty `catch(_){}` in the frontend — no error shown, nothing saved). Made
`status` optional and switched the upsert to `COALESCE(:status, existing)`
so a partial update no longer clobbers or requires the status field.

**Verified:** setting a gate's due date now persists to `product_gate_dates`;
setting a task's owner-only or due-date-only now persists to
`product_gate_tasks` without resetting its existing status.

---

## Feature: Gate Lead now visible next to the calendar button

**File:** `frontend/js/pages/gates.js`

Previously the assigned Gate Lead was only shown as small gray text buried
in the gate's subtitle line ("3/5 tasks · Lead: X · Due: Y"), easy to miss.
Added a dedicated pill badge — person icon + name, or "Unassigned" in gray
if not yet set — positioned directly beside the calendar/date-edit button
in each gate's header row, visible to every role (not just those who can
edit it).

---

## Feature: Partnership status options updated

**Files:** `frontend/js/pages/gates.js` (the real Add/Edit Partnership
modals), `frontend/js/pages/product.js` (a dead-code duplicate, updated for
consistency), `backend/app/api/partnerships.py` (default value),
`database/schema.sql` (column default + comment), `PROJECT_OVERVIEW.md`

Replaced the old 6-option list (`Prospecting / In Discussion / MOU Signed /
Active / Completed / On Hold`) with:
1. Partner Identified
2. Agreement Development
3. Agreement Signed
4. On Hold

New default value on creation is "Partner Identified". Status badge colors
were remapped (gray / blue / green / red respectively). This is a display
and default-value change only — the `status` column is a plain `VARCHAR(50)`
with no `CHECK` constraint, so no database migration was needed.

---

## Feature: User reactivation

**Files:** `backend/app/api/admin.py` (new `POST /api/users/{id}/activate`
endpoint), `frontend/js/api.js`, `frontend/js/pages/settings.js`

Deactivating a user (`DELETE /api/users/{id}`, a soft delete setting
`is_active=FALSE`) had no way back through the app — no endpoint and no UI
button existed to reactivate someone, only a direct database `UPDATE`. The
Manage Users table now shows a neutral "Activate" icon for inactive users
and the existing red "Deactivate" icon for active ones, wired to the new
endpoint. Verified round-trip: deactivate → Inactive/Activate button shows →
Activate → confirm → `is_active` flips back to `true` in the database and
the badge/button both update.

---

## Feature: "Team Lead" product field renamed to "Owner"

**Files:** `frontend/js/pages/portfolio.js`, `frontend/js/pages/product.js`

Renamed the UI label everywhere it described *who leads a given product*
(product cards, Add/Edit Product form, Product Detail quick stats/info
row) from "Team Lead" to "Owner". The underlying field/column name
(`products.team_lead`, `team_lead_user_id`) was left unchanged — this is a
display-only rename, not a data model change. The **user role** called
"Team Lead" (Admin / Manager / Team Lead, in Settings → Manage Users) is a
separate concept and was deliberately left untouched.

---

## Feature: Gray/purple "Graphite" + white "Daylight" theme, then simplified to Daylight-only

The app's visual design was reworked twice in sequence:

1. First pass: a full re-skin from the original green/blue Aramco brand
   colors to a dark gray "Graphite" theme with a signature purple accent
   (purple = "active/current" — active nav item, the active/in-progress
   gate on the heatmap, primary buttons), glass-surface cards, and a
   drifting particle background. Rolled out across every page.
2. Second pass: added a second "Daylight" (white) mode alongside Graphite,
   switchable via a toggle, with both palettes bound to the same semantic
   design tokens so no component needed per-mode code. This surfaced and
   fixed several real contrast bugs along the way — see the git history
   (`Fix Daylight-mode contrast bug in Audit Log badges`) for the ones
   caught after the fact by actually computing WCAG contrast ratios rather
   than eyeballing them.
3. Final state (current): **Daylight/white is the only mode** — Graphite
   and the toggle were removed at the client's request. `frontend/css/main.css`
   now has a single `:root` token block with the Daylight values (including
   the darkened `--ink3`/`--amber-text` that were needed to actually clear
   WCAG AA — see the contrast note left in that file). `theme.js` no longer
   has a `Mode` object; `ParticleBackground` uses one fixed palette.

If a dark mode is wanted again later, the git history above (commits
`00c8dc6`, `7a52608`) has the full working dual-mode implementation to
restore from, rather than rebuilding it from scratch.

---

## Feature: SSO (OIDC) architecture scaffold

**Files:** `backend/app/core/config.py`, `backend/app/models/user.py`,
`backend/app/api/sso.py` (new), `backend/app/api/auth.py`,
`database/schema.sql`, `frontend/js/auth.js`, `frontend/index.html`,
new `SSO_SETUP.md`

Added everything needed to connect a real SSO/OIDC identity provider
later **without touching business logic**, while keeping it fully inactive
until configured:
- `users.password_hash` is now nullable, with new `auth_provider`
  (`'local'`/`'oidc'`) and `sso_subject` columns plus a check constraint
  guaranteeing every user has either a password or an SSO identity.
- `GET /api/auth/sso/status`, `GET /api/auth/sso/login`,
  `POST /api/auth/sso/callback` exist now — the login/status endpoint is
  live, the other two currently return `501` with the exact real
  implementation (authlib-based token exchange + JIT user provisioning)
  written out as comments, ready to drop in.
- The login screen has a "Sign in with SSO" button, hidden by default,
  that only appears once the backend reports SSO is actually configured.
- Both login paths converge on the same `create_access_token()` — an SSO
  session is indistinguishable from a password session to every downstream
  permission check, exactly like the rest of the app expects.

See **SSO_SETUP.md** for the exact steps to activate this with a real
identity provider (Azure AD / Entra ID, Okta, etc.).

---

## Not fixed — flagged only (lower severity / needs a product decision)

These were found but left as-is since they're validation gaps or design
questions rather than something with one obvious correct fix — see
`TEST_FINDINGS_REPORT.md` section 2 for full detail:

- Gate weight "must sum to 100%" is enforced client-side only — a direct API
  call can set an arbitrary weight.
- `GET /api/products/summary` returns portfolio-wide `total_budget`/`total_spend`
  to any authenticated user regardless of finance access (not currently
  rendered anywhere, but present in the raw response).
- Deleting a Client (soft delete) silently orphans its `product_clients`
  links; there's also no "Delete Client" button in the current UI, only
  unlink.
- Excel import has a working backend endpoint but no UI entry point.
